/*

 <MulRlarge.c>

 for trying Multiple large spheres with different Rlarge
 
 coded by Takeshi Kawabata (takawaba@is.naist.jp)

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <math.h>
#include "pdbstruct.h"
#include "PdbIO.h"
#include "SphePnt3.h"
#include "SpheIcosa.h"
#include "Amino.h"
#include "EachVol.h"
#include "Overlap.h"
#include "Cluster.h"
#include "ResMergeSort.h"
#include "AtmMergeSort.h"
#include "DifSpCnvHul.h"
#include "SpheHull.h"
#include "SortAtom.h"
#include "NeiNvec.h"

static float StaticRlargeArray[15][15] =
{
/*  0 */{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0},
/*  1 */{3.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0},
/*  2 */{3.0, 6.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0},
/*  3 */{3.0, 4.0, 5.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0},
/*  4 */{3.0, 6.0, 9.0,12.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0},
/*  5 */{3.0, 5.0, 7.0, 9.0,11.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0},
/*  6 */{3.0, 5.0, 7.0, 9.0,11.0,13.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0},
/*  7 */{3.0, 5.0, 7.0, 9.0,11.0,13.0,15.0,0.0,  0.0, 0.0, 0.0, 0.0, 0.0, 0.0},
/*  8 */{3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0,10.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0},
/*  9 */{3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0,10.0,11.0, 0.0, 0.0, 0.0, 0.0, 0.0},
/* 10 */{3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0,10.0,11.0,12.0, 0.0, 0.0, 0.0, 0.0},
/* 11 */{3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0,10.0,11.0,12.0,13.0, 0.0, 0.0, 0.0},
/* 12 */{3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0,10.0,11.0,12.0,13.0,14.0, 0.0, 0.0},
/* 13 */{3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0,10.0,11.0,12.0,13.0,14.0,15.0, 0.0},
/* 14 */{3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0,10.0,11.0,12.0,13.0,14.0,15.0,16.0},
};

/** Functions (GLOBAL) **/
void Try_Multiple_Large_Spheres();
void Generate_Multiple_Large_Spheres();

/** Functions (LOCAL) **/
static void Find_Min_Rinaccess_For_Each_Atom();
static void Find_Min_Rinaccess_For_Each_Residue();
static void Set_indRlarge_for_Crashed_Atoms_With_Probes();
static void Set_indRlarge_for_NonCrashed_Atoms_With_Probes();
static void Set_indRlarge_for_Crashed_Atoms_With_Planes();
static void Set_indRlarge_for_NonCrashed_Atoms_With_Planes();
static int Check_Crash_Pos_and_Planes();
static void Write_Residue_File_Multiple_Rlarge();
static void Read_PDB_File_Probes_By_FilePointer();
static void Read_PDB_File_Planes_By_FilePointer();




void Try_Multiple_Large_Spheres(NRlarge,Ahead,Rhead,Shead,Dmat,RprobeS,oprbfile,oprbonlyfile,oracfile)
 int    NRlarge;  /* Number of trying NRlarge */ 
 struct ATOM *Ahead; /* Protein Atoms       */ 
 struct RESIDUE *Rhead; /* Head of Protein Residues */
 struct ATOM *Shead; /* Small Probe Spheres */ 
 struct MATRIX *Dmat;
 float  RprobeS;
 char   *oprbfile;
 char   *oprbonlyfile;
 char   *oracfile;
{
 struct ATOM Lhead;        /* Large Probe Spheres */
 struct SH_FACE  SH_Fhead; /* For Convex (Spherical) Hull   */
 float  RlargeArray[128];
 int    k;
 struct ATOM *pn;
 char comment[1024],rcomment[1024],buff[128];
 int  NRinaccess;  /* Number of types of NRinaccess (NRlarge + 2) */

 printf("#Try_Multiple_Large_Spheres(NRlarge %d)\n",NRlarge);
 NRinaccess = NRlarge + 2;

/* 
 >> Rule for RlargeArray[] <<

  When NRlarge kinds of sphere are tried,
   (NRlarge + 2) kinds of Rlarge values are necessary.
   In other words, the range of RlargeArray is [0..NRlarge+1].

 (1) Before trying spheres, plane-probe is always tried. 
 (2) When Rlarge[NRlareg-1]-probes can delete a small probe, and the planes cannot (Rinaccess = plane),
     its Rinaccess = RlargeArray[NRlarge-1] + 2.0; index of Rinaccess = NRlarge.
 (3) When the planes can delete a small probe (Rinaccess = null)
     its Rinaccess = RlargeArray[NRlarge-1] + 4.0; index of Rinaccess = NRlarge+1.
*/

 /** [0] Set RlargeArray */
 if (NRlarge>=15)
 { printf("#ERROR:NRlarge %d is not proper. (Choose among 1,2,5,15).\n",NRlarge);
   exit(1); }
 else
 { for (k=0;k<NRlarge;++k) RlargeArray[k] = StaticRlargeArray[NRlarge][k]; }
  RlargeArray[NRlarge]   = RlargeArray[NRlarge-1] + 2.0;
  RlargeArray[NRlarge+1] = RlargeArray[NRlarge-1] + 4.0;

 
 /** [1] Initialize Probe pn->indRlarge and tFactor for plane-accessible */
 pn = Shead;
 while (pn->next != NULL) 
  { pn = pn->next; 
    pn->tFactor = RlargeArray[0];  /* smallest sphere- inaccessible */ 
    pn->indRlarge = 0; 
  }
 
 /* [2] Generate Probe-Planes */ 
 Initial_Double_Triangle_DifSp(Ahead,&SH_Fhead);
 ConstructHull_DifSp(Ahead,&SH_Fhead);
 Set_indRlarge_for_Crashed_Atoms_With_Planes(Shead,&SH_Fhead,NRlarge+1,RlargeArray[NRlarge+1]);
 Free_SH_FACEs(&SH_Fhead);

 /* [3] Generate Large Probe Spheres */ 
 for (k=NRlarge-1;k>=0;--k)
 { 
    Make_NEIGHBOR_ATOM(Ahead,Dmat,RlargeArray[k]);
    Initial_Double_Triangle_SpheHull(Ahead,&SH_Fhead,Dmat,RlargeArray[k]);
    Construct_Sphere_Hull(Ahead,&SH_Fhead,Dmat,RlargeArray[k]);
    Make_Probe_Atoms_from_SH_FACE(&Lhead,&SH_Fhead);
    Free_NEIGHBOR_ATOM(Ahead);
    Check_Crash_Bwn_Chains(Ahead, &Lhead, 'd');
    /* 
    Set_indRlarge_for_NonCrashed_Atoms_With_Probes(Shead,&Lhead,k,RlargeArray[k]); 
    */ 
    Set_indRlarge_for_Crashed_Atoms_With_Probes(Shead,&Lhead,k+1,RlargeArray[k+1]); 
    Free_ATOMs(&Lhead);
    Free_SH_FACEs(&SH_Fhead);

  } /* k */


 /* [4] Set Min_Rinaccess for each Atom and Residue */
 Find_Min_Rinaccess_For_Each_Atom(Ahead,Shead,NRlarge,RlargeArray);
 Find_Min_Rinaccess_For_Each_Residue(Rhead,Shead,NRlarge,RlargeArray);
 
 /* [5] Make rcomment[] lines */

 if ((oprbfile[0] != '\0')||(oracfile[0] != '\0')){
  rcomment[0] = '\0';
  sprintf(buff,"RprobeS   %6.2f A\n",RprobeS); strcat(rcomment,buff);
  sprintf(buff,"NRlarge   %d\n",NRlarge);  strcat(rcomment,buff);
  sprintf(buff,"NRinaccess %d\n",NRinaccess); strcat(rcomment,buff);
  for (k=0;k<NRlarge;++k) 
   {sprintf(buff,"Rlarge[%d] %6.2f A\n",k,RlargeArray[k]); strcat(rcomment,buff); }
  sprintf(buff,"*Rinaccess(p) = %.2f A : a probe with %.2f A can access a probe p, but planes cannot.\n",RlargeArray[NRlarge],RlargeArray[NRlarge-1]); 
 strcat(rcomment,buff);  
 sprintf(buff,"*Rinaccess(p) = %.2f A : a plane can access a probe p\n",RlargeArray[NRlarge+1]);
 strcat(rcomment,buff);  
 }

 /** [6] OUTPUT **/
 if (oprbfile[0] != '\0')
 { Recover_Atom_Order_By_Atom_Number(Ahead);
   sprintf(comment,"Protein Atoms and Small Probes\n"); strcat(comment,rcomment);
   sprintf(buff,"Column_tFactor : Raccess(a) = min_{p belongs to ContactProbes(a)}[ Rinaccess(p) ]\n"); strcat(comment,buff); 
   Write_PDB_File(oprbfile,Ahead,'w',comment,PAR.COMMAND);
   sprintf(comment,"Small Probe Spheres Shaved by Multiple Large Spheres\n"); strcat(comment,rcomment);
   sprintf(buff,"Column_tFactor : Rinaccess\n"); strcat(comment,buff); 
   Write_PDB_File_Probes(oprbfile,Shead,'a',comment,PAR.COMMAND); 
 }
 
 if (oprbonlyfile[0]!='\0') Write_PDB_File_Probes(oprbonlyfile,Shead,'w',comment,PAR.COMMAND); 

 if (oracfile[0] != '\0')
  Write_Residue_File_Multiple_Rlarge(oracfile,Rhead,RprobeS,NRlarge,RlargeArray,PAR.COMMAND);

 exit(1);

} /* end of Try_Multiple_Large_Spheres() */




void Try_Multiple_Large_Spheres_From_File(imulfile,NRlarge,Ahead,Rhead,Shead,Dmat,RprobeS,oprbfile,oracfile)
 char    *imulfile; /* Input multiple large probe files */
 int    NRlarge;  /* Number of trying NRlarge */ 
 struct ATOM *Ahead; /* Protein Atoms       */ 
 struct RESIDUE *Rhead; /* Head of Protein Residues */
 struct ATOM *Shead; /* Small Probe Spheres */ 
 struct MATRIX *Dmat;
 float  RprobeS;
 char   *oprbfile;
 char   *oracfile;
{
 struct ATOM Lhead;        /* Large Probe Spheres */
 struct SH_FACE  SH_Fhead; /* For Convex (Spherical) Hull   */
 float  RlargeArray[128];
 int    k;
 struct ATOM *pn;
 char comment[1024],rcomment[1024],buff[128];
 int  NRinaccess;  /* Number of types of NRinaccess (NRlarge + 2) */
 FILE *fpi;

 printf("#Try_Multiple_Large_Spheres(NRlarge %d)\n",NRlarge);
 NRinaccess = NRlarge + 2;

 fpi = fopen(imulfile,"r");
 if (fpi==NULL) {printf("#ERROR:Can't open imulfile \"%s\"\n",imulfile); exit(1);}

/* 
 >> Rule for RlargeArray[] <<

  When (NRlarge" kinds of sphere are tried,
   (NRlarge + 2) kinds of Rlarge values are nessarrray.
   In other woards, the range of RlargeArray is [0..NRlarge+1].

 (1) Before trying spheres, plane-probe is always tried. 
 (2) When Rlarge[NRlareg-1]-probes can delete a small probe, and the planes cannot (Rinaccess = plane),
     its Rinaccess = RlargeArray[NRlarge-1] + 2.0; index of Rinaccess = NRlarge.
 (3) When the planes can delete a small probe (Rinaccess = null)
     its Rinaccess = RlargeArray[NRlarge-1] + 4.0; index of Rinaccess = NRlarge+1.
*/

 /** [0] Set RlargeArray */
 if (NRlarge>=15)
 { printf("#ERROR:NRlarge %d is not proper. (Choose among 1,2,5,15).\n",NRlarge);
   exit(1); }
 else
 { for (k=0;k<NRlarge;++k) RlargeArray[k] = StaticRlargeArray[NRlarge][k]; }
  RlargeArray[NRlarge]   = RlargeArray[NRlarge-1] + 2.0;
  RlargeArray[NRlarge+1] = RlargeArray[NRlarge-1] + 4.0;

 
 /** [1] Initialize Probe pn->indRlarge and tFactor for plane-accessible */
 pn = Shead;
 while (pn->next != NULL) 
  { pn = pn->next; 
    pn->tFactor = RlargeArray[0];  /* smallest sphere- inaccessible */ 
    pn->indRlarge = 0; 
  }
 
 /* [2] Generate Probe-Planes */ 
 
 Read_PDB_File_Planes_By_FilePointer(fpi,&SH_Fhead);
 /*
 Initial_Double_Triangle_DifSp(Ahead,&SH_Fhead);
 ConstructHull_DifSp(Ahead,&SH_Fhead);
 */ 
 Set_indRlarge_for_Crashed_Atoms_With_Planes(Shead,&SH_Fhead,NRlarge+1,RlargeArray[NRlarge+1]);
 Free_SH_FACEs(&SH_Fhead);

 /* [3] Generate Large Probe Spheres */ 
 for (k=NRlarge-1;k>=0;--k)
 { 
    Read_PDB_File_Probes_By_FilePointer(fpi,&Lhead,RlargeArray[k]);
/*
    Make_NEIGHBOR_ATOM(Ahead,Dmat,RlargeArray[k]);
    Initial_Double_Triangle_SpheHull(Ahead,&SH_Fhead,Dmat,RlargeArray[k]);
    Construct_Sphere_Hull(Ahead,&SH_Fhead,Dmat,RlargeArray[k]);
    Make_Probe_Atoms_from_SH_FACE(&Lhead,&SH_Fhead);
    Free_NEIGHBOR_ATOM(Ahead);
    Check_Crash_Bwn_Chains(Ahead, &Lhead, 'd');
 */
    Set_indRlarge_for_Crashed_Atoms_With_Probes(Shead,&Lhead,k+1,RlargeArray[k+1]); 
    Free_ATOMs(&Lhead);
    Free_SH_FACEs(&SH_Fhead);

  } /* k */


 /* [4] Set Min_Rinaccess for each Atom and Residue */
 Find_Min_Rinaccess_For_Each_Atom(Ahead,Shead,NRlarge,RlargeArray);
 Find_Min_Rinaccess_For_Each_Residue(Rhead,Shead,NRlarge,RlargeArray);
 
 /* [5] Make rcomment[] lines */

 if ((oprbfile[0] != '\0')||(oracfile[0] != '\0'))
 {
  rcomment[0] = '\0';
  sprintf(buff,"RprobeS   %6.2f A\n",RprobeS); strcat(rcomment,buff);
  sprintf(buff,"NRlarge   %d\n",NRlarge);  strcat(rcomment,buff);
  sprintf(buff,"NRinaccess %d\n",NRinaccess); strcat(rcomment,buff);
  for (k=0;k<NRlarge;++k) 
   {sprintf(buff,"Rlarge[%d] %6.2f A\n",k,RlargeArray[k]); strcat(rcomment,buff); }
  sprintf(buff,"*Rinaccess(p) = %.2f A : a probe with %.2f A can access a probe p, but planes cannot.\n",RlargeArray[NRlarge],RlargeArray[NRlarge-1]); 
 strcat(rcomment,buff);  
 sprintf(buff,"*Rinaccess(p) = %.2f A : a plane can access a probe p\n",RlargeArray[NRlarge+1]);
 strcat(rcomment,buff);  
 }

 /** [6] OUTPUT **/
 if (oprbfile[0] != '\0')
 { Recover_Atom_Order_By_Atom_Number(Ahead);
   sprintf(comment,"Protein Atoms and Small Probes\n"); strcat(comment,rcomment);
   sprintf(buff,"Column_tFactor : Raccess(a) = min_{p belongs to ContactProbes(a)}[ Rinaccess(p) ]\n"); strcat(comment,buff); 
   Write_PDB_File(oprbfile,Ahead,'w',comment,PAR.COMMAND);
   sprintf(comment,"Small Probe Spheres Shaved by Multiple Large Spheres\n"); strcat(comment,rcomment);
   sprintf(buff,"Column_tFactor : Rinaccess\n"); strcat(comment,buff); 
   Write_PDB_File_Probes(oprbfile,Shead,'a',comment,PAR.COMMAND); }
 
 if (oracfile[0] != '\0')
  Write_Residue_File_Multiple_Rlarge(oracfile,Rhead,RprobeS,NRlarge,RlargeArray,PAR.COMMAND);

 fclose(fpi);
 exit(1);

} /* end of Try_Multiple_Large_Spheres_From_File() */







void Generate_Multiple_Large_Spheres(ofname,NRlarge,Ahead,Rhead,Dmat)
 char   *ofname;
 int    NRlarge;  /* Number of trying NRlarge */ 
 struct ATOM *Ahead; /* Protein Atoms       */ 
 struct RESIDUE *Rhead; /* Head of Protein Residues */
 struct MATRIX *Dmat;
{
 struct ATOM Lhead;        /* Large Probe Spheres */
 struct SH_FACE  SH_Fhead; /* For Convex (Spherical) Hull   */
 float  RlargeArray[128];
 int    i,j,k,L;
 struct ATOM *pn;
 char comment[1024],buff[128];
 int  NRinaccess;  /* Number of types of NRinaccess (NRlarge + 2) */
 FILE  *fpo;
 

 printf("#Generate_Multiple_Large_Spheres(NRlarge %d)\n",NRlarge);
 NRinaccess = NRlarge + 2;

/* 
 >> Rule for RlargeArray[] <<

  When (NRlarge" kinds of sphere are tried,
   (NRlarge + 2) kinds of Rlarge values are nessarrray.
   In other woards, the range of RlargeArray is [0..NRlarge+1].

 (1) Before trying spheres, plane-probe is always tried. 
 (2) When Rlarge[NRlareg-1]-probes can delete a small probe, and the planes cannot (Rinaccess = plane),
     its Rinaccess = RlargeArray[NRlarge-1] + 2.0; index of Rinaccess = NRlarge.
 (3) When the planes can delete a small probe (Rinaccess = null)
     its Rinaccess = RlargeArray[NRlarge-1] + 4.0; index of Rinaccess = NRlarge+1.
*/
 
 /** [0] Set RlargeArray */
 if (NRlarge>=15)
 { printf("#ERROR:NRlarge %d is not proper. (Choose among 1,2,5,15).\n",NRlarge);
   exit(1); }
 else
 { for (k=0;k<NRlarge;++k) RlargeArray[k] = StaticRlargeArray[NRlarge][k]; }
 
  RlargeArray[NRlarge]   = RlargeArray[NRlarge-1] + 2.0;
  RlargeArray[NRlarge+1] = RlargeArray[NRlarge-1] + 4.0;

 /* [1] Make and Write comment[] lines */

  comment[0] = '\0';
  sprintf(buff,"NRlarge   %d\n",NRlarge);  strcat(comment,buff);
  sprintf(buff,"NRinaccess %d\n",NRinaccess); strcat(comment,buff);
  for (k=0;k<NRlarge;++k) 
   {sprintf(buff,"Rlarge[%d] %6.2f A\n",k,RlargeArray[k]); strcat(comment,buff); }
  sprintf(buff,"*Rinaccess(p) = %.2f A : a probe with %.2f A can access a probe p, but planes cannot.\n",RlargeArray[NRlarge],RlargeArray[NRlarge-1]); 
 strcat(comment,buff);  
 sprintf(buff,"*Rinaccess(p) = %.2f A : a plane can access a probe p\n",RlargeArray[NRlarge+1]);
 strcat(comment,buff);  

 printf("#COMMENT \"%s\"\n",comment);
 fpo = fopen(ofname,"w");
 if (fpo==NULL) {printf("#ERROR:Can't write to \"%s\"",ofname); exit(1);}
 fprintf(fpo,"HEADER MULTIPLE LARGE PROBE FILES\n");
 fprintf(fpo,"REMARK COMMAND \"%s\"\n",PAR.COMMAND);
 fprintf(fpo,"REMARK FILENAME \"%s\"\n",ofname);
 fprintf(fpo,"REMARK DATE      %s\n",Get_Date_String());
 Write_Comment_PDB_Remark(fpo,comment);
 fclose(fpo);

 /* [2] Generate and Write Probe-Planes */ 
 Initial_Double_Triangle_DifSp(Ahead,&SH_Fhead);
 ConstructHull_DifSp(Ahead,&SH_Fhead);
 Write_PDB_File_Planes(ofname,&SH_Fhead,'a',"","");
 Free_SH_FACEs(&SH_Fhead);

 /* [3] Generate and Write Large Probe Spheres */ 
 for (k=NRlarge-1;k>=0;--k)
 { 
    Make_NEIGHBOR_ATOM(Ahead,Dmat,RlargeArray[k]);
    Initial_Double_Triangle_SpheHull(Ahead,&SH_Fhead,Dmat,RlargeArray[k]);
    Construct_Sphere_Hull(Ahead,&SH_Fhead,Dmat,RlargeArray[k]);
    Make_Probe_Atoms_from_SH_FACE(&Lhead,&SH_Fhead);
    Free_NEIGHBOR_ATOM(Ahead);
    Check_Crash_Bwn_Chains(Ahead, &Lhead, 'd');
    Write_PDB_File_Probes(ofname,&Lhead,'a',"","");
    Free_ATOMs(&Lhead);
    Free_SH_FACEs(&SH_Fhead);
  } /* k */

 exit(1);

} /* end of Generate_Multiple_Large_Spheres() */







void Find_Min_Rinaccess_For_Each_Atom(Ahead,Phead,NRlarge,RlargeArray)
 struct ATOM *Ahead; /* Protein Atoms       */ 
 struct ATOM *Phead; /* Small Probe Spheres */ 
 int    NRlarge;        /* Number of tried different large probe spheres */
 float  *RlargeArray;   /* RlargeArray[0..NRlarge-1] */    
{
 struct ATOM *an,*pn;
 int i,hit,Ncon;

 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  an->indRlarge = 100; Ncon = 0;
  pn = Phead;
  while (pn->next != NULL)
  {
   pn = pn->next;
   i = hit = 0;
   while ((i<3)&&(hit==0)) 
    { if ((pn->con[i]!=NULL)&&(an->num == pn->con[i]->num)) {hit = 1; ++Ncon;} else ++i; }
   if ((hit==1)&&(pn->indRlarge < an->indRlarge)) an->indRlarge = pn->indRlarge;
  }

  if (Ncon==0) an->tFactor   =  0.0;
  else an->tFactor = RlargeArray[an->indRlarge];

 } /* an */

} /* end of Find_Min_Rinaccess_For_Each_Atom() */






void Find_Min_Rinaccess_For_Each_Residue(Rhead,Phead,NRlarge,RlargeArray)
 struct RESIDUE *Rhead; /* Protein Residues     */ 
 struct ATOM    *Phead; /* Small Probe Spheres  */ 
 int    NRlarge;        /* Number of tried different large probe spheres */
 float  *RlargeArray;   /* RlargeArray[0..NRlarge-1] */    
{
 /** 
   You have to do "Find_Min_Rinaccess_For_Each_Atom()",
   before try this function.
 **/ 

 struct RESIDUE *rn;
 struct ATOM *an,*pn;
 int Ncon,i,hit;

 printf("#Find_Min_Rinaccess_For_Each_Residue()\n");

 /* Scan residues */
 rn = Rhead;
 while (rn->next != NULL)
 {
  rn = rn->next;

  /* malloc Nprobe_multi[] */
  rn->Nprobe_multi = (int *)malloc(sizeof(int)*(NRlarge+2)); 
  for (i=0;i<(NRlarge+2);++i) rn->Nprobe_multi[i] = 0;
  rn->Racc = 100; Ncon = 0;
  rn->Nprobe = 0;
 
  /* Initialze mark of Probes */
  pn = Phead;  
  while (pn->next != NULL) {pn = pn->next; pn->mark = 0;} 

  an = &(rn->Ahead); 
  while (an->rnext != NULL)
  {
   an = an->rnext;
   pn = Phead;  
   while (pn->next != NULL)
   {
    pn = pn->next; 
    i = hit = 0;
    while ((i<3)&&(hit==0)) 
    { if ((pn->con[i]!=NULL)&&(an->num == pn->con[i]->num)) {hit = 1; pn->mark = 1;} else ++i; }
   } /* pn */
  } /* an */

  /* Re-scan marked probes */
  Ncon = 0;
  pn = Phead; rn->Racc = 100.0; 
  while (pn->next != NULL) 
  { pn = pn->next; 
    if (pn->mark ==1) 
    { ++rn->Nprobe; 
      ++(rn->Nprobe_multi[pn->indRlarge]);
      if (RlargeArray[pn->indRlarge] < rn->Racc) rn->Racc = RlargeArray[pn->indRlarge];
   }
  } /* pn */
 
  if (rn->Nprobe==0) rn->Racc = 0.0;  

 } /* rn */

  /* Re-initialze mark of Probes */
  pn = Phead;  
  while (pn->next != NULL) {pn = pn->next; pn->mark = 0;} 

} /* end of Find_Min_Rinaccess_For_Each_Residue() */







void Set_indRlarge_for_Crashed_Atoms_With_Probes(Phead,Rhead,indRlarge,tFactor_val)
 struct ATOM *Phead;  /* Head of probed atoms to be checked */
 struct ATOM *Rhead;  /* Head of reference atoms */
 int    indRlarge;    /* index of Rlarge */
 float  tFactor_val;
{
 struct ATOM *pn,*rn;
 char crash;
 
 printf("#Set_indRlarge_for_Crashed_Atoms_With_Probes()\n"); fflush(stdout);
 pn = Phead; crash = 0;
 while (pn->next != NULL)
 {
   pn = pn->next;
   crash = Check_Crash_Pos_and_Atoms(pn->Pos,pn->R,Rhead);
  
   /* First, Rinaccess is the minimum value. Then we tried from the largest radius. */
   if ((crash==1)&&(pn->tFactor<tFactor_val))
   { pn->tFactor = tFactor_val;
     pn->indRlarge = indRlarge;  
     /* printf("pn %d sphere_crash tFact %f\n",pn->num,pn->tFactor); */
   }
 }

} /* end of Set_indRlarge_for_Crashed_Atoms_With_Probes() */





void Set_indRlarge_for_NonCrashed_Atoms_With_Probes(Phead,Rhead,indRlarge,tFactor_val)
 struct ATOM *Phead;  /* Head of probed atoms to be checked */
 struct ATOM *Rhead;  /* Head of reference atoms */
 int    indRlarge;    /* index of Rlarge */
 float  tFactor_val;
{
 struct ATOM *pn,*rn;
 char crash;
 
 printf("#Set_indRlarge_for_Crashed_Atoms_With_Probes()\n"); fflush(stdout);
 pn = Phead; crash = 0;
 while (pn->next != NULL)
 {
   pn = pn->next;
   crash = Check_Crash_Pos_and_Atoms(pn->Pos,pn->R,Rhead);
  
   if (crash != 1) 
   { pn->tFactor = tFactor_val;
     pn->indRlarge = indRlarge;  }
 }

} /* end of Set_indRlarge_for_NonCrashed_Atoms_With_Probes() */







void Set_indRlarge_for_Crashed_Atoms_With_Planes(Phead,Fhead,indRlarge,tFactor_val)
 struct ATOM *Phead;   /* Head of probed atoms to be checked */
 struct SH_FACE *Fhead; /* Head of Faces of Convex Hull */
 int    indRlarge;     /* index of Rlarge */
 float  tFactor_val;
{
 struct ATOM *pn;
 char crash;
 
 printf("#Set_indRlarge_for_Crashed_Atoms_With_Planes()\n"); fflush(stdout);
 pn = Phead; crash = 0;
 while (pn->next != NULL)
 {
   pn = pn->next;
   crash = Check_Crash_Pos_and_Planes(pn,Fhead);

   /* First, Rinaccess is the minimum value. Then we tried from the largest radius. */
   if ((crash==1)&&(pn->tFactor<tFactor_val))
    { pn->tFactor = tFactor_val;
      pn->indRlarge = indRlarge;  
  /* printf("pn %d plane_crash tFact %f\n",pn->num,pn->tFactor); */
   }

 } /* pn */

} /* end of Set_indRlarge_for_Crashed_Atoms_With_Planes() */



void Set_indRlarge_for_NonCrashed_Atoms_With_Planes(Phead,Fhead,indRlarge,tFactor_val)
 struct ATOM *Phead;   /* Head of probed atoms to be checked */
 struct SH_FACE *Fhead; /* Head of Faces of Convex Hull */
 int    indRlarge;     /* index of Rlarge */
 float  tFactor_val;
{
 struct ATOM *pn;
 char crash;
 
 printf("#Set_indRlarge_for_Crashed_Atoms_With_Planes()\n"); fflush(stdout);
 pn = Phead; crash = 0;
 while (pn->next != NULL)
 {
   pn = pn->next;
   crash = Check_Crash_Pos_and_Planes(pn,Fhead);

   if (crash != 1) 
     { pn->tFactor = tFactor_val;
       pn->indRlarge = indRlarge; } 
 }

} /* end of Set_indRlarge_for_Crashed_Atoms_With_Planes() */






int Check_Crash_Pos_and_Planes(pn,Fhead)
 struct ATOM *pn;
 struct SH_FACE *Fhead; /* Head of Faces of Convex Hull */
{
 /*
  plane : 
   nvec * (x - tpnt[0]) = 0
   nvec * nvec = 1
 
       pn 
       |  nvec
    ___|_____
   /   |    /
  /    x   /
 /________/ 

  pn - x  = dis * nvec;

  nvec * (pn - dis*nvec - tpnt[0]) = 0;  

  dis = nvec * (pn - tpnt[0]);

 */

 int crash;
 struct SH_FACE *fn;
 float  PV[3],dis;

 crash = 0;
 fn = Fhead;
 while ((fn->next != NULL) &&(crash==0))
  { fn = fn->next;
    PV[0] = pn->Pos[0] - fn->tpnt[0][0];
    PV[1] = pn->Pos[1] - fn->tpnt[0][1];
    PV[2] = pn->Pos[2] - fn->tpnt[0][2];
    dis = fn->nvec[0] * PV[0] + fn->nvec[1] * PV[1] + fn->nvec[2] * PV[2];

         if (dis > 0.0)         crash = 1;
    else if (fabs(dis) < pn->R) crash = 1; 
    /* printf("fn %d dis %f crash %d\n",fn->num,dis,crash); */
  }
  /*
  printf("#crash %d\n",crash);
  */ 
  return(crash);

} /* end of Check_Crash_Pos_and_Planes() */



void Write_Residue_File_Multiple_Rlarge(fname,Rhead,RprobeS,NRlarge,RlargeArray,command)
 char *fname;
 struct RESIDUE *Rhead;
 float RprobeS;
 int    NRlarge;        /* Number of tried different large probe spheres */
 float  *RlargeArray;   /* RlargeArray[0..NRlage-1] */    
 char *command;
{
 FILE *fp;
 struct RESIDUE *rn;
 float Vone_probe,Vprb,Mprb,Mmxcl;
 char chain;
 int i;
 
 printf("#Write_Residue_File_Mulriple_Rlarge() -> \"%s\"\n",fname);
 
 Vone_probe = 4.0/3.0*M_PI*RprobeS*RprobeS*RprobeS;
 if (fname[0]=='-') fp = stdout;
 else
 {
  fp = fopen(fname,"w");
  if (fp==NULL) { printf("#ERROR:Can't write to \"%s\"\n",fname); exit(1);}
 }
 
 fprintf(fp,"#>>>> Raccess of Pocket Probes for Each Residues<<<<\n");
 if (command[0] != '\0') fprintf(fp,"#%-14s %s\n","COMMAND",command);
 fprintf(fp,"#%-14s %s\n","DATE",Get_Date_String());
 fprintf(fp,"#%-14s %.2f A\n","RprobeS",RprobeS);
 fprintf(fp,"#%-14s %d\n","NRlarge",NRlarge);
 for (i=0;i<NRlarge;++i) fprintf(fp,"#%-6s %2d      %6.2f A\n","Rlarge",i,RlargeArray[i]);
 
 fprintf(fp,"#%-14s Num of atoms in the residue\n","[Natm]");
 fprintf(fp,"#%-14s Minimum of Rinaccess among contacting probes to the residue\n","[Racc]");
 fprintf(fp,"#%-14s *Rinaccess(p): minimum radius of large probe, which cannot delete the probe p.\n","");
 fprintf(fp,"#%-14s *if no probe is contacted, Racc = 0.0 (buried).\n","");
 fprintf(fp,"#%-14s *Rinaccess(p) = %.2f A : a probe with %.2f A can access to the probe p, but planes cannot.\n","",RlargeArray[NRlarge],RlargeArray[NRlarge-1]); 
 fprintf(fp,"#%-14s *Rinaccess(p) = %.2f A : a plane can access to the probe p\n","",RlargeArray[NRlarge+1]);
 
 fprintf(fp,"#%-14s Num of contacted probes in pocket\n","[Nprb]");
 for (i=0;i<NRlarge;++i) 
  fprintf(fp,"#[N(%6.2f)]    Num of contacted probes with Rinaccess %.1f A\n",
   RlargeArray[i],RlargeArray[i]);
 fprintf(fp,"#[N(plane)]    Num of contacted probes with Rinaccess = %.1f (infinity (plane))\n",
RlargeArray[NRlarge]);
 fprintf(fp,"#[N(convex)]   Num of contacted probes with Rinaccess = %.1f (a plane can access)\n",
RlargeArray[NRlarge+1]);
 fprintf(fp,"#[RNUM] [CHAIN] [RES] [Natm] [Racc] [Nprb]");
 for (i=0;i<NRlarge;++i) fprintf(fp," [N(%.2f)]",RlargeArray[i]);
 fprintf(fp," [N(plane)] [N(convex)]\n"); 
 
 rn = Rhead;
 while (rn->next != NULL)
 {
  rn = rn->next;
  if (rn->Chain == ' ') chain = '-'; else chain = rn->Chain;
  fprintf(fp,"%5s %c %3s %4d %6.2f %3d ",rn->Rnum,chain,rn->Resi,rn->Natom,rn->Racc,rn->Nprobe);
  for (i=0;i<(NRlarge+2);++i) fprintf(fp," %3d",rn->Nprobe_multi[i]);
  fprintf(fp,"\n");
 }
 
 if (fp!=stdout) fclose(fp);

} /* end of Write_Residue_File_Multiple_Rlarge() */


void Read_PDB_File_Probes_By_FilePointer(fp,Phead,Rprobe)
 FILE  *fp;
 struct ATOM *Phead; /* Head of Probes */
 float Rprobe;
{
 char line[256],B[32],Aname[32],Rname[32],atomtype,chain,endflag;
 char atminfo[32];
 float P[3];
 int anum;
 struct ATOM *an;
                                                                                                                           
 /*
 >> FILE FORMAT <<
 REMARK [con0-2]: Atom numbers of protein atoms contacting the probe.
 REMARK                               X       Y       Z     R Mprob catm1 catm2 catm3
 HETATM    1  NOC PRB P   1      10.823   9.016   2.542  1.87 11.25  1123  1127  1139
 HETATM    2  NOO PRB P   1      10.965   8.839   2.505  1.87 11.25   694  1123  1139
 HETATM    3  OCC PRB P   1      14.409   9.826   2.608  1.87 11.25   693   699  1139
 */
                                                                                                                           
 printf("#Read_PDB_File_Probes_By_FilePointer()\n");
 anum = 0;
 Phead->next = NULL;
 an = Phead;  endflag = 0;
                                                                                                                           
 while ((feof(fp)==0)&&(endflag==0))
 {
  line[0] = '\0';
  fgets(line,255,fp);
       if (strncmp(line,"ATOM",4)==0)   atomtype = 'A';
  else if (strncmp(line,"HETATM",6)==0) atomtype = 'H';
  else atomtype = ' ';
       
  if (strncmp(line,"END",3)==0) endflag = 1;
  if (strncmp(line,"TER",3)==0) endflag = 1;
                                                                                                                    
  if (atomtype != ' ')
  {
    Get_Part_Of_Line(Aname,line,12,15);
    Get_Part_Of_Line(Rname,line,17,19);
    Get_Part_Of_Line(atminfo,line,12,25);
    atminfo[4] = ' ';
    /* printf("\"%s\"\n",atminfo); */
    chain = line[21];
    an->next = (struct ATOM *)malloc(sizeof(struct ATOM));
    an->next->prev = an;
    an = an->next;
    an->next = NULL;
    Get_Part_Of_Line(B,line,30,37); an->Pos[0] = atof(B);
    Get_Part_Of_Line(B,line,38,45); an->Pos[1] = atof(B);
    Get_Part_Of_Line(B,line,46,53); an->Pos[2] = atof(B);
    Get_Part_Of_Line(an->Anum,line,6,10);
    Get_Part_Of_Line(an->Atom,line,12,15);
    Get_Part_Of_Line(an->Resi,line,17,19);
    Get_Part_Of_Line(an->Rnum,line,22,26);
    Get_Part_Of_Line(B,line,54,59); an->Occup  = atof(B);
    Get_Part_Of_Line(B,line,60,65); an->tFactor = atof(B);
    /* an->tFactor = 0.0; */
    an->Chain = chain;
    an->num   = anum;
    an->res = NULL;
    an->rnext = an->rprev = NULL;
    an->AHtype = atomtype;
    an->R  = Rprobe;
    an->RR = an->R * an->R;
    an->subtype = ' ';
    ++anum;
  }
 } /* while */

} /* end of Read_PDB_File_Probes_By_FilePointer() */






void Read_PDB_File_Planes_By_FilePointer(fp,Fhead)
 FILE  *fp;
 struct SH_FACE *Fhead; /* Head FACEs */
{
 char line[256],B[32],Rname[32],atomtype,endflag;
 int Nface;
 struct SH_FACE *fn;
                                                                                                                           
 /*
 >> FILE FORMAT <<
 HEADER FILES FOR TANGENT PLANES
 REMARK One of the three tangent points and normal vectors are described.
 REMARK DATE Dec 17,2005 15:8:21
 REMARK                          Tpnt0x  Tpnt0y  Tpnt0z  Nv_x  Nv_y  Nv_z
 HETATM    1  CA  PLN P   1       0.108  43.424  30.537 0.247 0.904 0.349
 HETATM    2  CA  PLN P   1      -1.330  43.324  29.997-0.522 0.851 0.060
 */
                                                                                                                           
 printf("#Read_PDB_File_Planes_By_FilePointer()\n");
 
 Fhead->next = NULL;
 fn = Fhead;  endflag = 0;
 Nface = 0;
 
 while ((feof(fp)==0)&&(endflag==0))
 {
  line[0] = '\0';
  fgets(line,255,fp);
       if (strncmp(line,"ATOM",4)==0)   atomtype = 'A';
  else if (strncmp(line,"HETATM",6)==0) atomtype = 'H';
  else atomtype = ' ';
       
  if (strncmp(line,"END",3)==0) endflag = 1;
  if (strncmp(line,"TER",3)==0) endflag = 1;
                                                                                                                    
  Get_Part_Of_Line(Rname,line,17,19);
 
  if ((atomtype != ' ')&&(strncmp(Rname,"PLN",3)==0))
  {
    fn->next = (struct SH_FACE *)malloc(sizeof(struct SH_FACE));
    fn->next->prev = fn;
    fn = fn->next;
    fn->next = NULL;
    Get_Part_Of_Line(B,line,30,37); fn->tpnt[0][0] = atof(B);
    Get_Part_Of_Line(B,line,38,45); fn->tpnt[0][1] = atof(B);
    Get_Part_Of_Line(B,line,46,53); fn->tpnt[0][2] = atof(B);

    Get_Part_Of_Line(B,line,54,59); fn->nvec[0] = atof(B);
    Get_Part_Of_Line(B,line,60,65); fn->nvec[1] = atof(B);
    Get_Part_Of_Line(B,line,66,71); fn->nvec[2] = atof(B);
 
    ++Nface; 
    fn->num   = Nface;
    fn->tpnt[1][0] = fn->tpnt[1][1] = fn->tpnt[1][2] = 0.0;
    fn->tpnt[2][0] = fn->tpnt[2][1] = fn->tpnt[2][2] = 0.0;
    fn->R  = fn->RR = 0.0;
    fn->probe = NULL;    
  }

 } /* while */

} /* end of Read_PDB_File_Planes_By_FilePointer() */
