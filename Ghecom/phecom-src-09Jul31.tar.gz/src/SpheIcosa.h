/*
 
<SpheIcosa.h>

*/

extern void Make_Probe_Spheres_Icosahedron();
extern void Make_Probe_Spheres_Icosahedron_Recursive();
