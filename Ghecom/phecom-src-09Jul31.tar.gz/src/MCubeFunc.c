/*

<MCubeFunc.c>
 
 functions for calculating surface data from voxel data
 using Marching-Cube algorithm.

 coded by Takeshi Kawabata (takawaba@is.naist.jp)

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <math.h>
#include "Voxel.h" 
#include "mc_verface.h" 


/** Connection Matrix **/
struct CMATRIX{
 int N;
 char **m; };


/*** FUNCTIONS (GLOBAL) ***/
void Marching_Cube();
void Output_MC_Faces_VRML();
int  Output_MC_Faces_PDB();
float Volume_Inside_Faces();
float Area_Faces();
void Free_MC_Vertex_Stack();
void Free_MC_Face_Stack();
struct MC_VERTEX *Add_MC_Vertex_Stack();
struct MC_FACE *Add_MC_Face_Stack();


/*** FUNCTIONS (LOCAL) ***/
static void Sub_Vec_F();
static void Sub_Vec_FI();
static void Cross_Prod_F();
static float Dot_Prod_F();
static int  March_Tetrahedron();
static void Make_Mid_Point();
static struct MC_VERTEX *Add_Pnt_to_Ver_Map();
static struct MC_VERTEX *Find_Ver_Map();
static void Free_MIDPNT_Stack_In_MIDMAP_YZ();
static void Malloc_CMATRIX();
static void Free_CMATRIX();
static float VolumeTetrahedron();
static void Malloc_MIDMAP();
static void Free_MIDMAP();
static void Reset_MIDMAP();
static int Number_Of_MC_VERTEX();
static void Output_Comment();

static char MidPntType;


void Marching_Cube(vox,Vhead,Fhead,thre,midpnttype)
 struct VOXEL  *vox;
 struct MC_VERTEX *Vhead;
 struct MC_FACE   *Fhead;
 float thre;
 char midpnttype;
 /* 'H' HalfPoint Interpolation  
    'S' Simple Interpolation  
    'C' Complicated Interpolation  */
{
 char voxfile[128];
 struct MIDMAP Map0,Map1,*Curr,*Post;
 int i,j,k,x,y,z,K,L;
 int a[3],b[3],c[3],d[3],e[3],f[3],g[3],h[3]; /* Eight vertex of cube */
 struct MC_VERTEX *vn;
 struct MC_FACE   *fn;
 int Nin,Nxyz,Nver,Nface;
 /*

  To decide a new mid-point is already constructed or not,
  two maps (map[y][z]) are used : Map0 and Map1.
  if ((x%2)==0)  {Cur = Map0; Post = Map1;}
     (othereise) {Cur = Map1; Post = Map0;}
 

 */


 /*
 printf("#Marching_Cube(vox,Vhead,Fhead,thre,midpnttype)\n");
 */

 MidPntType = midpnttype;
 
 Vhead->num = -1; Vhead->next = NULL;
 /* Fhead->num = -1; */
 Fhead->next = NULL;
 Malloc_MIDMAP(&Map0,vox->N[1], vox->N[2]);
 Reset_MIDMAP(&Map0);
 Malloc_MIDMAP(&Map1,vox->N[1], vox->N[2]);
 Reset_MIDMAP(&Map1);

 /* printf("#grid %f X %d Y %d Z %d minX %f minY %f minZ %f \n",
   vox->gridlen,vox->N[0],vox->N[1],vox->N[2],vox->minX,vox->minY,vox->minZ);  */

 /*** Marching Cube ***/
 for (x=0;x<(vox->N[0]-1);++x)
 { 
    if ((x%2)==0) {Curr = &Map0; Post = &Map1; Reset_MIDMAP(&Map1);}
             else {Curr = &Map1; Post = &Map0; Reset_MIDMAP(&Map0);}

   /*
   printf("[%d] ",x); 
   if (Vhead->next!=NULL) printf(" %d ",Vhead->next->num);
   fflush(stdout);
   if (((x+1)%5)==0) {printf("\n"); fflush(stdout);} 
   if (x==(vox->N[0]-2)) printf("\n"); 
   */
 
   for (y=0;y<(vox->N[1]-1);++y)
   for (z=0;z<(vox->N[2]-1);++z)
   { 
    /* Eight vertices of the focused cube */ 
    a[0] = x;   a[1] = y;   a[2] = z;   
    b[0] = x+1; b[1] = y;   b[2] = z;   
    c[0] = x+1; c[1] = y+1; c[2] = z;   
    d[0] = x;   d[1] = y+1; d[2] = z;   
    e[0] = x;   e[1] = y;   e[2] = z+1; 
    f[0] = x+1; f[1] = y;   f[2] = z+1; 
    g[0] = x+1; g[1] = y+1; g[2] = z+1; 
    h[0] = x;   h[1] = y+1; h[2] = z+1; 
   
    if (((x+y+z)%2)==0)
    {
     March_Tetrahedron(x,a,b,c,f,vox,Vhead,Fhead,Curr,Post,thre);
     March_Tetrahedron(x,f,g,h,c,vox,Vhead,Fhead,Curr,Post,thre);
     March_Tetrahedron(x,f,e,h,a,vox,Vhead,Fhead,Curr,Post,thre);
     March_Tetrahedron(x,a,c,d,h,vox,Vhead,Fhead,Curr,Post,thre);
     March_Tetrahedron(x,f,c,h,a,vox,Vhead,Fhead,Curr,Post,thre);
     }
    else 
    {
     March_Tetrahedron(x,e,f,g,b,vox,Vhead,Fhead,Curr,Post,thre);
     March_Tetrahedron(x,b,c,d,g,vox,Vhead,Fhead,Curr,Post,thre);
     March_Tetrahedron(x,e,g,h,d,vox,Vhead,Fhead,Curr,Post,thre);
     March_Tetrahedron(x,a,b,d,e,vox,Vhead,Fhead,Curr,Post,thre);
     March_Tetrahedron(x,e,g,b,d,vox,Vhead,Fhead,Curr,Post,thre);
     }

   } /* yz loop */

 } /* x loop */

 /* printf("\n#done\n"); */

 Free_MIDMAP(&Map1);
 Free_MIDMAP(&Map0);
 
} /* end of Marching_Cube() */




int March_Tetrahedron(cur_x,a,b,c,d,vox,Vhead,Fhead,Curr,Post,thre)
 int cur_x;  /* current x */
 int a[3],b[3],c[3],d[3];
 struct VOXEL *vox; 
 struct MC_VERTEX *Vhead;
 struct MC_FACE   *Fhead;
 struct MIDMAP *Curr,*Post;
 float thre;
{
 int i,Nin,Nout;
 int IN[4][3],OUT[4][3];   /* Lattice Number for INside and OUTside vertex */
 struct MC_VERTEX *pn,*qn,*rn,*sn;
 char A,B,C,D;


 if (vox->dat[a[0]][a[1]][a[2]] > thre) A = 1; else A = 0;
 if (vox->dat[b[0]][b[1]][b[2]] > thre) B = 1; else B = 0;
 if (vox->dat[c[0]][c[1]][c[2]] > thre) C = 1; else C = 0;
 if (vox->dat[d[0]][d[1]][d[2]] > thre) D = 1; else D = 0;

 Nin = Nout = 0;
 if (A==1) {IN[Nin][0]  =a[0]; IN[Nin][1]  =a[1]; IN[Nin][2]  =a[2];  ++Nin;} 
      else {OUT[Nout][0]=a[0]; OUT[Nout][1]=a[1]; OUT[Nout][2]=a[2]; ++Nout;} 
 if (B==1) {IN[Nin][0]  =b[0]; IN[Nin][1]  =b[1]; IN[Nin][2]  =b[2];  ++Nin;} 
      else {OUT[Nout][0]=b[0]; OUT[Nout][1]=b[1]; OUT[Nout][2]=b[2]; ++Nout;} 
 if (C==1) {IN[Nin][0]  =c[0]; IN[Nin][1]  =c[1]; IN[Nin][2]  =c[2];  ++Nin;} 
      else {OUT[Nout][0]=c[0]; OUT[Nout][1]=c[1]; OUT[Nout][2]=c[2]; ++Nout;} 
 if (D==1) {IN[Nin][0]  =d[0]; IN[Nin][1]  =d[1]; IN[Nin][2]  =d[2];  ++Nin;} 
      else {OUT[Nout][0]=d[0]; OUT[Nout][1]=d[1]; OUT[Nout][2]=d[2]; ++Nout;} 

 /* Completely inside or completely outside */
 if ((Nin==0)||(Nin==4)) return(0);

 if (Nin==1)
 {
  pn=Find_Ver_Map(cur_x,Curr,Post,IN[0],OUT[0]); 
  if(pn==NULL) pn=Add_Pnt_to_Ver_Map(cur_x,IN[0],OUT[0],Vhead,vox,Curr,Post,thre); 
  
  qn=Find_Ver_Map(cur_x,Curr,Post,IN[0],OUT[1]); 
  if(qn==NULL) qn=Add_Pnt_to_Ver_Map(cur_x,IN[0],OUT[1],Vhead,vox,Curr,Post,thre); 
 
  rn=Find_Ver_Map(cur_x,Curr,Post,IN[0],OUT[2]); 
  if(rn==NULL) rn=Add_Pnt_to_Ver_Map(cur_x,IN[0],OUT[2],Vhead,vox,Curr,Post,thre); 

  Add_MC_Face_Stack(Fhead,pn,qn,rn,IN[0]);
 }

 else if (Nin==2)
 {
   pn=Find_Ver_Map(cur_x,Curr,Post,IN[0],OUT[0]); 
   if(pn==NULL) pn=Add_Pnt_to_Ver_Map(cur_x,IN[0],OUT[0],Vhead,vox,Curr,Post,thre); 
   qn=Find_Ver_Map(cur_x,Curr,Post,IN[0],OUT[1]); 
   if(qn==NULL) qn=Add_Pnt_to_Ver_Map(cur_x,IN[0],OUT[1],Vhead,vox,Curr,Post,thre); 
   rn=Find_Ver_Map(cur_x,Curr,Post,IN[1],OUT[0]); 
   if(rn==NULL) rn=Add_Pnt_to_Ver_Map(cur_x,IN[1],OUT[0],Vhead,vox,Curr,Post,thre); 
   sn=Find_Ver_Map(cur_x,Curr,Post,IN[1],OUT[1]); 
   if(sn==NULL) sn=Add_Pnt_to_Ver_Map(cur_x,IN[1],OUT[1],Vhead,vox,Curr,Post,thre); 
   
   Add_MC_Face_Stack(Fhead,pn,rn,qn,IN[0]);
   Add_MC_Face_Stack(Fhead,rn,qn,sn,IN[0]);
 }

 else if (Nin==3)
 {
   pn=Find_Ver_Map(cur_x,Curr,Post,IN[0],OUT[0]); 
   if(pn==NULL) pn=Add_Pnt_to_Ver_Map(cur_x,IN[0],OUT[0],Vhead,vox,Curr,Post,thre); 
   qn=Find_Ver_Map(cur_x,Curr,Post,IN[1],OUT[0]); 
   if(qn==NULL) qn=Add_Pnt_to_Ver_Map(cur_x,IN[1],OUT[0],Vhead,vox,Curr,Post,thre); 
   rn=Find_Ver_Map(cur_x,Curr,Post,IN[2],OUT[0]); 
   if(rn==NULL) rn=Add_Pnt_to_Ver_Map(cur_x,IN[2],OUT[0],Vhead,vox,Curr,Post,thre); 
   Add_MC_Face_Stack(Fhead,pn,qn,rn,IN[0]);
 }

} /* end of March_Tetrahedron() */ 




void Make_Mid_Point(m,a,b,vox,thre)
 float *m;
 int *a,*b;
 struct VOXEL *vox;
 float thre;
{
 float Va,Vb,Vc,Vd,r,rsimp;
 float ab[3],len;
 double A,B,C,det; 
 int diff[3],Ndiff;
 int c[3],d[3];
 float eps;

 eps = 0.01;
 
 /***********************/
 /*** [1] DECIDE 'r'  ***/
 /***********************/
 
 /** (H) HalfPoint Interpolation  **/
 if (MidPntType == 'H') r = 0.5;
 else  
 { 
  Va = vox->dat[a[0]][a[1]][a[2]];
  Vb = vox->dat[b[0]][b[1]][b[2]];
  rsimp = (thre - Va)/(Vb - Va); 
 } 
 
 /** (S) Simple Interpolation  **/
 if (MidPntType == 'S') r = rsimp;

 /** (C) Complicated Interpolation  **/
 if (MidPntType == 'C')
 {

 diff[0] = b[0] - a[0];
 diff[1] = b[1] - a[1];
 diff[2] = b[2] - a[2];
 
 Ndiff = 0;
 if (diff[0]!=0) ++Ndiff;
 if (diff[1]!=0) ++Ndiff;
 if (diff[2]!=0) ++Ndiff;

 if (Ndiff==1) r = rsimp; 
 
 /* for diagonal */
 if (Ndiff==2)
 {
  c[0] = a[0]; c[1] = a[1]; c[2] = a[2];
  d[0] = a[0]; d[1] = a[1]; d[2] = a[2];
  
  if (diff[0]==0) { c[1] += diff[1]; d[2] += diff[2]; } 
  if (diff[1]==0) { c[0] += diff[0]; d[2] += diff[2]; } 
  if (diff[2]==0) { c[0] += diff[0]; d[1] += diff[1]; } 

  Vc = vox->dat[c[0]][c[1]][c[2]];
  Vd = vox->dat[d[0]][d[1]][d[2]];

  A = Va + Vb - Vc - Vd;
  B = Vc - 2 *Va + Vd;
  C = Va - thre;
  
  if (A==0.0) r = rsimp;
  else 
  {
   det = (B*B-4*A*C);
   if (det>0.0) det = sqrt(det);
   r = (-B + det)/2.0/A; 
   if ((r<0.0)||(r>1.0)) r = (-B-det)/2.0/A;
   if ((r<0.0)||(r>1.0)) r = rsimp;
   } 
  }
 
 } /* 'C' */

 /*************************************/
 /*** [2] Decide midpoint using 'r' ***/
 /*************************************/


 if (r<0.0)
 {  if ((r+eps) <0.0) 
    {printf("#ERROR(MarCube):r %f is outof range (a %d %d %d %f b %d %d %d %f) rsimp %f\n",
      r,a[0],a[1],a[2],Va,b[0],b[1],b[2],Vb,rsimp); exit(1);}
   else r = 0.0; }

 if (r>1.0)
 { if ((r-eps) >1.0) 
    {printf("#ERROR(MarCube):r %f is outof range (a %d %d %d %f b %d %d %d %f) rsimp %f\n",
      r,a[0],a[1],a[2],Va,b[0],b[1],b[2],Vb,rsimp); exit(1);}
   else r = 1.0; }

 ab[0] = (float)b[0] - (float)a[0];
 ab[1] = (float)b[1] - (float)a[1];
 ab[2] = (float)b[2] - (float)a[2];
 
 m[0] = a[0] + r * ab[0];
 m[1] = a[1] + r * ab[1];
 m[2] = a[2] + r * ab[2];

} /* end of Make_Mid_Point() */





void Malloc_MIDMAP(M,Y,Z)
 struct MIDMAP *M;
 int Y,Z;
{
 int y,z;
 double Mbyte;
 M->Y = Y; M->Z = Z;

 /*
 Mbyte = (double)sizeof(struct MIDPNT)*Y*Z /1024.0/1024.0; 
 printf("#Malloc_MIDMAP(%d %d) %.2lf Mbyte\n",Y,Z,Mbyte);
 */
 
 M->map = (struct MIDPNT **)malloc(sizeof(struct MIDPNT *) * Y); 
 for (y=0;y<Y;++y)
   M->map[y] = (struct MIDPNT *)malloc(sizeof(struct MIDPNT) * Z); 
 
} /* end of Malloc_MIDMAP() */





void Reset_MIDMAP(M)
 struct MIDMAP *M;
{
 int y,z,i,j,k;
 
 for (y=0;y<M->Y;++y)
  for (z=0;z<M->Z;++z)
   for (i=0;i<3;++i) 
    for (j=0;j<3;++j) 
     for (k=0;k<3;++k) M->map[y][z].ver[i][j][k] = NULL;

} /* end of  Reset_MIDMAP() */




void Free_MIDMAP(M)
 struct MIDMAP *M;
{
  int y;

 for (y=0;y<M->Y;++y) free(M->map[y]);
 free(M->map);
 
} /* end of Free_MIDMAP() */





struct MC_VERTEX  *Add_Pnt_to_Ver_Map(cur_x,I,J,Vhead,vox,Curr,Post,thre)
 int    cur_x;
 int    I[3],J[3];
 struct MC_VERTEX *Vhead;
 struct VOXEL  *vox;
 struct MIDMAP *Curr,*Post;
 float  thre;
{
  struct MC_VERTEX *vn;
  float P[3]; 
  int i,d[3];

  Make_Mid_Point(P,I,J,vox,thre); 
  vn = Add_MC_Vertex_Stack(Vhead,P);

  for (i=0;i<3;++i) d[i] = J[i]-I[i]+1;
       if (I[0]==cur_x) Curr->map[I[1]][I[2]].ver[d[0]][d[1]][d[2]] = vn;
  else if (I[0]> cur_x) Post->map[I[1]][I[2]].ver[d[0]][d[1]][d[2]] = vn;
  
  for (i=0;i<3;++i) d[i] = I[i]-J[i]+1;
       if (J[0]==cur_x) Curr->map[J[1]][J[2]].ver[d[0]][d[1]][d[2]] = vn;
  else if (J[0]> cur_x) Post->map[J[1]][J[2]].ver[d[0]][d[1]][d[2]] = vn;

  return(vn);

} /* end of Add_Pnt_to_Ver_Map() */




struct MC_VERTEX *Find_Ver_Map(cur_x,Curr,Post,I,J)
 int cur_x;
 struct MIDMAP *Curr,*Post;
 int I[3],J[3]; 
{
 struct MIDPNT *mn;
 int i,d[3];

 for (i=0;i<3;++i) d[i] = J[i]-I[i]+1;
      if (I[0]==cur_x) return(Curr->map[I[1]][I[2]].ver[d[0]][d[1]][d[2]]); 
 else if (I[0]>cur_x)  return(Post->map[I[1]][I[2]].ver[d[0]][d[1]][d[2]]); 
 else return(NULL); 

} /* end of Find_Ver_Map() */




struct MC_VERTEX *Add_MC_Vertex_Stack(Vhead,f)
 struct MC_VERTEX *Vhead;
 float f[3];
{
 struct MC_VERTEX *newn;
 int i;

 newn = (struct MC_VERTEX*)malloc(sizeof(struct MC_VERTEX));
 newn->pos[0] = f[0]; 
 newn->pos[1] = f[1]; 
 newn->pos[2] = f[2]; 

 newn->next = Vhead->next;

 if (Vhead->next != NULL) 
  { newn->num = newn->next->num + 1; }
 else newn->num = 0;
 Vhead->next = newn;
 return(newn);

} /* end of Add_MC_Vertex_Stack() */ 



void Free_MC_Vertex_Stack(Vhead)
 struct MC_VERTEX *Vhead;
{
 struct MC_VERTEX *cur,*next;
 int i;

 cur = Vhead;
 next = cur->next;
 while (next != NULL)
 { cur = next;
   next = cur->next;
   free(cur); }

} /* end of Free_MC_Vertex_Stack() */ 





struct MC_FACE *Add_MC_Face_Stack(Fhead,an,bn,cn,in)
 struct MC_FACE *Fhead;
 struct MC_VERTEX *an,*bn,*cn;
 int in[3];       /* Inside Vertex */
{
 struct MC_FACE *newn;
 float norm[3],AB[3],AC[3],cross[3]; 
 int i;

 /* Malloc New Face Node */
 newn = (struct MC_FACE*)malloc(sizeof(struct MC_FACE));

 /*** Set Vertex a,b,c by proper order ***/

 Sub_Vec_FI(norm,an->pos,in);
 Sub_Vec_F(AB,bn->pos,an->pos);
 Sub_Vec_F(AC,cn->pos,an->pos);
 Cross_Prod_F(cross,AB,AC);
 if (Dot_Prod_F(norm,cross)>0.0)
 { newn->a = an; newn->b = bn; newn->c = cn;}
 else
 { newn->a = an; newn->b = cn; newn->c = bn;}

 newn->next = Fhead->next;
 Fhead->next = newn;

 return(newn);

} /* end of Add_MC_Face_Stack() */ 



void Free_MC_Face_Stack(Fhead)
 struct MC_FACE *Fhead;
{
 struct MC_FACE *cur,*next;
 int i;

 cur = Fhead;
 next = cur->next;

 while (next != NULL)
 { cur = next;
   next = cur->next;
   free(cur); }

} /* end of Free_MC_Face_Stack() */ 



void Sub_Vec_F(c,a,b)
 float c[3],a[3],b[3];
{ c[0] = a[0]-b[0];
  c[1] = a[1]-b[1];
  c[2] = a[2]-b[2]; }

void Sub_Vec_FI(c,a,b)
 float c[3],a[3];
 int b[3];
{ c[0] = a[0]-b[0];
  c[1] = a[1]-b[1];
  c[2] = a[2]-b[2]; }

void Cross_Prod_F(c,a,b)
 float c[3],a[3],b[3];
{ c[0] = a[1]*b[2] - a[2]*b[1];
  c[1] = a[2]*b[0] - a[0]*b[2];
  c[2] = a[0]*b[1] - a[1]*b[0]; }

float Dot_Prod_F(a,b)
 float a[3],b[3];
{ return(a[0]*b[0] + a[1]*b[1] + a[2]*b[2]); }


/*************************************************/
/*** FUNCTIONS FOR CALCULATING VOLUME AND AREA ***/
/*************************************************/

float Volume_Inside_Faces(gridlen,Vhead,Fhead)
 float  gridlen;
 struct MC_VERTEX *Vhead;
 struct MC_FACE   *Fhead;
{
 struct MC_VERTEX *vn;
 struct MC_FACE   *fn;
 float G[3],V,v;
 int Natom,i;
 /** Cal Gravity Center of Vertices**/
 G[0] = G[1] = G[2] = 0.0; Natom = 0;
 vn = Vhead;
 while (vn->next != NULL)
 {
  vn = vn->next;
  ++Natom;
  for (i=0;i<3;++i) G[i] += vn->pos[i];
  }

  for (i=0;i<3;++i) G[i] /= Natom;

 /** Cal Volume **/
 V = 0.0;
 fn = Fhead;
 while (fn->next != NULL)
 {
  fn = fn->next;
  v = VolumeTetrahedron(fn->a->pos,fn->b->pos,fn->c->pos,G);
  /* printf("v %f\n",v); */
  V += v;
 }

 V *= gridlen*gridlen*gridlen;

 return(V);

} /* end of Volume_Inside_Faces() */





float Area_Faces(gridlen,Fhead)
 float gridlen;
 struct MC_FACE   *Fhead;
{
 struct MC_FACE   *fn;
 int i;
 float X[3],Y[3],Z[3],S,DD,s;
 S = 0.0;

 fn = Fhead;
 while (fn->next != NULL)
 {
  fn = fn->next;
  for (i=0;i<3;++i)
   { X[i] = fn->a->pos[i] - fn->c->pos[i];
     Y[i] = fn->b->pos[i] - fn->c->pos[i];  }
 
  Z[0] = X[1]*Y[2] - X[2]*Y[1];
  Z[1] = X[2]*Y[0] - X[0]*Y[2];
  Z[2] = X[0]*Y[1] - X[1]*Y[0];

  DD = Z[0]*Z[0] + Z[1]*Z[1] + Z[2]*Z[2];
  if (DD>0.0) s = 0.5 * sqrt(DD); else s = 0.0;
  S += s;
  /* printf("s %f\n",s);  */
}

 S *= gridlen*gridlen;
 return(S);

} /* end of Area_Faces() */


float VolumeTetrahedron(a,b,c,x)
 float a[3],b[3],c[3],x[3];
 /*
 The order of a,b,c must be defined by counter-clockwise
 from the outside.

 if x is inside,  V is positive.
 if x is outside, V is negative.
 */
{
 float A[3],B[3],C[3],V;
 int i;

 for (i=0;i<3;++i)
 { A[i] = a[i] - x[i];
   B[i] = b[i] - x[i];
   C[i] = c[i] - x[i]; }

 V =   A[0]*B[1]*C[2] + A[1]*B[2]*C[0] + A[2]*B[0]*C[1]
     - A[2]*B[1]*C[0] - A[1]*B[0]*C[2] - A[0]*B[2]*C[1];

 return(V/6.0);

} /* end of Volume_Tetrahedron() */



/*************************************/
/*** FUNCTIONS FOR OUTPUT MC_FACES ***/
/*************************************/


void Output_MC_Faces_VRML(fname,Vhead,Fhead,vox,R,G,B,Trans,comment)
 char *fname;
 struct MC_VERTEX *Vhead;
 struct MC_FACE   *Fhead;
 struct VOXEL  *vox;
 float R,G,B,Trans;
 char  *comment;
{
 FILE *fp;
 struct MC_VERTEX *v;
 struct MC_FACE   *f;
 int Nver;

 if (fname[0]=='-') fp = stdout;
 else
 { fp = fopen(fname,"w");
   if (fp==NULL){printf("#ERROR:Can't write to vrmlfile \"%s\"\n",fname); exit(1);}
   printf("#Output_MC_Faces_VRML() --> \"%s\"\n",fname); 
 }

 Nver = Number_Of_MC_VERTEX(Vhead);
 
 /** Output Header ***/
 fprintf(fp,"#VRML V2.0 utf8\n");
 fprintf(fp,"#%s\n",fname);
 Output_Comment(fp,comment,"#[COMMENT]",100);

 fprintf(fp,"Shape{\n");
 fprintf(fp," appearance Appearance{\n");
 fprintf(fp," material Material{\n");
 fprintf(fp,"  diffuseColor %.1f %.1f %.1f\n",R,G,B);
 fprintf(fp,"  transparency %.1lf\n",Trans);
 fprintf(fp," }\n");
 fprintf(fp,"}\n");

/*** Output IndexedFaceSet ***/

/* Output Points (in stacked order (first in, last out) */
 fprintf(fp,"geometry IndexedFaceSet{\n");
 fprintf(fp," coord Coordinate{\n");
 fprintf(fp," point[\n");
 
 v = Vhead;
 while (v->next != NULL)
 {
  v = v->next;
  fprintf(fp,"%.3f %.3f %.3f",
        vox->min[0] + vox->gridlen*v->pos[0],
        vox->min[1] + vox->gridlen*v->pos[1],
        vox->min[2] + vox->gridlen*v->pos[2]);
  if (v->next != NULL) fprintf(fp,",");
  fprintf(fp,"\n");
 }
 fprintf(fp,"]}\n");
 
 /* Output MC_FACES  (Vertex nums are modified in the stacked order) */
 fprintf(fp,"  coordIndex[\n");
 f = Fhead;
 while (f->next != NULL)
 {
  f = f->next;
  fprintf(fp,"%d, %d, %d, -1", 
   Nver - f->a->num -1,
   Nver - f->b->num -1,
   Nver - f->c->num -1);
  if (f->next !=NULL) fprintf(fp,",");
  fprintf(fp,"\n");
 }
 fprintf(fp,"]\n");
 /* fprintf(fp,"solid FALSE\n"); */
 fprintf(fp,"}}\n");

 if (fp != stdout) fclose(fp);
} /* end of Output_MC_Faces_VRML() */





int Output_MC_Faces_PDB(fname,Vhead,Fhead,vox,comment)
 char *fname;
 struct MC_VERTEX *Vhead;
 struct MC_FACE   *Fhead;
 struct VOXEL  *vox;
 char *comment;
{
 FILE *fp;
 struct MC_VERTEX *v;
 struct MC_FACE   *f;
 struct CMATRIX Cmat;  /* Connection Matrix */
 int Nver,i,j,n,a,b,c,anum;
 int *Carray;
 char OutFace;
 
 /** [1] Open file **/
 if (fname[0]=='-') fp = stdout;
 else
 { fp = fopen(fname,"w");
   if (fp==NULL){printf("#ERROR:Can't write to surf_pdb file\"%s\"\n",fname); exit(1);}
   printf("#Output_MC_Faces_PDB() --> \"%s\"\n",fname); }

 /** [2] Output HEADER and REMARK **/ 
 fprintf(fp,"HEADER    Surface File by MarCube\n");
 Output_Comment(fp,comment,"REMARK  ",80);

 /** [3] Count Nvertex **/ 
 Nver = Number_Of_MC_VERTEX(Vhead);
 printf("#Nvertex %d\n",Nver);
 fprintf(fp,"REMARK  Nvertex %d\n",Nver);
 if (Nver >99999) 
 { printf("#WARNING(Output_MC_Faces_PDB)[%s]:Natom %d is too large for CONECT.\n",fname,Nver);
   fprintf(fp,"REMARK   #WARNING:Natom %d is too large for CONECT.\n",Nver);
   OutFace = 0;}
 else OutFace = 1;
 
 /* [4] Output Points (in the stacked order) as "ATOM" */

 v = Vhead;
 while (v->next != NULL)
 {
  v = v->next;
  anum = Nver - v->num-1;
  if (anum>99999) anum = anum % 100000;

  fprintf(fp,"ATOM  %5d %4s %3s %c%4d    %8.3f%8.3f%8.3f\n",
       anum ,"SUR","SUR",'X',anum/10,
       vox->min[0] + vox->gridlen*v->pos[0],
       vox->min[1] + vox->gridlen*v->pos[1],
       vox->min[2] + vox->gridlen*v->pos[2]);
 }

 if (OutFace == 1)
 {  
 /* [5] Output Faces as "CONECT" */

 /** (1) Malloc Camt and Carray **/

 Malloc_CMATRIX(&Cmat,Nver);
 Carray = (int *)malloc(sizeof(int)*Nver);
 for (i=0;i<Nver;++i)
  { Carray[i] = 0;
    for (j=0;j<Nver;++j) Cmat.m[i][j] = 0; }

 /** (2) Make Camt and Carray **/
 f = Fhead;
 while (f->next != NULL)
 {
  f = f->next;
  a = Nver - f->a->num - 1; 
  b = Nver - f->a->num - 1; 
  c = Nver - f->a->num - 1; 
  Cmat.m[a][b] = Cmat.m[b][a] = 1;
  Cmat.m[b][c] = Cmat.m[c][b] = 1;
  ++Carray[a]; ++Carray[b]; ++Carray[c];
 }

 /** (3) Output CONECT **/
 for (i=0;i<Nver;++i)
 {
  if (Carray[i]>0)
  { 
   fprintf(fp,"CONECT%5d",i);
   n = 0;
   for (j=0;j<Nver;++j) 
   { if (Cmat.m[i][j]==1) 
     { fprintf(fp,"%5d",j); ++n;
       if ((Carray[i]>n)&&((n%4)==0)) {fprintf(fp,"\nCONECT%5d",i);} 
      } 
     }    
    fprintf(fp,"\n"); 
   }
  }
 
 Free_CMATRIX(&Cmat);
 free(Carray);
 } 
 if (fp != stdout) fclose(fp);
 return(1);

} /* end of Output_MC_Faces_PDB() */



void Malloc_CMATRIX(M,Nmalloc)
 struct CMATRIX *M;
 int Nmalloc;
{
 int i;

 M->N = Nmalloc;
 M->m = (char **)malloc(sizeof(char*)*M->N);
 for (i=0;i<M->N;++i) M->m[i] = (char *)malloc(sizeof(char)*M->N);
} /* end of Malloc_CMATRIX() */


void Free_CMATRIX(M)
 struct CMATRIX *M;
{
 int i;
 for (i=0;i<M->N;++i) free(M->m[i]);
 free(M->m);

} /* end of Free_CMATRIX() */



int Number_Of_MC_VERTEX(Vhead)
 struct MC_VERTEX *Vhead;
{ int Nver;
  struct MC_VERTEX *v;

 Nver = 0;
 v = Vhead;
 while (v->next != NULL) {v = v->next; ++Nver;}
 return(Nver);
} /* end of Number_Of_MC_VERTEX() */

 
void Output_Comment(fp,comment,header,Nsymb_oneline)
 FILE *fp;
 char *comment,*header;
 int  Nsymb_oneline;  /* Number of symbol for one line */
{
 int Lcomment,i,j;
 
 Lcomment = strlen(comment);
 if (comment[Lcomment-1]=='\n') Lcomment -= 1;

 fprintf(fp,"%s ",header); 
 i = 0; j = 0;
 while (i<Lcomment)
 {
  if ((comment[i]=='\n')||(j==Nsymb_oneline)) 
   { fprintf(fp,"\n"); 
     if (i<Lcomment) fprintf(fp,"%s ",header); 
     j = 0;}
  if (comment[i]!='\n') { fprintf(fp,"%c",comment[i]);  ++j;}
  ++i;  
  }
 if (j>=0) fprintf(fp,"\n");

} /* end of Output_Comment() */
