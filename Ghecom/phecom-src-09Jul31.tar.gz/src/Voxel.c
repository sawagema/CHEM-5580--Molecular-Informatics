/*

 <Voxel.c> 

 coded by Takeshi Kawabata (takawaba@is.naist.jp)

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <strings.h>
#include "pdbstruct.h" 
#include "Voxel.h" 

/** Functions(GLOBAL) **/
void Cal_Size_Of_Voxel_By_Molecule();
void Malloc_Voxel();
void Cal_Voxel_Of_PDB();
void Write_Voxel_File();
void Free_Voxel();
void Cal_Density_Of_Molecule();

/** Functions(LOCAL) **/



void Cal_Size_Of_Voxel_By_Molecule(Ahead,Rprobe,gridlen,Min,Ngrid,MarkCare)
 struct ATOM *Ahead; 
 float  Rprobe,gridlen;
 float  Min[3];          /* Minimum Value  */
 int    Ngrid[3];            /* Number of Grid */
 char MarkCare; /* if 'T', only care atoms with mark == 1 */
{
 struct ATOM *an;
 float inf,minpos,maxpos,Rlarge;
 int i,Natom;
 float min[3],max[3],width[3];

 inf = 100000000.0;

 /** Cal Gcenter and ranges **/
 for (i=0;i<3;++i) { min[i] = inf; max[i] = -inf; }  
 Natom = 0;
 an = Ahead;
 while (an->next != NULL)
 {  
  an = an->next;
  if ((MarkCare!='T')||(an->mark==1))
  {
   ++Natom;
   
   Rlarge = (an->R + Rprobe) * 2;
   
   for (i=0;i<3;++i)
   { 
    minpos = an->Pos[i] - Rlarge;
    maxpos = an->Pos[i] + Rlarge;
    if (minpos < min[i]) min[i] = minpos;
    if (maxpos > max[i]) max[i] = maxpos;
   }
  } 
 } /* an */

 for (i=0;i<3;++i) 
 { width[i]  = max[i]-min[i]; 
   Ngrid[i]  = (int)ceil(width[i]/gridlen); 
   Min[i] = min[i];
   /* 
   printf("#[%d] min %f max %f\n",i,min[i],max[i]);
   */ 
 } 

} /* end of Cal_Size_Of_Voxel_By_Molecule() */





void Malloc_Voxel(vox,x,y,z)
 struct VOXEL *vox;
 int x,y,z;
{
 int i,j;
 double Nbyte;

 if ((x< 0)||(y<0)||(z<0))
 { printf("#ERROR(Malloc_Voxel):Improper Malloc number:x %d y %d z %d\n",x,y,z);
   exit(1); }

 Nbyte = (double)x*y*z*(double)sizeof(float); 

 /* printf("Nbyte %.2lf\n",Nbyte); */
 vox->dat = (float ***)malloc(sizeof(float **) * x);
 for (i=0;i<x;++i)
 {
  vox->dat[i] = (float **)malloc(sizeof(float *) * y);
  for (j=0;j<y;++j) 
   vox->dat[i][j] = (float *)malloc(sizeof(float) * z);
 }
 vox->mal = 1;

} /* end of Malloc_Voxel() */


void Free_Voxel(vox,x,y,z)
 struct VOXEL *vox;
 int x,y,z;
{
 int i,j;
 
 for (i=0;i<x;++i)
 {
  for (j=0;j<y;++j) free(vox->dat[i][j]);
  free(vox->dat[i]);
 }

 free(vox->dat);
 vox->mal = 0;

} /* end of Free_Voxel() */



void Cal_Voxel_Of_PDB(vox,Ahead)
 struct VOXEL *vox;
 struct ATOM  *Ahead;
{
 int i,j,k,x,y,z,m;
 struct ATOM *an,*bn;
 int minR[3],maxR[3];
 float Q[3],D[3],DD,R,RR;

 /**
 vox->dat[x][y][z] = 0 : Outside
                   = 1 : Inside 
                   = 2 : Surface Probe Region 
 **/

 for (x=0;x<vox->N[0];++x)
 for (y=0;y<vox->N[1];++y)
 for (z=0;z<vox->N[2];++z)  vox->dat[x][y][z] = 0;

 
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  R  = an->R; 
  RR = R * R;

  /* Cal min-max index for each atom */
  for (m=0;m<3;++m)
  { minR[m] = floor(((an->Pos[m] - R) - vox->min[m])/vox->gridlen);
    maxR[m] =  ceil(((an->Pos[m] + R) - vox->min[m])/vox->gridlen); 
    if (minR[m] < 0)          minR[m] = 0; 
    if (maxR[m] >= vox->N[m]) maxR[m] = vox->N[m] -1;  }

  for (x=minR[0];x<=maxR[0];++x)
  {
   Q[0] = vox->min[0] + vox->gridlen * x; 
   D[0] = Q[0] - an->Pos[0]; 
   for (y=minR[1];y<=maxR[1];++y)
   {
    Q[1] = vox->min[1] + vox->gridlen * y; 
    D[1] = Q[1] - an->Pos[1]; 
    for (z=minR[2];z<=maxR[2];++z)
    {
      Q[2] = vox->min[2] + vox->gridlen * z; 
      D[2] = Q[2] - an->Pos[2]; 
      DD = D[0]*D[0] + D[1]*D[1] + D[2]*D[2];
      if (DD <= RR) vox->dat[x][y][z] = 1;
     }
    }
  }
 
 
 } /* an */


} /* end of Cal_Voxel_Of_PDB() */




void Write_Voxel_File(vox,fname)
 struct VOXEL *vox;
 char *fname;
{
 FILE *fp; 
 int x,y,z;

 fp = fopen(fname,"w"); 
 if (fp==NULL) {printf("#ERROR:Can't write to \"%s\"\n",fname); exit(1);}
 printf("#Write_Voxel_File() -> \"%s\"\n",fname);
 fprintf(fp,"X %d\n",vox->N[0]);
 fprintf(fp,"Y %d\n",vox->N[1]);
 fprintf(fp,"Z %d\n",vox->N[2]);
 fprintf(fp,"GRIDLEN %f\n",vox->gridlen);
 fprintf(fp,"MINX %f\n",vox->min[0]);
 fprintf(fp,"MINY %f\n",vox->min[1]);
 fprintf(fp,"MINZ %f\n",vox->min[2]);
 for (x=0;x<vox->N[0];++x)
 {
  for (y=0;y<vox->N[1];++y)
  {
   for (z=0;z<vox->N[2];++z)
   {
    fprintf(fp,"%f\n",vox->dat[x][y][z]);
    }
    fprintf(fp,"\n"); 
   } 
  }
 fclose(fp);

} /* end of Write_Voxel_File() */





void Cal_Density_Of_Molecule(vox,Ahead,MarkCare)
 struct VOXEL *vox;
 struct ATOM  *Ahead;
 char MarkCare; /* if 'T', only care atoms with mark == 1 */
{
 int i,j,k,x,y,z,m;
 struct ATOM *an,*bn;
 int minR[3],maxR[3];
 float Q[3],D[3],DD,d,R,RR,Cutoff,Rc,RRc,logPhardsp,val;

 /** Initialize **/

 logPhardsp = log(PAR.Phardsp);
 /*
 printf("Phardsp %f log %f\n",PAR.Phardsp,logPhardsp);
 */

      if (PAR.SpType =='H') Cutoff = 1.0;
 else if (PAR.SpType =='G') Cutoff = 5.0;
 else if (PAR.SpType =='S') Cutoff = 3.0;
 else if (PAR.SpType =='s') Cutoff = 3.0;
 else Cutoff = 1.0;
 
 for (x=0;x<vox->N[0];++x)
 for (y=0;y<vox->N[1];++y)
 for (z=0;z<vox->N[2];++z)  vox->dat[x][y][z] = 0;

 an = Ahead;

 while (an->next != NULL)
 {
  an = an->next;

  if ((MarkCare != 'T')||(an->mark==1))
  {

  R  = an->R;
  RR = R * R;
  Rc = an->R*Cutoff;
  RRc = Rc*Rc;

  /* Cal min-max index for each atom */

  for (m=0;m<3;++m)
  { minR[m] = floor(((an->Pos[m] - Rc) - vox->min[m])/vox->gridlen);
    maxR[m] =  ceil(((an->Pos[m] + Rc) - vox->min[m])/vox->gridlen);
    if (minR[m] < 0)       minR[m] = 0;
    if (maxR[m] >= vox->N[m]) maxR[m] = vox->N[m] -1; }
 
  for (x=minR[0];x<=maxR[0];++x)
  {
   Q[0] = vox->min[0] + vox->gridlen * x;
   D[0] = Q[0] - an->Pos[0];
   for (y=minR[1];y<=maxR[1];++y)
   {
    Q[1] = vox->min[1] + vox->gridlen * y;
    D[1] = Q[1] - an->Pos[1];
    for (z=minR[2];z<=maxR[2];++z)
    {
      Q[2] = vox->min[2] + vox->gridlen * z;
      D[2] = Q[2] - an->Pos[2];
      DD = D[0]*D[0] + D[1]*D[1] + D[2]*D[2];
     
       if (DD <= RRc) 
       { 
        if (PAR.SpType == 'G') val = exp(DD/RR*logPhardsp);
        if (PAR.SpType == 'H') val = 1.0;
        if (PAR.SpType == 'S') 
          { d = sqrt(DD);
            val = 1.0/(1.0+exp(PAR.Asigmoid*(d-R))); }
        if (PAR.SumType == 'X')
         { if (val > vox->dat[x][y][z]) vox->dat[x][y][z] = val;  }
       else 
         { vox->dat[x][y][z] += val;  }
       }

     } /* z */
    } /* y */
  } /* x */
 
  } /* MarkCare */
 } /* an */

} /* end of Cal_Density_Of_Molecule() */




