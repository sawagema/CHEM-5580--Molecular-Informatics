/*

<SpheHull.c>
 
 for making 3D "Sphere Hull" of Spheres with different radius.

 coded by Takeshi Kawabata (takawaba@is.naist.jp) 

 "Convex Hull" : object covered by triangles
 "Sphere Hull" : object covered by concave spheres

 This is based on : 
  Joseph O'Rourke "Computational Geometry in C" (1998), 
   Second Edition,Cambridge.

 however, these functions do not use sturct EDGE.

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "pdbstruct.h" 
#include "SphePnt3.h" 
#include "SpheHull.h" 
#include "NeiNvec.h" 

/** FUNCTION (GLOBAL) **/
void Construct_Sphere_Hull();
int  Initial_Double_Triangle_SpheHull();
void Output_Faces_VRML_SpheHull();
int  Free_SH_FACEs();
void Make_Probe_Atoms_from_SH_FACE();
int Check_Crash_Bwn_Chains();
void Write_Tpnt_Face_PDB_File_SH_FACE();


/** FUNCTION (LOCAL) **/
static void Set_Surface_Atom_By_SH_FACE();
static int Add_One_Atom_To_SpheHull();
static char Collinear();
static struct SH_FACE* Make_SH_FACE();
static int VolSign_F_to_farthestP();
static int VolSign_X_ABC();
static void CleanFaces();
static void Make_CounterClockWise_By_Nvec();
static void Cross_Vec();
static float Dot_Prod();
static int Add_New_SH_FACE_By_Three_Atoms();
static void Add_New_SH_FACE_From_FacePointer();
static int Check_Face_For_Overlapped_With_Surface_Atom();
static int Check_Outside_From_Nvec_Atoms_Of_Face();
static void Sub_Vec();
static void Normalize();
static void Increment_Plus();
static void Show_Face_Info_DifSp();
static void Initialize_Mark();
static int Inside_Face_Sphere();
static struct SH_FACE *Check_Redundant_Face();
static struct ATOM *Move_This_Atom_To_End_Of_List();




void Construct_Sphere_Hull(Ahead,Fhead,Dmat,Rprobe)
 struct ATOM *Ahead;
 struct SH_FACE *Fhead;
 struct MATRIX *Dmat;
 float Rprobe;
{
 struct ATOM *an;
 struct SH_FACE *fn;
 struct SH_EDGE *Ehead;
 int  add_ok;

 printf("#Construct_Sphere_Hull(Rprobe %f)\n",Rprobe);
 Set_Surface_Atom_By_SH_FACE(Ahead,Fhead);
 Set_Nvec_to_Atoms_By_NEIGHBOR_ATOMS(Ahead);
 
 an = Ahead;
 while (an->next != NULL){
  an = an->next;
  if (PAR.Vtype == 'T') 
   {printf(">>>>an %s (%d) mark %d\n",an->Anum,an->num,an->mark);  fflush(stdout); }

  if (an->mark != 1){
    add_ok = Add_One_Atom_To_SpheHull(an,Ahead,Fhead,Dmat,Rprobe);
 
    /* an is "inside" or "isolated" from the Hull 
       an->mark :=2. Try an only once more later.
    */
    if ((add_ok==0)&&(an->mark==0)) 
     { an->mark = 2; an = Move_This_Atom_To_End_Of_List(an,Ahead);}

    else if ((add_ok==0)&&(an->mark==2)){ 
       an->mark = 2; 
       printf("#This Atom is  inside/isolated again !! ATOM %s %s %s %s\n",
       an->Anum,an->Atom,an->Resi,an->Rnum);
     }
    /* an is normally included in the the Hull */
    else{    
     an->mark = 1;
     Set_Surface_Atom_By_SH_FACE(Ahead,Fhead);
     Set_Nvec_to_Atoms_By_NEIGHBOR_ATOMS(Ahead);

     if (PAR.Vtype == 'T'){
        fn = Fhead;
        while (fn->next != NULL)
        { fn = fn->next;
          printf("#CURRENT_FACE(%s):%s %s %s\n",
           an->Anum, fn->atom[0]->Anum, fn->atom[1]->Anum, fn->atom[2]->Anum); }
      }
    }

  } /* an->mark != 1 */

 } /* an */
 
} /* end of Construct_Sphere_Hull() */




struct ATOM *Move_This_Atom_To_End_Of_List(an,Ahead)
 struct ATOM *an;
 struct ATOM *Ahead;
 /** Return previous atom pointer of an */
{
 struct ATOM *endatm,*prevatm;

 printf("#Move_This_Atom_To_End_Of_List() ATOM %s %s %s %s\n",
   an->Anum,an->Atom,an->Resi,an->Rnum);

 prevatm = an->prev; 
 
 /* (1) Find endatm */
 endatm = Ahead;
 while (endatm->next != NULL) {endatm = endatm->next;}

 if (an != endatm){
  /* (2) Modify prev and next of an  */
  if (an->prev != NULL) an->prev->next = an->next;
  if (an->next != NULL) an->next->prev = an->prev;

  /* (3) Modify next of endatm  */
  endatm->next = an;
  an->prev     = endatm;
  an->next = NULL;
 }

 /* (4) return an->prev */
 return(prevatm);

} /* Move_This_Atom_To_End_Of_List() */





void Set_Surface_Atom_By_SH_FACE(Ahead,Fhead)
 struct ATOM *Ahead;
 struct SH_FACE *Fhead;
{
 struct ATOM *an;
 struct SH_FACE *fn;
 int Natom,Nsurface;

 an = Ahead; Natom = 0;
 while (an->next != NULL) { an = an->next; an->surface = 0; ++Natom;}

 fn = Fhead;
 while (fn->next != NULL)
 {
  fn = fn->next;
  fn->atom[0]->surface =  fn->atom[1]->surface =  fn->atom[2]->surface = 1;
 } /* fn */

 an = Ahead; Nsurface = 0;
 while (an->next != NULL) 
  { an = an->next; 
    if (an->surface ==1) ++Nsurface; }

 if (PAR.Vtype == 'T')
  printf("#Natom %d Nsurface %d %.2f %%\n",Natom, Nsurface,100.0*Nsurface/Natom);


} /* end of Set_Surface_Atom_By_SH_FACE() */




int Add_One_Atom_To_SpheHull(p,Ahead,Fhead,Dmat,Rprobe)
 struct ATOM *p;    /* Atom to be added */
 struct ATOM *Ahead;
 struct SH_FACE *Fhead;
 struct MATRIX *Dmat;
 float Rprobe;
{
 struct ATOM *an;
 struct SH_FACE *f, *nf;
 struct SH_FACE NewFaceHead;
 int nnf;             /* Number of added face to the focused face f */
 int Nnewface;        /* Total number of added face about atom p and previous convex hull */
 int Nnewface_final;  /* Final Total number of added face after checking collision with other atoms */
 int i;
 char out[3];
 float Rprobe2,RpRatm0,RpRatm1,RpRatm2;

 if (PAR.Vtype == 'T')
 printf("#Add_One_Atom_To_SpheHull(one_atom[%d] %s %s %s %s)\n",
  p->num,p->Atom,p->Anum,p->Resi,p->Rnum); 

 Rprobe2 = 2.0 * Rprobe;


 /* (1) Mark faces visible from p */
 NewFaceHead.next = NULL; 
 
 f = Fhead; Nnewface =  Nnewface_final = 0;
 while (f->next != NULL){
  f = f->next;
  if (PAR.Vtype == 'T')  
  printf("####face[%d] %s %s %s\n", f->num,f->atom[0]->Anum,f->atom[1]->Anum,f->atom[2]->Anum);
 
  nnf = 0;

  RpRatm0 =  p->R + f->atom[0]->R + Rprobe2;
  RpRatm1 =  p->R + f->atom[1]->R + Rprobe2;
  RpRatm2 =  p->R + f->atom[2]->R + Rprobe2;

  /** [COLLISION] **/
  /*
   Atom p is inside of probe sphere of f.
   Making new three sp-triangles by p and atom[0],atom[1],atom[2] of f.
   f->visible set to 1. --> f is supposed to be deleted. 
  */
  if (Inside_Face_Sphere(f,p)==1)
  { 
  if (PAR.Vtype == 'T')  printf("##collision\n"); 

  if((Dmat->m[p->num][f->atom[0]->num]<=RpRatm0)&&(Dmat->m[p->num][f->atom[1]->num]<=RpRatm1)) 
    nnf += Add_New_SH_FACE_By_Three_Atoms(&NewFaceHead,p,f->atom[0],f->atom[1],Rprobe,'S');
 
  if((Dmat->m[p->num][f->atom[1]->num]<=RpRatm1)&&(Dmat->m[p->num][f->atom[2]->num]<=RpRatm2)) 
    nnf += Add_New_SH_FACE_By_Three_Atoms(&NewFaceHead,p,f->atom[1],f->atom[2],Rprobe,'S');
  
  if((Dmat->m[p->num][f->atom[2]->num]<=RpRatm2)&&(Dmat->m[p->num][f->atom[0]->num]<=RpRatm0)) 
    nnf += Add_New_SH_FACE_By_Three_Atoms(&NewFaceHead,p,f->atom[2],f->atom[0],Rprobe,'S');

   f->visible = 1; 
  }

 /** [VISIBLE]  **/
 /*
   Atom p is outside of probe sphere of f, but visible by f.
   Making new three sp-triangles by p and atom[0],atom[1],atom[2] of f for both side.
   f->visible is not set to 1. --> f is not supposed to be deleted. 
 */
 if ((nnf==0)&&(VolSign_F_to_farthestP(f,p)<0))
  {  
  if (PAR.Vtype == 'T') printf("##visible\n"); 
  
  if((Dmat->m[p->num][f->atom[0]->num]<=RpRatm0)&&(Dmat->m[p->num][f->atom[1]->num]<=RpRatm1)) 
    nnf += Add_New_SH_FACE_By_Three_Atoms(&NewFaceHead,p,f->atom[0],f->atom[1],Rprobe,'B');
 
  if((Dmat->m[p->num][f->atom[1]->num]<=RpRatm1)&&(Dmat->m[p->num][f->atom[2]->num]<=RpRatm2)) 
    nnf += Add_New_SH_FACE_By_Three_Atoms(&NewFaceHead,p,f->atom[1],f->atom[2],Rprobe,'B');
  
  if((Dmat->m[p->num][f->atom[2]->num]<=RpRatm2)&&(Dmat->m[p->num][f->atom[0]->num]<=RpRatm0)) 
    nnf += Add_New_SH_FACE_By_Three_Atoms(&NewFaceHead,p,f->atom[2],f->atom[0],Rprobe,'B');
  }


 /** [OUTSIDE]  **/
 /*
   Atom p is outside of probe sphere of f, but invisible by f.
   But, atom p is outside from nvec.
   Making new three sp-triangles by p and atom[0],atom[1],atom[2] of f including outside atom
   for both sides.
   f->visible is not set to 1. --> f is not supposed to be deleted. 
 */
 
 if ((nnf==0)&&(Check_Outside_From_Nvec_Atoms_Of_Face(f,p,out)>0)){
  if (PAR.Vtype == 'T') printf("##outside\n"); 
    if (((out[0]==1)||(out[1]==1))  &&
        (Dmat->m[p->num][f->atom[0]->num]<=RpRatm0)&&(Dmat->m[p->num][f->atom[1]->num]<=RpRatm1) ) 
      nnf += Add_New_SH_FACE_By_Three_Atoms(&NewFaceHead,p,f->atom[0],f->atom[1],Rprobe,'b');

    if (((out[1]==1)||(out[2]==1))  &&
        (Dmat->m[p->num][f->atom[1]->num]<=RpRatm1)&&(Dmat->m[p->num][f->atom[2]->num]<=RpRatm2) ) 
    nnf += Add_New_SH_FACE_By_Three_Atoms(&NewFaceHead,p,f->atom[1],f->atom[2],Rprobe,'b');
       
    if (((out[2]==1)||(out[0]==1))  &&
        (Dmat->m[p->num][f->atom[2]->num]<=RpRatm2)&&(Dmat->m[p->num][f->atom[0]->num]<=RpRatm0) ) 
    nnf += Add_New_SH_FACE_By_Three_Atoms(&NewFaceHead,p,f->atom[2],f->atom[0],Rprobe,'b');
  }

  Nnewface += nnf; 
 
 } /* f */


 /* (2) If no new faces are made by p, then p is "INSIDE" or "ISOLATED" from the hull. */

 if (Nnewface == 0)
  { printf("##atom[%s] is inside/isolated from the hull\n",p->Anum);  
    if (PAR.Vtype=='T') printf("#Nnewface %d Nnewface_final %d\n",Nnewface,Nnewface_final);
    return(0); }

 /* (3) Checking visiblity of  newfaces from previous convex-hull vertex atoms  */
 nf = &NewFaceHead;
 while (nf->next != NULL){
  nf = nf->next;
  if (Check_Face_For_Overlapped_With_Surface_Atom(Ahead,nf)==0) 
   { Add_New_SH_FACE_From_FacePointer(Fhead,nf);
     ++Nnewface_final;} 
 } /* nf */

 if (PAR.Vtype=='T') printf("#Nnewface %d Nnewface_final %d\n",Nnewface,Nnewface_final);
 
 CleanFaces(Fhead);
 Free_SH_FACEs(&NewFaceHead);
 return(1);

} /* end of Add_One_Atom_To_SpheHull() */





int Check_Face_For_Overlapped_With_Surface_Atom(Ahead,nf)
 struct ATOM *Ahead;
 struct SH_FACE *nf;
{
 struct ATOM *an,*fl,*ma;
 int spin,inside;

 /*
 printf("#Check_Face_For_Overlapped_With_Surface_Atom(face %d %s %s %s)\n",
  nf->num, nf->atom[0]->Anum, nf->atom[1]->Anum, nf->atom[2]->Anum);
 */

 inside = 0;
 an = Ahead;
 while (an->next != NULL){
  an = an->next;
  if ( (an->surface==1) 
       && (nf->atom[0]->num != an->num)
       && (nf->atom[1]->num != an->num)
       && (nf->atom[2]->num != an->num) ) 
 { spin  = Inside_Face_Sphere(nf,an);
   if (spin==1)  return(1);  }

 } /* an */

 return(0);
 
} /* end of Check_Face_For_Overlapped_With_Surface_Atoms() */







void CleanFaces(Fhead)
 struct SH_FACE *Fhead;
{
 struct SH_FACE *f,*df;
 int Nall,Ndelete;

 /* Delete the face f if f->visible = 1 */

 f = Fhead; Nall =  Ndelete = 0;
 while (f->next != NULL)
 {
   f = f->next;
  
   /* Deleting f */
   if (f->visible==1)
   {
/*
   printf("#DELETE f %d a0 %s a1 %s a2 %s visible %d\n",
   f->num,f->atom[0]->Anum, f->atom[1]->Anum, f->atom[2]->Anum,f->visible); 
*/
   
   ++Nall;
     df = f;
     f->prev->next = f->next;
     if (f->next != NULL) f->next->prev = f->prev;
     f = f->prev;    
     free(df); 
     ++Ndelete; 
   }
 } 

 /*
 printf("#CleanFaces() --> delete %d faces from %d faces\n",Ndelete,Nall);
 */

} /* end of CleanFaces() */






int Initial_Double_Triangle_SpheHull(Ahead,Fhead,Dmat,Rprobe)
 struct ATOM  *Ahead;  
 struct SH_FACE  *Fhead;
 struct MATRIX *Dmat;
 float  Rprobe;
{
 struct ATOM *an,*bn,*cn;
 struct SH_FACE *f[2]; 
 char find;
 float Nv[2][3],pos[3],Cpos[2][3];
 int spok,i,j,k;

 printf("#Initial_Double_Triangle_SpheHull()\n");
 Fhead->num = -1;
 Fhead->next = NULL; 

 /** (0) Initialize mark of atom to 0 **/
 an = Ahead;
 while (an->next != NULL)
 { an = an->next;
   an->mark = 0; }

 /** (1) Find three non-collinear atoms **/
 an = Ahead; find = 0;
 while ((an->next != NULL)&&(find==0)){
   an = an->next;
   
   if ((an->next != NULL)&&(an->next->next != NULL)){
    bn = an->next;
    cn = an->next->next;
    if ( (Collinear(an->Pos,bn->Pos,cn->Pos)==0) && 
         (Dmat->m[an->num][bn->num] <= an->R  + bn->R  + 2*Rprobe) &&
         (Dmat->m[an->num][cn->num] <= an->R  + cn->R  + 2*Rprobe) &&
         (Dmat->m[bn->num][cn->num] <= bn->R  + cn->R  + 2*Rprobe) ) 
     { spok = Cal_Sphere_On_Three_Atoms(Cpos[0],Cpos[1],Rprobe,an,bn,cn);
       printf("#try %d %d %d spok %d\n",an->num,bn->num,cn->num,spok);
       if (spok==1) find = 1; }
   }
 } /* while */
  
 if (find==0) 
  { printf("#ERROR:all points are collinear.\n"); 
    exit(1); }

 printf("#>>Initial Three Atoms<<\n");
 printf("#an %d %s %s %s\n",an->num,an->Atom,an->Resi,an->Rnum);
 printf("#bn %d %s %s %s\n",bn->num,bn->Atom,bn->Resi,bn->Rnum);
 printf("#cn %d %s %s %s\n",cn->num,cn->Atom,cn->Resi,cn->Rnum);

 /** (2) Mark the atoms as processed **/
 an->mark = 1; bn->mark = 1; cn->mark = 1; 

 /** (3) Making Face f[0] and f[1] **/

 for (i=0;i<2;++i){
  f[i] = Make_SH_FACE(Fhead,an,bn,cn,Cpos[i],Rprobe,'I');
  Make_CounterClockWise_By_Nvec(f[i],f[i]->nvec);
 }

 return(1);

} /* end of  int Initial_Double_Triangle_SpheHull() */





char Collinear(a,b,c)
 float a[3],b[3],c[3];
{
 float crs[3];

 /* crs = (b-a) x (c-a) */

 crs[0] = (b[1]-a[1])*(c[2]-a[2]) - (b[2]-a[2])*(c[1]-a[1]);
 crs[1] = (b[2]-a[2])*(c[0]-a[0]) - (b[0]-a[0])*(c[2]-a[2]);
 crs[2] = (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0]);

 /*
 printf("a   %f %f %f\n",a[0],a[1],a[2]);
 printf("b   %f %f %f\n",b[0],b[1],b[2]);
 printf("c   %f %f %f\n",c[0],c[1],c[2]);
 printf("crs %f %f %f\n",crs[0],crs[1],crs[2]);
 */

 if ((fabs(crs[0])<PAR.eps)&&(fabs(crs[1])<PAR.eps)&&(fabs(crs[2]<PAR.eps))) 
   return(1); else return(0); 

} /* end of Collinear() */






void Add_New_SH_FACE_From_FacePointer(Fhead,face)
 struct SH_FACE *Fhead;
 struct SH_FACE *face;
{
 struct SH_FACE *f,*nf;
 int i,j;
 float norm;

 /* >> Add new face on Fhead in stacking way << */
 nf = (struct SH_FACE*)malloc(sizeof(struct SH_FACE));
 f = Fhead->next;
 Fhead->next = nf;
 nf->next = f;
 nf->prev = Fhead;
 if (f != NULL) { f->prev = nf; nf->num = f->num + 1; } else nf->num = 0;

 nf->atom[0] = face->atom[0]; 
 nf->atom[1] = face->atom[1]; 
 nf->atom[2] = face->atom[2]; 

 nf->R  = face->R;
 nf->RR = face->RR;

 for (i=0;i<3;++i) nf->nvec[i] = face->nvec[i];
 for (i=0;i<3;++i) nf->Cen[i]  = face->Cen[i];

 norm = face->nvec[0]* face->nvec[0] + face->nvec[1]* face->nvec[1] +
        face->nvec[2]* face->nvec[2];

 if (norm <= 0.0)
 { printf("#WOOPS1 norm nvec is zero (%f %f %f)\n",
   face->nvec[0], face->nvec[1], face->nvec[2]); } 

 for (i=0;i<3;++i)
  for (j=0;j<3;++j) nf->tpnt[i][j] = face->tpnt[i][j];

 nf->visible = 0;
 nf->type = face->type;

} /* end of Add_NewFace_By_FacePointer() */





int Add_New_SH_FACE_By_Three_Atoms(Fhead,a0,a1,a2,Rprobe,Type)
 struct SH_FACE *Fhead;
 struct ATOM *a0,*a1,*a2;
 float  Rprobe; 
 char   Type; /* 'S'ingle side, 'B'oth or 'b'oth side */
{
 struct SH_FACE *nf,*rf0,*rf1;
 int i,k,spok,Nadd;
 float Cpos[2][3]   ; /* Center of Sphere Probe */
 float Nv[2][3];      /* Normal Vector */
 int  vsign0;

 /*

  Basically, two kinds of probe sphere can contact to a0, a1, a2. 

 [Type == 'S'ingle]  
   
  Choose the sphere which locate the outside of the face a0-a1-a2.
   a0-a1-a2 are considered as placing in counter clockwise way from outside
         a0
        /  |     nvec = (a1-a0) x (a2-a0)
      /    |
     a1---a2

 [Type == 'B'oth or 'b'oth]  

  Add both one.  If nvec is not directed to center of probes,
  change the order of atoms (a0,a1,a2) --> (a0, a2, a1).

  For this case, redundancy check is necessary.
 
 */


  spok = Cal_Sphere_On_Three_Atoms(Cpos[0],Cpos[1],Rprobe,a0,a1,a2);

 if (spok != 1){
 /*
    printf("#WARNING:atom(%s %s %s) spok %d\n",
    a0->Anum,a1->Anum,a2->Anum,spok);  
 */ 
  return(0);}

 Nadd = 0;
 vsign0 = VolSign_X_ABC(Cpos[0],a0->Pos,a1->Pos,a2->Pos);
 rf0 = Check_Redundant_Face(Fhead,a0,a1,a2);
 rf1 = Check_Redundant_Face(Fhead,a0,a2,a1);

 /** 'S'ingle probe sphre is accepted **/
 if (Type == 'S')
 {
  if (vsign0<0) 
  { 
   if (rf0==NULL)
   { nf = Make_SH_FACE(Fhead,a0,a1,a2,Cpos[0],Rprobe,Type); ++Nadd; } 
  }
  else 
  { 
   if (rf1==NULL)
   {nf = Make_SH_FACE(Fhead,a0,a1,a2,Cpos[1],Rprobe,Type); ++Nadd; } 
  }
 }


 /** 'B'oth probe sphre are accepted **/

 if ((Type == 'B')||(Type == 'b')){
/*
  if (rf0!=NULL) printf("#REDUNDANT!! %s %s %s\n",a0->Anum,a1->Anum,a2->Anum);
  if (rf1!=NULL) printf("#REDUNDANT!! %s %s %s\n",a0->Anum,a2->Anum,a1->Anum);
*/
  if (vsign0<0)
   {
    if (rf0==NULL) 
    { nf = Make_SH_FACE(Fhead,a0,a1,a2,Cpos[0],Rprobe,Type); ++Nadd;} 
    if (rf1==NULL) 
    { nf = Make_SH_FACE(Fhead,a0,a2,a1,Cpos[1],Rprobe,Type); ++Nadd;} 
   }
  else{
   if (rf0==NULL) 
    { nf = Make_SH_FACE(Fhead,a0,a1,a2,Cpos[1],Rprobe,Type); ++Nadd; } 
   if (rf1==NULL) 
    { nf = Make_SH_FACE(Fhead,a0,a2,a1,Cpos[0],Rprobe,Type); ++Nadd; } 
   } 
 }


 /*
 if (Nadd==0)
  {printf("#WARNING:Both Spheres are not satisfied.\n"); } 
 */

 if (PAR.Vtype == 'T')
 printf("#Add_New_SH_FACE_By_Three_Atoms(a0 %s a1 %s a2 %s) Nadd %d\n",
   a0->Anum, a1->Anum, a2->Anum,Nadd);
 
 return(Nadd);
 
} /* end of Add_New_SH_FACE_By_Three_Atoms() */





struct SH_FACE *Make_SH_FACE(Fhead,a0,a1,a2,Cen,Rprobe,type)
 struct SH_FACE *Fhead;
 struct ATOM *a0,*a1,*a2;
 float Cen[3];  /* Center of Sphere  */
 float Rprobe;  /* Radius for Sphere */
 char  type;
{
 struct SH_FACE *f,*nf;
 int i,j;
 float Vx[3], Vy[3],A0toC[3];

 /*
 printf("#Make_SH_FACE[%s %s %s]-->(%f %f %f) Rprobe %f type %c\n",
  a0->Anum,a1->Anum,a2->Anum,Cen[0],Cen[1],Cen[2],Rprobe,type);
 */

/* >> Add new face on Fhead in stacking way << */
 nf = (struct SH_FACE*)malloc(sizeof(struct SH_FACE));
 f = Fhead->next;
 Fhead->next = nf;
 nf->next = f; 
 nf->prev = Fhead;
 if (f != NULL) { f->prev = nf; nf->num = f->num + 1; } else nf->num = 0;
 nf->atom[0] = a0; nf->atom[1] = a1; nf->atom[2] = a2;

 for (i=0;i<3;++i) nf->nvec[i] =  0.0;

 nf->visible = 0;
 nf->R  = Rprobe;
 nf->RR = Rprobe*Rprobe;
 for (j=0;j<3;++j) nf->Cen[j] = Cen[j];

 for (j=0;j<3;++j) 
  nf->tpnt[0][j] = a0->Pos[j] + a0->R*(Cen[j] - a0->Pos[j])/(Rprobe + a0->R);
 
 for (j=0;j<3;++j) 
  nf->tpnt[1][j] = a1->Pos[j] + a1->R*(Cen[j] - a1->Pos[j])/(Rprobe + a1->R);
 
 for (j=0;j<3;++j) 
  nf->tpnt[2][j] = a2->Pos[j] + a2->R*(Cen[j] - a2->Pos[j])/(Rprobe + a2->R);

 for (j=0;j<3;++j) A0toC[j] = Cen[j] - a0->Pos[j];

 for (j=0;j<3;++j)  Vx[j] = nf->tpnt[1][j] - nf->tpnt[0][j];
 for (j=0;j<3;++j)  Vy[j] = nf->tpnt[2][j] - nf->tpnt[0][j];
 
 Cross_Vec(nf->nvec,Vx,Vy);
 Normalize(nf->nvec);
 if (Dot_Prod(nf->nvec,A0toC)<0) { for (j=0;j<3;++j) nf->nvec[j] *= -1.0; } 
 /*
 printf("#nvec %f %f %f\n",nf->nvec[0],nf->nvec[1],nf->nvec[2]);
 */ 

 nf->type = type;
 return(nf);

} /* end of Make_SH_FACE() */








void Show_Face_Info_DifSp(Fhead)
 struct SH_FACE *Fhead;
{
 struct SH_FACE *fn;
 int i;
 float norm;
 fn = Fhead;
 
 printf("#Show_Face_Info_DifSp()\n");
 while (fn->next != NULL)
 {
   fn = fn->next;
   printf("face[%d] atom ", fn->num);
   for (i=0;i<3;++i)
    if (fn->atom[i]!=NULL) printf(" %s",fn->atom[i]->Anum); else printf(" null");
   norm = fn->nvec[0] * fn->nvec[0] +
          fn->nvec[1] * fn->nvec[1] +
          fn->nvec[2] * fn->nvec[2];
   printf(" nvec %f %f %f norm %f",fn->nvec[0],fn->nvec[1],fn->nvec[2],norm); 
   printf(" visible %d", fn->visible);
   printf("\n");
  }

} /* end of Show_Face_Info_DifSp() */





int VolSign_F_to_farthestP(f,p)
 struct SH_FACE *f;
 struct ATOM *p;
{
 /* If the atom p is visible from the face f, this returns negative
    sign of volume.  
    
    The face is defined by three tangent points (tpnt[3][3]).  */

 float vol;
 float ax,ay,az,bx,by,bz,cx,cy,cz;
 float X[3]; /* Farthest Point on ATOM p in Nvec direction of FACE f */ 
 
 X[0] = p->Pos[0] + p->R * f->nvec[0];
 X[1] = p->Pos[1] + p->R * f->nvec[1];
 X[2] = p->Pos[2] + p->R * f->nvec[2];

 ax = f->tpnt[0][0] - X[0];
 ay = f->tpnt[0][1] - X[1];
 az = f->tpnt[0][2] - X[2];

 bx = f->tpnt[1][0] - X[0];
 by = f->tpnt[1][1] - X[1];
 bz = f->tpnt[1][2] - X[2];

 cx = f->tpnt[2][0] - X[0];
 cy = f->tpnt[2][1] - X[1];
 cz = f->tpnt[2][2] - X[2];

 vol =  ax * (by*cz - bz*cy)
      + ay * (bz*cx - bx*cz)
      + az * (bx*cy - by*cx);

 /* printf("vol %f\n",vol);  */

      if (vol >  PAR.eps) return(1);
 else if (vol < -PAR.eps) return(-1);
 else return(0);

} /* end of VolSign_F_to_farthestP() */



int VolSign_X_ABC(X,A,B,C)
 float X[3],A[3],B[3],C[3];
{
 /* If the atom p is visible from the face ABC, this returns negative
    sign of volume. */  
    
 float vol;
 float ax,ay,az,bx,by,bz,cx,cy,cz;
 

 ax = A[0] - X[0];
 ay = A[1] - X[1];
 az = A[2] - X[2];

 bx = B[0] - X[0];
 by = B[1] - X[1];
 bz = B[2] - X[2];

 cx = C[0] - X[0];
 cy = C[1] - X[1];
 cz = C[2] - X[2];

 vol =  ax * (by*cz - bz*cy)
      + ay * (bz*cx - bx*cz)
      + az * (bx*cy - by*cx);

 /* printf("vol %f\n",vol);  */

      if (vol >  PAR.eps) return(1);
 else if (vol < -PAR.eps) return(-1);
 else return(0);

} /* end of VolSign_F_to_farthestP() */




int Inside_Face_Sphere(f,p)
 struct SH_FACE *f;
 struct ATOM *p;
{
 float X[3],D;

 X[0] = p->Pos[0] - f->Cen[0];
 X[1] = p->Pos[1] - f->Cen[1];
 X[2] = p->Pos[2] - f->Cen[2];

 D = X[0]*X[0] + X[1]*X[1] + X[2]*X[2]; 
 if (D > 0) D = sqrt(D); 
 if (D < (f->R + p->R)) 
 {
   /* printf("#COLLISION D %f f->R + p->R %f\n",D,f->R+p->R);  */ 
   return(1); 
 }
 else return(0);


} /* end of Inside_Face_Sphere() */






int Check_Outside_From_Nvec_Atoms_Of_Face(f,p,outside)
 struct SH_FACE *f;
 struct ATOM *p;
 char outside[3];   /* if outside[i] = 1, atom[i] is outside. otherwise inside */  
{
 int i,nout;
 float PX[3],dotprod;

/*
 printf("#Check_Outside_From_Nvec_Atoms_Of_Face(for %s by %s %s %s)\n",
  p->Anum,f->atom[0]->Anum,f->atom[1]->Anum,f->atom[2]->Anum);
*/
 
 nout = 0;
 for (i=0;i<3;++i)
 {
  Sub_Vec(PX,p->Pos,f->atom[i]->Pos); 
  dotprod = Dot_Prod(f->atom[i]->nvec,PX);
  if (dotprod>0.0) 
  { outside[i] = 1; ++nout;
 /*
    printf("#Check_Outside_From_Nvec_Atoms_Of_Face(for %s by %s %s %s)\n",
    p->Anum,f->atom[0]->Anum,f->atom[1]->Anum,f->atom[2]->Anum);
    printf("atom %s dotprod %f\n", f->atom[i]->Anum,dotprod); 
*/
    } 
  else outside[i] = 0; 
  }

 return(nout);

} /* end of Check_Outside_From_Nvec_Atoms_Of_Face() */




void Output_Faces_VRML_SpheHull(fname,Fhead)
 char *fname;
 struct SH_FACE *Fhead; 
{
 FILE *fp;
 struct SH_FACE *f; 
 int Nver;
 
 if (fname[0]=='-') fp = stdout;
 else 
 { fp = fopen(fname,"w");
   printf("#Output_Faces_VRML_SpheHull()-->\"%s\"\n",fname);
   if (fp==NULL){printf("#ERROR:Can't write to \"%s\"\n",fname); exit(1);}
 }
/** Output Header ***/
 fprintf(fp,"#VRML V2.0 utf8\n");
 fprintf(fp,"#%s\n",fname);
 fprintf(fp,"Shape{\n");
 fprintf(fp," appearance Appearance{\n");
 fprintf(fp," material Material{\n");
 fprintf(fp," diffuseColor 0.7 1.0 0.7\n");
 fprintf(fp,"  transparency 0.5\n");
 fprintf(fp,"}\n");
 fprintf(fp,"}\n");

 /** Output IndexedFaceSet ***/

 /* Points */
 fprintf(fp,"geometry IndexedFaceSet{\n");
 fprintf(fp," coord Coordinate{\n");
 fprintf(fp," point[\n");
 f = Fhead;
 while (f->next != NULL)
  {
   f = f->next;
   fprintf(fp,"%f %f %f,\n",f->tpnt[0][0],f->tpnt[0][1],f->tpnt[0][2]);
   fprintf(fp,"%f %f %f,\n",f->tpnt[1][0],f->tpnt[1][1],f->tpnt[1][2]);
   fprintf(fp,"%f %f %f",   f->tpnt[2][0],f->tpnt[2][1],f->tpnt[2][2]);
   if (f->next != NULL) fprintf(fp,",\n"); else fprintf(fp,"\n");
  }

 fprintf(fp,"]}\n");

 /* Faces */
 Nver = 0; 
 fprintf(fp,"  coordIndex[\n");
 f = Fhead;
 if (f != NULL)
 while (f->next != NULL) 
 {
  f = f->next;
  fprintf(fp,"%d, %d, %d, -1,\n", Nver, Nver+1, Nver+2);
  Nver += 3; 
 }
 fprintf(fp,"]\n");
 fprintf(fp,"solid FALSE\n");
 fprintf(fp,"}}\n");

 if (fp != stdout) fclose(fp);

} /* end of Output_Faces_VRML_SpheHull() */








void Make_CounterClockWise_By_Nvec(f,nvec)
 struct SH_FACE *f;
 float  nvec[3];  /* Normal Vector */
{
 int    i;
 float Vx[3],Vy[3],Vz[3],dprod,buf_pos[3]; 
 struct ATOM *buf_atm; 
 /*
 if CounterClockWise
      t0 
    /  |
  t1--t2   (t0->t1) x (t0->t2) is the direction of nvec

 */

 /*
 printf("#Make_CounterClockWise_By_Nvec(f[%d])\n",f->num);
 printf("#%s %s %s ->",
 f->atom[0]->Anum,f->atom[1]->Anum,f->atom[2]->Anum);
 */

 for (i=0;i<3;++i) Vx[i] = f->tpnt[1][i] - f->tpnt[0][i]; 
 for (i=0;i<3;++i) Vy[i] = f->tpnt[2][i] - f->tpnt[0][i]; 
 
 Cross_Vec(Vz,Vx,Vy);
 dprod = Dot_Prod(nvec,Vz);
 
 if (dprod<0) 
 { 
   buf_atm = f->atom[1]; 
   f->atom[1] = f->atom[2];
   f->atom[2] = buf_atm; 
   for (i=0;i<3;++i) buf_pos[i] = f->tpnt[1][i]; 
   for (i=0;i<3;++i) f->tpnt[1][i] = f->tpnt[2][i]; 
   for (i=0;i<3;++i) f->tpnt[2][i] = buf_pos[i]; 
 }

 /*
 printf("%s %s %s\n",
 f->atom[0]->Anum,f->atom[1]->Anum,f->atom[2]->Anum);
 */

} /* end of Make_CounterClockWise_By_Nvec() */




void Cross_Vec(C,A,B)   /* This function is only for 3-D */
 float C[3],A[3],B[3];
{ C[0] = A[1]*B[2] - A[2]*B[1];
  C[1] = A[2]*B[0] - A[0]*B[2];
  C[2] = A[0]*B[1] - A[1]*B[0]; }


float Dot_Prod(A,B)
 float *A,*B;
{ int i;
  float prod;
  prod = 0.0;
  for (i=0;i<3;++i) prod += A[i]*B[i];
  return(prod); 
} /* end of Dot_Prod() */





int Free_SH_FACEs(Fhead)
 struct SH_FACE *Fhead;
{
 struct SH_FACE *f,*pf;
 int Nfree;

 /* 
 printf("#Free_SH_FACEs(Fhead)\n"); fflush(stdout);
 */ 
 if (Fhead->next == NULL) return(0); 

 f = Fhead; pf = NULL; Nfree = 0;
 while (f->next != NULL)
  {
   pf = f; 
   f = f->next;
   /* printf("fnum %d\n",f->num); fflush(stdout); */
   if ((pf != Fhead)&&(pf != NULL)) { free(pf); pf = NULL; ++Nfree;}
  }

 if (f!=NULL) { free(f); f = NULL; ++Nfree;}
 Fhead->next = NULL;
 return(Nfree);

} /* end of Free_SH_FACEs() */



void Initialize_Mark(Ahead)
 struct ATOM *Ahead;
{
 struct ATOM *an;

 an = Ahead; 
 while (an->next != NULL) 
  { an = an->next; 
    an->mark = 0; }

} /* end of Set_Mark_Zero() */






void Sub_Vec(C,A,B)
 float C[3],A[3],B[3];
{  C[0] = A[0]-B[0]; 
   C[1] = A[1]-B[1];
   C[2] = A[2]-B[2];
} /* end of Sub_Vec(A,B) */



void Normalize(A)
 float A[3];
{  float dis;
  dis = A[0]*A[0] + A[1]*A[1] + A[2]*A[2];
  if (dis>0.0)
   { dis = sqrt(dis);
     A[0] /= dis; A[1] /= dis; A[2] /= dis; }
} /* end Normalize() */


void Increment_Plus(A,B)
 float A[3],B[3];
{ A[0] += B[0];
  A[1] += B[1];
  A[2] += B[2];
} /* end of Increment_Plus() */




void Make_Probe_Atoms_from_SH_FACE(Ahead,Fhead)
 struct ATOM    *Ahead;
 struct SH_FACE *Fhead;
{
 struct ATOM    *an;
 struct SH_FACE *fn;
 int Natom;

 Ahead->next = NULL;
 fn = Fhead;
 an = Ahead;
 Natom = 0;
 while (fn->next != NULL)
 {
  fn = fn->next;
  ++Natom;
  an->next = (struct ATOM *)malloc(sizeof(struct ATOM));
  an->next->prev = an;
  an->next->next = NULL;
  an = an->next;

  fn->probe = an;  
  an->Pos[0] = fn->Cen[0]; an->Pos[1] = fn->Cen[1]; an->Pos[2] = fn->Cen[2];

  an->con[0] = fn->atom[0]; an->con[1] = fn->atom[1]; an->con[2] = fn->atom[2];
  
  an->R  = fn->R;
  an->num = Natom;
  sprintf(an->Anum,"%5d",Natom);
  /* 
  sprintf(an->Rnum,"%4d ",Natom);
  */
  sprintf(an->Rnum,"%4d ",Natom%10000);
  sprintf(an->Resi,"PRB");
  sprintf(an->Atom,"CA ");
  an->Chain = 'P';
  an->AHtype = 'H';
  an->Occup = an->tFactor = an->R;
  an->subtype = fn->type;
  an->res = NULL;
 
} /* fn */

} /* end of Make_Probe_Atoms_from_SH_FACE() */






int Check_Crash_Bwn_Chains(Ahead, Phead, ChkCrashType)
 struct ATOM *Ahead;  /* Head of protein Atoms */
 struct ATOM *Phead;  /* Head of Probes */
 char ChkCrashType;  /* 'c' just check, 'd':delete crashed atom from Phead */
{
 struct ATOM *an,*pn;
 float X[3],D;
 int i;

 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
 
  pn = Phead;

  while (pn->next != NULL)
  {
   pn = pn->next;

   X[0] = an->Pos[0] - pn->Pos[0];
   X[1] = an->Pos[1] - pn->Pos[1];
   X[2] = an->Pos[2] - pn->Pos[2];

   D = X[0]*X[0] + X[1]*X[1] + X[2]*X[2];

   if (D>0) D = sqrt(D); else D = -100.0;

   if ((an->R + pn->R - D) > PAR.Lcrash_permit)
   {
    printf("#CRASH Dis %f: atom %s %s %.2f vs probe %s %s %.2f ",
     D,an->Anum,an->Atom,an->R, pn->Anum, pn->Atom,pn->R);
    for (i=0;i<3;++i)
    { if (pn->con[i]!=NULL) printf(" %s",pn->con[i]->Anum);}
    printf(" Diff %f\n",D - an->R - pn->R);
 
    if (ChkCrashType == 'd')
     { if (pn->next != NULL) {pn->next->prev = pn->prev;}
       pn->prev->next = pn->next;
       pn = pn->prev; } 
   }
  
  } /* pn */
 
} /* an */

} /* end of Check_Crash_Bwn_Chains() */



struct SH_FACE *Check_Redundant_Face(Fhead,a0,a1,a2)
 struct SH_FACE *Fhead;
 struct ATOM *a0,*a1,*a2;
{
 struct SH_FACE *fn;

 fn = Fhead;
 while (fn->next != NULL)
 {
  fn = fn->next;
  if ((fn->atom[0]->num == a0->num) && (fn->atom[1]->num == a1->num) &&
      (fn->atom[2]->num == a2->num) )  return(fn); 
 } 
 return(NULL);

} /* end of Check_Redundant_Face() */





void Write_Tpnt_Face_PDB_File_SH_FACE(fname,mode,Fhead)
 char *fname;
 char mode; /* 'a'ppend, 'w'rite */ 
 struct SH_FACE *Fhead;
{
  FILE *fp;
  struct SH_FACE *fn;
  int i,j,L,Nres,Natm0;
  float PrbPos[3],PrbR;
  char  PrbAnum[7];
   printf("#Write_Tpnt_Face_PDB_File_SH_FACE -> \"%s\"\n",fname);
   if (fname[0]=='-') fp = stdout;
    else
     {
      if (mode=='a') fp = fopen(fname,"a");
                else fp = fopen(fname,"w");
      if (fp==NULL) { printf("#ERROR:Can't write to \"%s\"\n",fname); exit(1);}
     }

  fprintf(fp,"HEADER    Tangent points \"%s\"\n",fname);
 fprintf(fp,"REMARK%5s %4s %3s  %4s    %8s%8s%8s%6s%6s %5s%5s%5s%8s%8s%8s\n",
  "#atm","atm","res","#res","Xtpnt","Ytpnt","Ztpnt","Rprb","#prb","#atm1","#atm2","#atm3","Xprb","Yprb","Zprb");  

  Natm0 = 10000;
  /** [1] Output XYZ-coordinates for Tangent Points **/
 fn = Fhead;
  Nres = 0;
  while (fn->next != NULL)
   {
     fn = fn->next;

    if (fn->probe != NULL)
    { PrbPos[0] = fn->probe->Pos[0];
      PrbPos[1] = fn->probe->Pos[1];
      PrbPos[2] = fn->probe->Pos[2]; 
      sprintf(PrbAnum,"%s",fn->probe->Anum); 
      PrbR = fn->probe->R; }
    else
     { PrbPos[0] = PrbPos[1] = PrbPos[2] = PrbR = 0.0;
       sprintf(PrbAnum," %d ",Nres); }

     fprintf(fp,"HETATM%5d %4s %3s %c%4d    %8.3f%8.3f%8.3f%6.2f%6s %5s%5s%5s",
       Nres*3+Natm0,"TAN","TAN",' ',fn->num,
       fn->tpnt[0][0],fn->tpnt[0][1],fn->tpnt[0][2],PrbR,PrbAnum,
       fn->atom[0]->Anum, fn->atom[1]->Anum, fn->atom[2]->Anum);
    fprintf(fp,"%8.3f%8.3f%8.3f\n",PrbPos[0], PrbPos[1], PrbPos[2]);

     fprintf(fp,"HETATM%5d %4s %3s %c%4d    %8.3f%8.3f%8.3f%6.2f%6s %5s%5s%5s",
       Nres*3+Natm0+1,"TAN","TAN",' ',fn->num,
       fn->tpnt[1][0],fn->tpnt[1][1],fn->tpnt[1][2],PrbR,PrbAnum,
       fn->atom[0]->Anum, fn->atom[1]->Anum, fn->atom[2]->Anum);
    fprintf(fp,"%8.3f%8.3f%8.3f\n",PrbPos[0], PrbPos[1], PrbPos[2]);

    fprintf(fp,"HETATM%5d %4s %3s %c%4d    %8.3f%8.3f%8.3f%6.2f%6s %5s%5s%5s",
       Nres*3+Natm0+2,"TAN","TAN",' ',fn->num,
       fn->tpnt[2][0],fn->tpnt[2][1],fn->tpnt[2][2],PrbR,PrbAnum,
       fn->atom[0]->Anum, fn->atom[1]->Anum, fn->atom[2]->Anum);
    fprintf(fp,"%8.3f%8.3f%8.3f\n",PrbPos[0], PrbPos[1], PrbPos[2]);
 
   ++Nres;
   } /* fn */

  /** [2] Connect Information **/

  fn = Fhead;
  Nres = 0;
  while (fn->next != NULL)
   {
     fn = fn->next;
     fprintf(fp,"CONECT%5d%5d%5d\n",Nres*3+Natm0,Nres*3+Natm0+1,Nres*3+Natm0+2);
     fprintf(fp,"CONECT%5d%5d\n",Nres*3+Natm0+1,Nres*3+Natm0+2);
     ++Nres;
   } /* fn */

  fprintf(fp,"END\n");

  if (fp!=stdout) fclose(fp);

} /* end of Write_Tpnt_Face_PDB_File_SH_FACE() */
