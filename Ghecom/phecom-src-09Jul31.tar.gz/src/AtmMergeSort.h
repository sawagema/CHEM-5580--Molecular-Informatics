/*

 <AtmMergeSort.h>
 
*/

extern struct ATOM *Merge_Sort_List_ATOM();
extern void Merge_Sort_Double_Linked_List_ATOM();
