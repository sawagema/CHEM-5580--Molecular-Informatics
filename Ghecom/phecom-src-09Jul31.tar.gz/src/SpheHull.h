/*

<SpheHull.h>

*/

/*** FUNCTIONS ***/
extern void Construct_Sphere_Hull();
extern int  Initial_Double_Triangle_SpheHull();
extern void Output_Faces_VRML_SpheHull();
extern void Write_Tpnt_Face_PDB_File_SpheHull();
extern int  Free_SH_FACEs();
extern void Make_Probe_Atoms_from_SH_FACE();
extern int  Check_Crash_Bwn_Chains();
extern void Write_Tpnt_Face_PDB_File_SH_FACE();
