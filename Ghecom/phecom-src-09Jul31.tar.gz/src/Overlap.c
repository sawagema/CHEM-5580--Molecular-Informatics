/**

 <Overlap.c> 

 for setting Overlap list of atoms 
  
 coded by Takeshi Kawabata (takawaba@is.naist.jp)


**/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <math.h>
#include "pdbstruct.h"

/*** FUNCTION (GLOBAL) ***/
void Set_Overlap_List();
void Free_Overlap_List();
int Check_Crash_Pos_and_Overlapped_Atoms();

/*** FUNCTION (LOCAL)  ***/
static void Add_Overlap_Stack();
static void Free_Overlap_Stack();


void Set_Overlap_List(Ahead,Dmat,Rprobe)
 struct ATOM *Ahead;
 struct MATRIX *Dmat;
 float  Rprobe;
{
 struct ATOM *an,*bn;
 float Rprobe2;
 struct OVERLAP *on;
 int Nover;

 printf("#Set_Overlap_List()\n");
 Rprobe2 = 2.0*Rprobe; 

 /*** Initialize Ohead ***/
 an = Ahead;
 while (an->next != NULL)
 { an = an->next;
   an->Ohead.next = NULL; }


 /*** Set Overlap List ***/
 an = Ahead;
 while (an->next != NULL)
 {
   an = an->next; 
   bn = an;

   while (bn->next != NULL)
   { 
    bn = bn->next;

    if (Dmat->m[an->num][bn->num] <= (an->R+bn->R+Rprobe2))
    {
     Add_Overlap_Stack(&(an->Ohead),bn);
     Add_Overlap_Stack(&(bn->Ohead),an);
     }

   } /* bn */

 } /* an */



 /* Test */
 /*
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  Nover = 0;
  printf(">%d\n",an->num);
  on = &(an->Ohead);
  while (on->next != NULL)
  {
    on = on->next;
    printf(" %d\n",on->atom->num);
    ++Nover;
   } 
  printf("#Nover %d\n",Nover); 
 } 
 */ 

} /* end of Set_Overlap_List() */




void Free_Overlap_List(Ahead)
 struct ATOM *Ahead;
{
 struct ATOM *an;

 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  Free_Overlap_Stack(&(an->Ohead));
  } 
 
} /* end of Free_Overlap_List() */





int Check_Crash_Pos_and_Overlapped_Atoms(pos,Rprobe,tatm)
 float pos[3],Rprobe;
 struct ATOM *tatm;  /* Tangent Atom  */
{
 struct ATOM *an;
 struct OVERLAP *on;
 int m;
 float d[3],D;

 on =&(tatm->Ohead); 
 
 while (on->next != NULL)
 {
   on = on->next;
   for (m=0;m<3;++m) d[m] = pos[m] - on->atom->Pos[m];
   D = d[0]*d[0] + d[1]*d[1] + d[2]*d[2];
   if (D>0.0) D = sqrt(D);
   if ((Rprobe + on->atom->R - D)>PAR.Lcrash_permit) return(1);  

  } /* on */
  
  return(0);

} /* end of Check_Crash_Pos_and_Overlappped_Atoms() */






void Add_Overlap_Stack(Ohead,overlap_atom)
 struct OVERLAP *Ohead;
 struct ATOM *overlap_atom;
{
 struct OVERLAP *nn,*on;
 int i;

  nn = Ohead->next;
  Ohead->next = (struct OVERLAP*)malloc(sizeof(struct OVERLAP));
  on = Ohead->next;
  on->next = nn;

  on->atom = overlap_atom;

} /* end of Add_Overlap_Stack() */



void Free_Overlap_Stack(Ohead)
 struct OVERLAP *Ohead;
{
 struct OVERLAP *cur,*next;
 int i;

 cur = Ohead;
 next = cur->next;

 while (next != NULL)
 { cur = next;
   next = cur->next;
   free(cur); }

} /* end of Free_Overlap_Stack() */



