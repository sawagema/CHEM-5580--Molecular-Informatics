/*
 
<Amino.h>

*/

extern char Amino_Number();
extern int Number_Amino();
extern char TriAA_to_OneAA();
extern void Get_TriAmino();
extern void Set_AAnum();    
extern char  AAnum[20];    
extern int   numAA[256];   
