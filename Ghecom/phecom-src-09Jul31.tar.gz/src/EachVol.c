/*

 <EachVol.c>

 Procedure for calculating volume for each atoms / each residue 

 coded by Takeshi Kawabata (takawaba@is.naist.jp)

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <strings.h>
#include "pdbstruct.h"
#include "mc_verface.h"
#include "MCubeFunc.h"
#include "Voxel.h"
#include "PdbIO.h"


/*** FUNCTION (GLOBAL) ***/
void Cal_Each_Atom_Probe_Volume();
float Standard_Volume();
float Cal_Atoms_Volume_By_Marching_Cube();
void Cal_Each_Residue_Nprobe_surf();

/*** FUNCTION (LOCAL) ***/
static int Number_Of_Marked_Atom();



void Cal_Each_Atom_Probe_Volume(Ahead,Phead)
 struct ATOM *Ahead;
 struct ATOM *Phead;
{
 struct ATOM *an,*pn;
 int i,Nhit;
 char hit;
 float Rprobe,Vone;

 printf("#Cal_Each_Atom_Probe_Volume()\n");
 /** Atom Loop **/
 an = Ahead;
 while (an->next != NULL)
 { 
  an = an->next;
  Nhit = 0;
  pn = Phead;
 
  /** Probe Loop **/
  while (pn->next != NULL)
  { 
   pn = pn->next;
   
   i = 0; hit = 0;
   while ((i<3)&&(hit==0))
    { if ((pn->con[i] != NULL) && (pn->con[i]->num == an->num))  hit = 1; else ++i;}
   pn->mark = hit;   
   Nhit += hit;
   Rprobe = pn->R;
   } /* pn */

  if (Nhit>0) an->Vprobe = Cal_Atoms_Volume_By_Marching_Cube(Phead,'T');
         else an->Vprobe = 0.0;
  Vone = 4.0/3.0 * M_PI * Rprobe * Rprobe * Rprobe;
  /* Set atom tFactor to Vprobe/Vone */
  an->tFactor = an->Vprobe /Vone;
 
 } /* an */

} /* end of Cal_Each_Atom_Probe_Volume() */




void Cal_Each_Residue_Probe_Volume(Rhead,Ahead,Phead)
 struct RESIDUE *Rhead;
 struct ATOM *Ahead;
 struct ATOM *Phead;
{
 struct RESIDUE *rn;
 struct ATOM *an,*pn;
 int i,Nprobe;
 char hit;

 
 printf("#Cal_Each_Residue_Probe_Volume()\n");
 /** Residue Loop **/
 rn = Rhead;
 while (rn->next != NULL)
 { 
  rn = rn->next;
 
  /* initialized mark of probe */
  pn = Phead;
  while (pn->next != NULL) { pn = pn->next; pn->mark = 0;} 
  Nprobe = 0;

  /** Atom Loop **/
  an = Ahead; 
  while (an->next != NULL)
  {
   an = an->next; 
   if (an->res->num == rn->num) 
   { 
    /* printf("an->res->num %d rn->num %d\n",an->res->num,rn->num); */
    pn = Phead;
    /** Probe Loop **/
    while (pn->next != NULL)
    { 
     pn = pn->next;
     i = 0; hit = 0;
     while ((i<3)&&(hit==0))
      { if ((pn->con[i] != NULL) && (pn->con[i]->num == an->num))  hit = 1; else ++i;}
     if ((hit==1)&&(pn->mark==0)) {pn->mark = 1; ++Nprobe;}   
     } /* pn */
   }
  } /* an */

  rn->Nprobe = Nprobe;
  if (Nprobe>0) rn->Vprobe = Cal_Atoms_Volume_By_Marching_Cube(Phead,'T'); 
  else rn->Vprobe = 0.0;

  /* printf("Nprobe %d Vprobe %f\n",Nprobe,rn->Vprobe); */

 } /* rn */

} /* end of Cal_Each_Residue_Probe_Volume() */






float Cal_Atoms_Volume_By_Marching_Cube(Ahead,MarkType)
 struct ATOM *Ahead;
 char   MarkType; 
 /*
  if (MarkType == 'T') Calculating Volume of the union of atoms, only for "
  Marked" Atom ( for an whose mark = 1) 
 */
{
  struct VOXEL vox;
  struct MC_VERTEX vhead;
  struct MC_FACE   fhead;
  float V,vmin,r,rmin;
  int Natom;

  /**
   Before Marching_Cube, rmin is checked, and 
   vmin (volume of rmin sphere) is caluculated.
  
   if (Natom==1) return(vmin) without Marching_Cube.
   otherwise
   { 
    Calculate V using Marching_Cube.
    if (Natom> 1) and (V<vmin) return(vmin);
   } 
   **/

/*
  printf("#Cal_Atoms_Volume_By_Marching_Cube(Ahead)\n");
*/

  Natom = Number_Of_Marked_Atom(Ahead,&rmin);

  vmin = 4.0/3.0 * M_PI * rmin * rmin * rmin; 
  
  if (Natom == 0)  V = 0.0;
 
  else if (Natom == 1)  V = vmin;

  else
  {
  
  vox.gridlen = PAR.vvox_grid;
  Cal_Size_Of_Voxel_By_Molecule(Ahead,0.0,vox.gridlen,vox.min,vox.N,MarkType);
    
  Malloc_Voxel(&vox, vox.N[0], vox.N[1], vox.N[2]);
  PAR.SpType  = 'S'; PAR.SumType = 'X'; 
  PAR.Asigmoid = 10.0;
  PAR.Phardsp  = 0.5;

  Cal_Density_Of_Molecule(&vox,Ahead,MarkType);
  Marching_Cube(&vox,&vhead,&fhead,0.5,'C');
  V = Volume_Inside_Faces(vox.gridlen,&vhead,&fhead);
  Free_Voxel(&vox, vox.N[0], vox.N[1], vox.N[2]);
  Free_MC_Vertex_Stack(&vhead);
  Free_MC_Face_Stack(&fhead);
  } 

  /*
  printf("Natom %d V %f V/Vmin %lf\n",Natom,V,V/vmin); 
  */

  if (V < vmin) V = vmin;
  
  return(V);

} /* end of Cal_Atoms_Volume_By_Marching_Cube() */





int Number_Of_Marked_Atom(Ahead,Rmin)
 struct ATOM *Ahead;
 float *Rmin;
{
 struct ATOM *an;
 int Natom;

 *Rmin = 10000.0;
 Natom = 0;
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  if (an->mark == 1) 
   { ++Natom;
     if (an->R < *Rmin) *Rmin = an->R; 
    }
 }

 return(Natom);
} /* end of  Number_Of_Marked_Atom() */





float Standard_Volume(t,Rprobe)
  char *t;
  float Rprobe;
{
 float v;
 float R[20],D[20],DD,sigma;
 int i;

 sigma = 0.001;
 R[0] = 1.4; R[1] = 1.5; R[2] = 1.6; R[3] = 1.7; R[4] = 1.8;
 R[5] = 1.9; R[6] = 2.0; R[7] = 2.1; R[8] = 2.2; R[9] = 2.3;
 R[10] = 2.4; R[11] = 2.5;
  
 for (i=0;i<12;++i)
  { DD = R[i]-Rprobe;
    D[i] = sqrt(DD*DD);  }

 if (D[0]<=sigma)
{
 /* Rprobe = 1.4 */
      if (strncmp(t,"ALA",3)<=0)  v = 405.63;
 else if (strncmp(t,"VAL",3)<=0)  v = 541.75;
 else if (strncmp(t,"PHE",3)<=0)  v = 695.44;
 else if (strncmp(t,"PRO",3)<=0)  v = 491.02;
 else if (strncmp(t,"MET",3)<=0)  v = 647.67;
 else if (strncmp(t,"ILE",3)<=0)  v = 587.63;
 else if (strncmp(t,"LEU",3)<=0)  v = 597.76;
 else if (strncmp(t,"ASP",3)<=0)  v = 520.00;
 else if (strncmp(t,"GLU",3)<=0)  v = 568.52;
 else if (strncmp(t,"LYS",3)<=0)  v = 654.02;
 else if (strncmp(t,"ARG",3)<=0)  v = 779.37;
 else if (strncmp(t,"SER",3)<=0)  v = 436.43;
 else if (strncmp(t,"THR",3)<=0)  v = 503.12;
 else if (strncmp(t,"TYR",3)<=0)  v = 734.97;
 else if (strncmp(t,"HIS",3)<=0)  v = 639.35;
 else if (strncmp(t,"CYS",3)<=0)  v = 491.80;
 else if (strncmp(t,"ASN",3)<=0)  v = 509.28;
 else if (strncmp(t,"GLN",3)<=0)  v = 583.21;
 else if (strncmp(t,"TRP",3)<=0)  v = 799.67;
 else if (strncmp(t,"GLY",3)<=0)  v = 430.33;
 else v = 0.0;}

 else if (D[1] <= sigma)
{
 /* Rprobe = 1.5 */
      if (strncmp(t,"ALA",3)<=0)  v = 457.43;
 else if (strncmp(t,"VAL",3)<=0)  v = 604.20;
 else if (strncmp(t,"PHE",3)<=0)  v = 776.75;
 else if (strncmp(t,"PRO",3)<=0)  v = 558.83;
 else if (strncmp(t,"MET",3)<=0)  v = 722.33;
 else if (strncmp(t,"ILE",3)<=0)  v = 660.58;
 else if (strncmp(t,"LEU",3)<=0)  v = 668.59;
 else if (strncmp(t,"ASP",3)<=0)  v = 584.26;
 else if (strncmp(t,"GLU",3)<=0)  v = 633.75;
 else if (strncmp(t,"LYS",3)<=0)  v = 731.16;
 else if (strncmp(t,"ARG",3)<=0)  v = 873.68;
 else if (strncmp(t,"SER",3)<=0)  v = 487.48;
 else if (strncmp(t,"THR",3)<=0)  v = 562.07;
 else if (strncmp(t,"TYR",3)<=0)  v = 821.91;
 else if (strncmp(t,"HIS",3)<=0)  v = 713.86;
 else if (strncmp(t,"CYS",3)<=0)  v = 550.13;
 else if (strncmp(t,"ASN",3)<=0)  v = 572.04;
 else if (strncmp(t,"GLN",3)<=0)  v = 651.10;
 else if (strncmp(t,"TRP",3)<=0)  v = 891.46;
 else if (strncmp(t,"GLY",3)<=0)  v = 484.32;
 else v = 0.0;}

 else if (D[2] <= sigma)
{
 /* Rprobe =1.6 */
      if (strncmp(t,"ALA",3)<=0)  v = 512.39;
 else if (strncmp(t,"VAL",3)<=0)  v = 674.11;
 else if (strncmp(t,"PHE",3)<=0)  v = 871.33;
 else if (strncmp(t,"PRO",3)<=0)  v = 619.99;
 else if (strncmp(t,"MET",3)<=0)  v = 805.19;
 else if (strncmp(t,"ILE",3)<=0)  v = 737.57;
 else if (strncmp(t,"LEU",3)<=0)  v = 745.83;
 else if (strncmp(t,"ASP",3)<=0)  v = 655.87;
 else if (strncmp(t,"GLU",3)<=0)  v = 708.33;
 else if (strncmp(t,"LYS",3)<=0)  v = 813.49;
 else if (strncmp(t,"ARG",3)<=0)  v = 968.04;
 else if (strncmp(t,"SER",3)<=0)  v = 548.86;
 else if (strncmp(t,"THR",3)<=0)  v = 632.48;
 else if (strncmp(t,"TYR",3)<=0)  v = 915.38;
 else if (strncmp(t,"HIS",3)<=0)  v = 797.26;
 else if (strncmp(t,"CYS",3)<=0)  v = 618.89;
 else if (strncmp(t,"ASN",3)<=0)  v = 638.85;
 else if (strncmp(t,"GLN",3)<=0)  v = 726.75;
 else if (strncmp(t,"TRP",3)<=0)  v = 984.11;
 else if (strncmp(t,"GLY",3)<=0)  v = 543.67;
 else v = 0.0;}

 else if (D[3] <= sigma)
{
 /* Rprobe ==1.7 */
      if (strncmp(t,"ALA",3)<=0)  v = 575.02;
 else if (strncmp(t,"VAL",3)<=0)  v = 750.54;
 else if (strncmp(t,"PHE",3)<=0)  v = 957.68;
 else if (strncmp(t,"PRO",3)<=0)  v = 693.42;
 else if (strncmp(t,"MET",3)<=0)  v = 889.75;
 else if (strncmp(t,"ILE",3)<=0)  v = 815.06;
 else if (strncmp(t,"LEU",3)<=0)  v = 823.90;
 else if (strncmp(t,"ASP",3)<=0)  v = 731.21;
 else if (strncmp(t,"GLU",3)<=0)  v = 783.22;
 else if (strncmp(t,"LYS",3)<=0)  v = 898.42;
 else if (strncmp(t,"ARG",3)<=0)  v = 1070.30;
 else if (strncmp(t,"SER",3)<=0)  v = 610.71;
 else if (strncmp(t,"THR",3)<=0)  v = 703.36;
 else if (strncmp(t,"TYR",3)<=0)  v = 1009.83;
 else if (strncmp(t,"HIS",3)<=0)  v = 884.20;
 else if (strncmp(t,"CYS",3)<=0)  v = 686.92;
 else if (strncmp(t,"ASN",3)<=0)  v = 708.46;
 else if (strncmp(t,"GLN",3)<=0)  v = 803.64;
 else if (strncmp(t,"TRP",3)<=0)  v = 1085.81;
 else if (strncmp(t,"GLY",3)<=0)  v = 607.30;
 else v = 0.0;}

 else if (D[4] <= sigma)
{
 /** Rprobe ==1.8 **/
      if (strncmp(t,"ALA",3)<=0)  v = 638.36;
 else if (strncmp(t,"VAL",3)<=0)  v = 836.11;
 else if (strncmp(t,"PHE",3)<=0)  v = 1064.88;
 else if (strncmp(t,"PRO",3)<=0)  v = 769.89;
 else if (strncmp(t,"MET",3)<=0)  v = 982.07;
 else if (strncmp(t,"ILE",3)<=0)  v = 908.04;
 else if (strncmp(t,"LEU",3)<=0)  v = 913.20;
 else if (strncmp(t,"ASP",3)<=0)  v = 809.67;
 else if (strncmp(t,"GLU",3)<=0)  v = 864.85;
 else if (strncmp(t,"LYS",3)<=0)  v = 990.95;
 else if (strncmp(t,"ARG",3)<=0)  v = 1177.39;
 else if (strncmp(t,"SER",3)<=0)  v = 679.93;
 else if (strncmp(t,"THR",3)<=0)  v = 778.71;
 else if (strncmp(t,"TYR",3)<=0)  v = 1120.75;
 else if (strncmp(t,"HIS",3)<=0)  v = 981.29;
 else if (strncmp(t,"CYS",3)<=0)  v = 763.13;
 else if (strncmp(t,"ASN",3)<=0)  v = 784.98;
 else if (strncmp(t,"GLN",3)<=0)  v = 886.77;
 else if (strncmp(t,"TRP",3)<=0)  v = 1198.81;
 else if (strncmp(t,"GLY",3)<=0)  v = 677.70;
 else v = 0.0;}

 else if (D[5] <= sigma)
{
 /** Rprobe == 1.9 **/
      if (strncmp(t,"ALA",3)<=0)  v = 711.52;
 else if (strncmp(t,"VAL",3)<=0)  v = 924.19;
 else if (strncmp(t,"PHE",3)<=0)  v = 1170.46;
 else if (strncmp(t,"PRO",3)<=0)  v = 853.06;
 else if (strncmp(t,"MET",3)<=0)  v = 1085.18;
 else if (strncmp(t,"ILE",3)<=0)  v = 1000.07;
 else if (strncmp(t,"LEU",3)<=0)  v = 1006.36;
 else if (strncmp(t,"ASP",3)<=0)  v = 900.36;
 else if (strncmp(t,"GLU",3)<=0)  v = 959.08;
 else if (strncmp(t,"LYS",3)<=0)  v = 1096.88;
 else if (strncmp(t,"ARG",3)<=0)  v = 1295.70;
 else if (strncmp(t,"SER",3)<=0)  v = 759.73;
 else if (strncmp(t,"THR",3)<=0)  v = 866.46;
 else if (strncmp(t,"TYR",3)<=0)  v = 1235.26;
 else if (strncmp(t,"HIS",3)<=0)  v = 1081.15;
 else if (strncmp(t,"CYS",3)<=0)  v = 852.76;
 else if (strncmp(t,"ASN",3)<=0)  v = 869.95;
 else if (strncmp(t,"GLN",3)<=0)  v = 981.53;
 else if (strncmp(t,"TRP",3)<=0)  v = 1312.94;
 else if (strncmp(t,"GLY",3)<=0)  v = 756.52;
 else v = 0.0;}

 else if (D[6]<=sigma)
{
 /** Rprobe == 2.0 **/
      if (strncmp(t,"ALA",3)<=0)  v = 780.88;
 else if (strncmp(t,"VAL",3)<=0)  v = 1017.77;
 else if (strncmp(t,"PHE",3)<=0)  v = 1281.78;
 else if (strncmp(t,"PRO",3)<=0)  v = 936.98;
 else if (strncmp(t,"MET",3)<=0)  v = 1182.39;
 else if (strncmp(t,"ILE",3)<=0)  v = 1094.25;
 else if (strncmp(t,"LEU",3)<=0)  v = 1097.17;
 else if (strncmp(t,"ASP",3)<=0)  v = 981.24;
 else if (strncmp(t,"GLU",3)<=0)  v = 1044.78;
 else if (strncmp(t,"LYS",3)<=0)  v = 1195.03;
 else if (strncmp(t,"ARG",3)<=0)  v = 1411.88;
 else if (strncmp(t,"SER",3)<=0)  v = 835.62;
 else if (strncmp(t,"THR",3)<=0)  v = 953.16;
 else if (strncmp(t,"TYR",3)<=0)  v = 1344.48;
 else if (strncmp(t,"HIS",3)<=0)  v = 1180.11;
 else if (strncmp(t,"CYS",3)<=0)  v = 932.84;
 else if (strncmp(t,"ASN",3)<=0)  v = 952.49;
 else if (strncmp(t,"GLN",3)<=0)  v = 1070.18;
 else if (strncmp(t,"TRP",3)<=0)  v = 1425.89;
 else if (strncmp(t,"GLY",3)<=0)  v = 838.12;
 else v = 0.0;}

 else if (D[7] <= sigma)
{
 /** Rprobe = 2.1 **/
      if (strncmp(t,"ALA",3)<=0)  v = 858.80;
 else if (strncmp(t,"VAL",3)<=0)  v = 1117.03;
 else if (strncmp(t,"PHE",3)<=0)  v = 1398.12;
 else if (strncmp(t,"PRO",3)<=0)  v = 1026.66;
 else if (strncmp(t,"MET",3)<=0)  v = 1287.76;
 else if (strncmp(t,"ILE",3)<=0)  v = 1201.26;
 else if (strncmp(t,"LEU",3)<=0)  v = 1197.67;
 else if (strncmp(t,"ASP",3)<=0)  v = 1079.00;
 else if (strncmp(t,"GLU",3)<=0)  v = 1140.27;
 else if (strncmp(t,"LYS",3)<=0)  v = 1301.20;
 else if (strncmp(t,"ARG",3)<=0)  v = 1537.66;
 else if (strncmp(t,"SER",3)<=0)  v = 915.40;
 else if (strncmp(t,"THR",3)<=0)  v = 1043.25;
 else if (strncmp(t,"TYR",3)<=0)  v = 1466.92;
 else if (strncmp(t,"HIS",3)<=0)  v = 1285.49;
 else if (strncmp(t,"CYS",3)<=0)  v = 1022.90;
 else if (strncmp(t,"ASN",3)<=0)  v = 1046.57;
 else if (strncmp(t,"GLN",3)<=0)  v = 1169.62;
 else if (strncmp(t,"TRP",3)<=0)  v = 1556.51;
 else if (strncmp(t,"GLY",3)<=0)  v = 921.33;
 else v = 0.0;}

 else if (D[8] <= sigma)
{
 /** Rprobe = 2.2 **/
      if (strncmp(t,"ALA",3)<=0)  v = 937.06;
 else if (strncmp(t,"VAL",3)<=0)  v = 1211.28;
 else if (strncmp(t,"PHE",3)<=0)  v = 1527.71;
 else if (strncmp(t,"PRO",3)<=0)  v = 1126.21;
 else if (strncmp(t,"MET",3)<=0)  v = 1404.77;
 else if (strncmp(t,"ILE",3)<=0)  v = 1302.59;
 else if (strncmp(t,"LEU",3)<=0)  v = 1308.57;
 else if (strncmp(t,"ASP",3)<=0)  v = 1179.13;
 else if (strncmp(t,"GLU",3)<=0)  v = 1245.20;
 else if (strncmp(t,"LYS",3)<=0)  v = 1417.46;
 else if (strncmp(t,"ARG",3)<=0)  v = 1666.07;
 else if (strncmp(t,"SER",3)<=0)  v = 1004.19;
 else if (strncmp(t,"THR",3)<=0)  v = 1139.21;
 else if (strncmp(t,"TYR",3)<=0)  v = 1601.56;
 else if (strncmp(t,"HIS",3)<=0)  v = 1400.35;
 else if (strncmp(t,"CYS",3)<=0)  v = 1119.44;
 else if (strncmp(t,"ASN",3)<=0)  v = 1133.55;
 else if (strncmp(t,"GLN",3)<=0)  v = 1273.34;
 else if (strncmp(t,"TRP",3)<=0)  v = 1682.73;
 else if (strncmp(t,"GLY",3)<=0)  v = 1007.63;
 else v = 0.0;}

 else if (D[9] <= sigma)
{
 /** Rprobe = 2.3 **/
      if (strncmp(t,"ALA",3)<=0)  v = 1011.56;
 else if (strncmp(t,"VAL",3)<=0)  v = 1317.46;
 else if (strncmp(t,"PHE",3)<=0)  v = 1648.26;
 else if (strncmp(t,"PRO",3)<=0)  v = 1214.32;
 else if (strncmp(t,"MET",3)<=0)  v = 1511.99;
 else if (strncmp(t,"ILE",3)<=0)  v = 1415.67;
 else if (strncmp(t,"LEU",3)<=0)  v = 1403.34;
 else if (strncmp(t,"ASP",3)<=0)  v = 1274.34;
 else if (strncmp(t,"GLU",3)<=0)  v = 1343.59;
 else if (strncmp(t,"LYS",3)<=0)  v = 1523.07;
 else if (strncmp(t,"ARG",3)<=0)  v = 1788.98;
 else if (strncmp(t,"SER",3)<=0)  v = 1085.42;
 else if (strncmp(t,"THR",3)<=0)  v = 1240.48;
 else if (strncmp(t,"TYR",3)<=0)  v = 1729.78;
 else if (strncmp(t,"HIS",3)<=0)  v = 1515.99;
 else if (strncmp(t,"CYS",3)<=0)  v = 1207.87;
 else if (strncmp(t,"ASN",3)<=0)  v = 1224.47;
 else if (strncmp(t,"GLN",3)<=0)  v = 1371.87;
 else if (strncmp(t,"TRP",3)<=0)  v = 1811.70;
 else if (strncmp(t,"GLY",3)<=0)  v = 1090.83;
 else v = 0.0;}


else if (D[10] <= sigma)
{
 /** Rprobe = 2.4 **/
      if (strncmp(t,"ALA",3)<=0)  v = 1106.87;
 else if (strncmp(t,"VAL",3)<=0)  v = 1435.03;
 else if (strncmp(t,"PHE",3)<=0)  v = 1790.13;
 else if (strncmp(t,"PRO",3)<=0)  v = 1322.36;
 else if (strncmp(t,"MET",3)<=0)  v = 1640.38;
 else if (strncmp(t,"ILE",3)<=0)  v = 1536.04;
 else if (strncmp(t,"LEU",3)<=0)  v = 1526.76;
 else if (strncmp(t,"ASP",3)<=0)  v = 1383.07;
 else if (strncmp(t,"GLU",3)<=0)  v = 1458.81;
 else if (strncmp(t,"LYS",3)<=0)  v = 1655.65;
 else if (strncmp(t,"ARG",3)<=0)  v = 1935.07;
 else if (strncmp(t,"SER",3)<=0)  v = 1185.00;
 else if (strncmp(t,"THR",3)<=0)  v = 1350.93;
 else if (strncmp(t,"TYR",3)<=0)  v = 1876.38;
 else if (strncmp(t,"HIS",3)<=0)  v = 1643.90;
 else if (strncmp(t,"CYS",3)<=0)  v = 1321.68;
 else if (strncmp(t,"ASN",3)<=0)  v = 1331.86;
 else if (strncmp(t,"GLN",3)<=0)  v = 1490.85;
 else if (strncmp(t,"TRP",3)<=0)  v = 1958.93;
 else if (strncmp(t,"GLY",3)<=0)  v = 1182.53;
 else v = 0.0;}

 else if (D[11] <= sigma)
{
 /** Rprobe = 2.5 **/
      if (strncmp(t,"ALA",3)<=0)  v = 1199.61;
 else if (strncmp(t,"VAL",3)<=0)  v = 1558.25;
 else if (strncmp(t,"PHE",3)<=0)  v = 1930.35;
 else if (strncmp(t,"PRO",3)<=0)  v = 1429.23;
 else if (strncmp(t,"MET",3)<=0)  v = 1770.45;
 else if (strncmp(t,"ILE",3)<=0)  v = 1658.10;
 else if (strncmp(t,"LEU",3)<=0)  v = 1648.93;
 else if (strncmp(t,"ASP",3)<=0)  v = 1500.70;
 else if (strncmp(t,"GLU",3)<=0)  v = 1572.54;
 else if (strncmp(t,"LYS",3)<=0)  v = 1783.79;
 else if (strncmp(t,"ARG",3)<=0)  v = 2085.84;
 else if (strncmp(t,"SER",3)<=0)  v = 1288.96;
 else if (strncmp(t,"THR",3)<=0)  v = 1465.05;
 else if (strncmp(t,"TYR",3)<=0)  v = 2026.47;
 else if (strncmp(t,"HIS",3)<=0)  v = 1777.24;
 else if (strncmp(t,"CYS",3)<=0)  v = 1427.52;
 else if (strncmp(t,"ASN",3)<=0)  v = 1443.19;
 else if (strncmp(t,"GLN",3)<=0)  v = 1607.95;
 else if (strncmp(t,"TRP",3)<=0)  v = 2105.88;
 else if (strncmp(t,"GLY",3)<=0)  v = 1281.41;
 else v = 0.0;}

 
 /*
 printf("t \"%s\" Rprobe %f v %f ALA %d\n", t,Rprobe,v,strncmp(t,"ARA",3));
 */

 return(v);

} /* end of Standard_Volume() */





void Cal_Each_Residue_Nprobe_surf(Rhead,Ahead,Phead)
 struct RESIDUE *Rhead;
 struct ATOM *Ahead;
 struct ATOM *Phead;
{
 struct RESIDUE *rn;
 struct ATOM *an,*pn;
 int i,Nprobe_surf;
 char hit;

 printf("#Cal_Each_Residue_Nprobe_surf()\n");
 /** Residue Loop **/
 rn = Rhead;
 while (rn->next != NULL)
 { 
  rn = rn->next;
 
  /* initialized mark of probe */
  pn = Phead;
  while (pn->next != NULL) { pn = pn->next; pn->mark = 0;} 
  Nprobe_surf = 0;

  /** Atom Loop **/
  an = Ahead; 
  while (an->next != NULL)
  {
   an = an->next; 
   if (an->res->num == rn->num) 
   { 
    pn = Phead;
    /** Probe Loop **/
    while (pn->next != NULL)
    { 
     pn = pn->next;
     i = 0; hit = 0;
     while ((i<3)&&(hit==0))
      { if ((pn->con[i] != NULL) && (pn->con[i]->num == an->num))  hit = 1; else ++i;}
     if ((hit==1)&&(pn->mark==0)) {pn->mark = 1; ++Nprobe_surf;}   
     } /* pn */
   }
  } /* an */

  rn->Nprobe_surf = Nprobe_surf;

 } /* rn */

} /* end of Cal_Each_Residue_Nprobe_surf() */
