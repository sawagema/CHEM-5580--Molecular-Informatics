/*

 <ResMergeSort.c>
 
 functions for MergeSort for linked linear list. 

 coded by Takeshi Kawabata (takawaba@is.naist.jp).

 Reference :
 Yoshiyuki Kondo. "Algorithms and Data Structures for C programmers".
  Soft Bank Publishing (1998). written in Japanese.  


 <Standard Definition of NODE> 

 struct NODE{
  float value;
  struct NODE *next;
  struct NODE *prev;
 };


 <Standard Usage> 
 
 struct RESIDUE HEAD,*bn;
 
 bn = Merge_Sort_List(Head.next,'-'); 
 Head.next = bn;
   or 
 Merge_Sort_Double_Linked_List(head,type)

*/


#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "pdbstruct.h" 

/*** FUNCTIONS (GLOBAL) ***/
struct RESIDUE *Merge_Sort_List_RESIDUE();
void Merge_Sort_Double_Linked_List_RESIDUE();

/*** FUNCTIONS (LOCAL) ***/
static void Set_Prev_Pointer();
static struct RESIDUE *Merge_List();
static void Show_NODE();


void Show_NODE(head)
 struct RESIDUE *head;
{ 
 struct RESIDUE *bn;      

 /* bn = head->next;   */
 bn = head;
 while (bn != NULL)
 { printf("%f\n",bn->value); 
   bn = bn->next; }

} /* end of Show_NODE() */



void Merge_Sort_Double_Linked_List_RESIDUE(head,type)
 struct RESIDUE *head;
 char type; /* if 'R', large to small, otherwise small to large */ 
{
 struct RESIDUE *bn;
 bn = Merge_Sort_List_RESIDUE(head->next,type); 
 head->next = bn;
 Set_Prev_Pointer(head);

} /* end of Merge_Sort_Double_Linked_List_RESIDUE() */



struct RESIDUE *Merge_List(a,b,type)
 struct RESIDUE *a,*b;
 char type; /* if 'R', large to small, otherwise small to large */ 
{
 struct RESIDUE head, *p;

 /* Initialize */ 
 p = &head;

 /* Repeat until lists 'a' and 'b' become empty */

 /* The smaller node is attached to the list 'p' */
 if (type != 'R') 
 while ((a!=NULL)&&(b!=NULL))
 {
  if (a->value <= b->value) { p->next = a; p = a; a = a->next; }
                       else { p->next = b; p = b; b = b->next; }
 }  

 else
 
 /* The larger node is attached to the list 'p' */
 while ((a!=NULL)&&(b!=NULL))
 {
  if (a->value >= b->value) { p->next = a; p = a; a = a->next; }
                       else { p->next = b; p = b; b = b->next; }
 }  


 /* The rest nodes are attached to the list 'p'. */
       if ((a == NULL) && (b !=NULL)) p->next = b; 
 else if  ((b == NULL) && (a !=NULL)) p->next = a; 
   
 return(head.next);

} /* end of  Merge_List() */






struct RESIDUE *Merge_Sort_List_RESIDUE(x,type)
 struct RESIDUE *x;
 char type;
{
 struct RESIDUE *a, *b, *p;


 /* if x has no nodes, or one nodes */
 if ((x==NULL) || (x->next ==NULL)) return(x); 

 /* a is the 1st node, and 'b' is the 2nd or 3rd node */
 a = x;
 b = x->next;
 if (b->next !=NULL) b = x->next;

 /* 
   Progress a by 1 node, and 'b' by two nodes. 
   if 'b' reaches to the end, 'a' reaches to the midpoint.
 */

 while (b->next !=NULL)
 {
  a = a->next;
  b = b->next;
  if (b->next !=NULL) b = b->next;
  }

 /* Truncate the list on the midpoint */
 p = a->next; a->next = NULL;

 return(Merge_List(Merge_Sort_List_RESIDUE(x,type),Merge_Sort_List_RESIDUE(p,type),type));


} /* end of *Merge_Sort_List_RESIDUE() */




void Set_Prev_Pointer(head)
 struct RESIDUE *head;
{
 struct RESIDUE *bn,*pn;

 bn = head;
 while (bn->next !=NULL) 
 {
   pn = bn;
   bn = bn->next;
   bn->prev = pn; 
  }

} /* end of Set_Prev_Pointer() */

