/**

 <SpheIcosa.c>

 for making probe spheres following 
 recursively divieded icosahedron.

 coded by Takeshi Kawabata (takawaba@is.naist.jp)

**/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "pdbstruct.h" 
#include "PdbIO.h" 
#include "SphePnt3.h" 
#include "ColCheck.h" 


#define MAX_RECUR 10

/*** FUNCTION (GLOBAL) ***/
void Make_Probe_Spheres_Icosahedron();
void Make_Probe_Spheres_Icosahedron_ColVoxel();
void Make_Probe_Spheres_Icosahedron_Recursive();

/*** FUNCTION (LOCAL) ***/
static void Make_Icosahedron_Vertex();
static void Make_Recursive_Icosahedron_Vertex();
static struct VERTEX* Add_Vertex_Stack();
static struct VERTEX* Add_Vertex_Stack_Parent();
static struct TRIANGLE* Add_Triangle_Stack();
static struct VERTEX* Find_Vertex_Parent();
static void Normalize();
static void Write_Vertex_In_PDB();
static void Vertex_Mark_Set();



struct VERTEX{
 float Pos[3];
 char  mark; 
 int num;
 struct VERTEX *next;
 struct VERTEX *xn,*yn;  /* Parent Vertex */
};




struct TRIANGLE{
 struct VERTEX *an,*bn,*cn;
 struct VERTEX *pn,*qn,*rn;
 struct TRIANGLE *next;
 /*
       a
     /   \  
    p---- r  
   / \  /  \ 
  b----q----c

 */

};


void Make_Probe_Spheres_Icosahedron(Phead,Ahead,Rprobe,Nrecur)
 struct ATOM *Phead;
 struct ATOM *Ahead;
 float Rprobe;
 int   Nrecur;
{
 struct VERTEX   Vhead[MAX_RECUR];
 struct TRIANGLE Thead[MAX_RECUR];
 struct ATOM *an,*bn,*cn;
 struct VERTEX *vn;
 int Nprobe,r,m,Nver;
 float R,Ppos[3];

 printf("#Make_Probe_Spheres_Icosahedron(Rprobe %f Nrecur %d)\n",Rprobe,Nrecur);
 if (Nrecur >= MAX_RECUR) 
 { printf("#ERROR:Nrecur %d is over MAX_RECUR %d\n",Nrecur,MAX_RECUR);
   exit(1); }
 
 /*** Make Template Spheres for Icosahedron  (Vhead, Thead) ***/
 Make_Icosahedron_Vertex(&Vhead[0],&Thead[0]);
 if (Nrecur>1)
  Make_Recursive_Icosahedron_Vertex(Vhead,Thead,Nrecur);

 /*** Make Probe Spheres using Icosahedron templates (Vhead,Thead) ***/
 bn = NULL; cn = NULL;

 an = Ahead;
 Phead->next = NULL;
 Nprobe = 0;
 while (an->next != NULL)
 {
  an = an->next;
  R = an->R + Rprobe;
  for (r=0;r<Nrecur;++r)
  {
    vn = &Vhead[r];  Nver = 0;
    while (vn->next != NULL)
    { 
      vn = vn->next; ++Nver;
      for (m=0;m<3;++m) Ppos[m] = an->Pos[m] + R*vn->Pos[m];
      if (Check_Crash_Pos_and_Atoms(Ppos,Rprobe,Ahead)==0)
       { Add_Atom_Stack(Phead,Ppos,Rprobe,'I',Nprobe,an,bn,cn); 
         vn->mark = 1; ++Nprobe; }
     else vn->mark = 0;
     } /* vn */
  } /* r */

 } /* an */

 Renumber_AnumRnum(Phead);

} /* end of Make_Probe_Sphres_Icosahedron() */







void Make_Probe_Spheres_Icosahedron_ColVoxel(Phead,Ahead,Rprobe,Nrecur)
 struct ATOM *Phead;
 struct ATOM *Ahead;
 float Rprobe;
 int   Nrecur;
{
 struct VERTEX   Vhead[MAX_RECUR];
 struct TRIANGLE Thead[MAX_RECUR];
 struct ATOM *an, *bn, *cn;
 struct VERTEX *vn;
 int Nprobe,i,r,m,Nver;
 float R,Ppos[3];
 struct COLVOXEL cvox;
 double val,residual;
 int I[3];

 printf("#Make_Probe_Spheres_Icosahedron_ColVoxel(Rprobe %f Nrecur %d)\n",Rprobe,Nrecur);
 if (Nrecur >= MAX_RECUR) 
 { printf("#ERROR:Nrecur %d is over MAX_RECUR %d\n",Nrecur,MAX_RECUR);
   exit(1); }

 /** Make ColVoxel for Fast Collision Check **/
 cvox.gridlen = Rprobe;
 Cal_Size_Of_Voxel_By_Molecule(Ahead,Rprobe,cvox.gridlen,cvox.min,cvox.N,'F');
 Malloc_Col_Voxel( &cvox, cvox.N[0],cvox.N[1],cvox.N[2]);
 Cal_Col_Voxel(&cvox,Ahead,Rprobe*0.5);
 
 /*** Make Template Spheres for Icosahedron  (Vhead, Thead) ***/
 Make_Icosahedron_Vertex(&Vhead[0],&Thead[0]);
 if (Nrecur>1)
  Make_Recursive_Icosahedron_Vertex(Vhead,Thead,Nrecur);

 /*** Make Probe Spheres using Icosahedron templates (Vhead,Thead) ***/
 an = Ahead; bn = NULL; cn = NULL;
 Phead->next = NULL;
 Nprobe = 0;
 while (an->next != NULL)
 {
  an = an->next;
  R = an->R + Rprobe;
  for (r=0;r<Nrecur;++r)
  {
    vn = &Vhead[r];  Nver = 0;
    while (vn->next != NULL)
    { 
      vn = vn->next; ++Nver;
      for (m=0;m<3;++m) Ppos[m] = an->Pos[m] + R*vn->Pos[m];
   /*
      for (i=0;i<3;++i)
       { val  = (Ppos[i] - cvox.min[i])/cvox.gridlen; 
         residual  = val -(int)(val);
         if (residual>0.5) I[i]  = ceil(val); else I[i] = floor(val); }
   */
   IntXYZ_from_FloatXYZ(I,Ppos,&cvox);

 
/*   
       printf("#%d %d %d -->",I[0],I[1],I[2]);fflush(stdout);
       printf(" %d\n",cvox.map[I[0]][I[1]][I[2]]); fflush(stdout);
 */  
/*
      if (cvox.map[I[0]][I[1]][I[2]]==255)
        printf("#COLLIDE !! %d %d %d %d\n",I[0],I[1],I[2],cvox.map[I[0]][I[1]][I[2]]);
*/
      if ((cvox.map[I[0]][I[1]][I[2]]!=255)&&(Check_Crash_Pos_and_Atoms(Ppos,Rprobe,Ahead)==0))
       { Add_Atom_Stack(Phead,Ppos,Rprobe,'I',Nprobe,an,bn,cn); 
         vn->mark = 1; ++Nprobe; }
     else vn->mark = 0;
     } /* vn */
  } /* r */

 } /* an */

 Renumber_AnumRnum(Phead);
 Free_Col_Voxel(&cvox, cvox.N[0],cvox.N[1],cvox.N[2]);

} /* end of Make_Probe_Sphres_Icosahedron_ColVoxel() */







void Make_Probe_Spheres_Icosahedron_Recursive(Phead,Ahead,Rprobe,Nrecur)
 struct ATOM *Phead;
 struct ATOM *Ahead;
 float Rprobe;
 int   Nrecur;
{
 struct VERTEX   Vhead[MAX_RECUR];
 struct TRIANGLE Thead[MAX_RECUR];
 struct ATOM *an,*bn,*cn;
 struct VERTEX   *vn;
 struct TRIANGLE *tn;
 int Nprobe,r,m,Nver;
 float R,Ppos[3];

 printf("#Make_Probe_Spheres_Icosahedron(Rprobe %f Nrecur %d)\n",Rprobe,Nrecur);
 if (Nrecur >= MAX_RECUR) 
 { printf("#ERROR:Nrecur %d is over MAX_RECUR %d\n",Nrecur,MAX_RECUR);
   exit(1); }
 
 /*** Make Template Spheres for Icosahedron  (Vhead, Thead) ***/
 Make_Icosahedron_Vertex(&Vhead[0],&Thead[0]);
 if (Nrecur>1)
  Make_Recursive_Icosahedron_Vertex(Vhead,Thead,Nrecur);

 /*** Make Probe Spheres using Icosahedron templates (Vhead,Thead) ***/
 an = Ahead;
 Phead->next = NULL;
 Nprobe = 0;
 while (an->next != NULL)
 {
  an = an->next;
  R = an->R + Rprobe;

  Vertex_Mark_Set(&Vhead[0],1);
  for (r=1;r<Nrecur;++r) Vertex_Mark_Set(&Vhead[r],0);

  for (r=0;r<Nrecur;++r)
  {
    /* Check exposure using previous phase of triangles */
    if (r>0) 
    {
      tn = &Thead[r-1]; 
      while (tn->next != NULL)
      {
       tn = tn->next;
       if( (tn->an->mark == 1)|| (tn->bn->mark == 1)|| (tn->cn->mark == 1) )
         tn->pn->mark = tn->qn->mark = tn->rn->mark = 1;
       }
    }
 
    vn = &Vhead[r];  Nver = 0;
  
    while (vn->next != NULL)
    { 
      vn = vn->next; 
      if (vn->mark == 1)
      { 
       for (m=0;m<3;++m) Ppos[m] = an->Pos[m] + R*vn->Pos[m];
       if (Check_Crash_Pos_and_Atoms(Ppos,Rprobe,Ahead)==0)
        { Add_Atom_Stack(Phead,Ppos,Rprobe,'I',Nprobe,an,bn,cn); 
          vn->mark = 1; ++Nprobe; } else vn->mark = 0;
       }
     } /* vn */
  
   } /* r */

 } /* an */

 Renumber_AnumRnum(Phead);

} /* end of Make_Probe_Sphres_Icosahedron_Recursive() */









void Make_Icosahedron_Vertex(Vhead,Thead)
 struct VERTEX   *Vhead;
 struct TRIANGLE *Thead;
{
 float Ppos[3],Pos[3],R;
 float Ipos[12][3];  /* 12 vertices of icosahedron */
 int i,m,Nok;
 double sqrt5,sin_th,cos_th,phi;
 struct VERTEX *Iver[12]; 
 struct VERTEX *vn,*pn,*qn,*rn;
 struct TRIANGLE *tn;
 int r,Nver,Ntri;
 
 printf("#Make_Icosahedron_Vertex(Vhead,Thead)\n");
 /*** Set 12 vertices of icosahedron for radius 1.0 **/
 sqrt5  = sqrt(5.0);
 sin_th = 2*sqrt(2)*sqrt(3-sqrt5)/(5-sqrt5);
 cos_th = (-1+sqrt5)/(5-sqrt5);
 Ipos[0][0] = 0.0; Ipos[0][1] = 0.0; Ipos[0][2] = 1.0;
 for (i=1;i<=5;++i)
 { phi = 2*M_PI/5.0*(i-1);
   Ipos[i][0] = sin_th * cos(phi);
   Ipos[i][1] = sin_th * sin(phi);
   Ipos[i][2] = cos_th; }

 for (i=6;i<=10;++i)
 { phi = 2*M_PI/5.0*(i-6) + 2*M_PI/10.0 ;
   Ipos[i][0] = sin_th*cos(phi);
   Ipos[i][1] = sin_th*sin(phi);
   Ipos[i][2] = -1.0 + cos_th; }

 Ipos[11][0] = 0.0; Ipos[11][1] = 0.0; Ipos[11][2] = -1.0;

 Vhead->next = NULL;
 for (i=0;i<12;++i)
 {
  /* printf("%d %f %f %f\n",i,Ipos[i][0],Ipos[i][1],Ipos[i][2]);  */
  Iver[i] = Add_Vertex_Stack(Vhead,Ipos[i],i);
 }

 /*
 vn = Vhead;
 while (vn->next != NULL)
 { vn = vn->next; 
   printf("ver %d %f %f %f\n",vn->num,vn->Pos[0],vn->Pos[1],vn->Pos[2]); }
 */

  Thead->next = NULL; 
  Add_Triangle_Stack(Thead,Iver[0],Iver[1],Iver[2]);
  Add_Triangle_Stack(Thead,Iver[0],Iver[2],Iver[3]);
  Add_Triangle_Stack(Thead,Iver[0],Iver[3],Iver[4]);
  Add_Triangle_Stack(Thead,Iver[0],Iver[4],Iver[5]);
  Add_Triangle_Stack(Thead,Iver[0],Iver[5],Iver[1]);

  Add_Triangle_Stack(Thead,Iver[11],Iver[6],Iver[7]);
  Add_Triangle_Stack(Thead,Iver[11],Iver[7],Iver[8]);
  Add_Triangle_Stack(Thead,Iver[11],Iver[8],Iver[9]);
  Add_Triangle_Stack(Thead,Iver[11],Iver[9],Iver[10]);
  Add_Triangle_Stack(Thead,Iver[11],Iver[10],Iver[6]);
  
  Add_Triangle_Stack(Thead,Iver[1],Iver[2],Iver[6]);
  Add_Triangle_Stack(Thead,Iver[2],Iver[3],Iver[7]);
  Add_Triangle_Stack(Thead,Iver[3],Iver[4],Iver[8]);
  Add_Triangle_Stack(Thead,Iver[4],Iver[5],Iver[9]);
  Add_Triangle_Stack(Thead,Iver[5],Iver[1],Iver[10]);

  Add_Triangle_Stack(Thead,Iver[6],Iver[7],Iver[2]);
  Add_Triangle_Stack(Thead,Iver[7],Iver[8],Iver[3]);
  Add_Triangle_Stack(Thead,Iver[8],Iver[9],Iver[4]);
  Add_Triangle_Stack(Thead,Iver[9],Iver[10],Iver[5]);
  Add_Triangle_Stack(Thead,Iver[10],Iver[6],Iver[1]);

  /*
  tn = Thead;
  while (tn->next != NULL)
  { tn = tn->next; 
   printf("%d %d %d\n",tn->an->num,tn->bn->num,tn->cn->num); }
  */


} /* end of Make_Icosahedron_Vertex() */






void  Make_Recursive_Icosahedron_Vertex(Vhead,Thead,Nrecur)
 struct VERTEX *Vhead; 
 struct TRIANGLE *Thead; 
 int Nrecur;
{
 float Ppos[3],Pos[3],R;
 int i,m,Nok;
 struct VERTEX *vn;
 struct TRIANGLE *tn;
 int r,Nver,Ntri;
 char fname[128];
 
 printf("#Make_Recursive_Icosahedron_Vertex(Nrecur %d)\n",Nrecur);
 /*** Set Nrecur >=1 vertex and triangles ***/
 Nver = 12; Ntri = 20;
  
 for (r=1;r<Nrecur;++r)
  {
   Vhead[r].next = NULL;
   Thead[r].next = NULL;
   tn = &(Thead[r-1]);
   printf("#recursive %d\n",r); 
   while (tn->next != NULL)
   {
    tn = tn->next;
    tn->pn = tn->qn = tn->rn = NULL; 
    /* 
    printf("try triangle %d %d %d\n",tn->an->num,tn->bn->num,tn->cn->num);
    */
 
    tn->pn = Find_Vertex_Parent(&(Vhead[r]),tn->an,tn->bn);
    if (tn->pn==NULL)
    { for (m=0;m<3;++m)  Pos[m] = 0.5*(tn->an->Pos[m] + tn->bn->Pos[m]);
      Normalize(Pos);  
      tn->pn = Add_Vertex_Stack_Parent(&(Vhead[r]),Pos,Nver,tn->an,tn->bn); ++Nver; }

    tn->qn = Find_Vertex_Parent(&(Vhead[r]),tn->bn,tn->cn);
    if (tn->qn==NULL)
     { for (m=0;m<3;++m)  Pos[m] = 0.5*(tn->bn->Pos[m] + tn->cn->Pos[m]);
       Normalize(Pos);  
       tn->qn = Add_Vertex_Stack_Parent(&(Vhead[r]),Pos,Nver,tn->bn,tn->cn); ++Nver; }

    tn->rn = Find_Vertex_Parent(&(Vhead[r]),tn->cn,tn->an);
    if (tn->rn==NULL)
    { for (m=0;m<3;++m)  Pos[m] = 0.5*(tn->cn->Pos[m] + tn->an->Pos[m]);
      Normalize(Pos);  
      tn->rn = Add_Vertex_Stack_Parent(&(Vhead[r]),Pos,Nver,tn->cn,tn->an); ++Nver; }

   
    Add_Triangle_Stack(&(Thead[r]),tn->an,tn->pn,tn->rn);
    Add_Triangle_Stack(&(Thead[r]),tn->pn,tn->bn,tn->qn);
    Add_Triangle_Stack(&(Thead[r]),tn->rn,tn->qn,tn->cn);
    Add_Triangle_Stack(&(Thead[r]),tn->pn,tn->qn,tn->rn);
    Ntri += 4;
    }

   printf("%d recur Nver %d Ntri %d\n",r,Nver,Ntri);


   /*

   vn = &(Vhead[r]);
   while (vn->next != NULL)
  { vn = vn->next; 
    printf("ver %d x %d y %d %f %f %f\n",vn->num,
    vn->xn->num, vn->yn->num, vn->Pos[0],vn->Pos[1],vn->Pos[2]); }

   tn = &(Thead[r]);
   while (tn->next != NULL)
   { tn = tn->next; 
     if (tn->an != NULL) printf(" %d",tn->an->num); else printf(" null"); 
     if (tn->bn != NULL) printf(" %d",tn->bn->num); else printf(" null"); 
     if (tn->cn != NULL) printf(" %d",tn->cn->num); else printf(" null"); 
     printf("\n");
   }

  */

 } /* r */

 /*
 for (r=0;r<Nrecur;++r)
 {
   sprintf(fname,"ver%d.pdb",r); 
   Write_Vertex_In_PDB(fname,&(Vhead[r]));
 }
 */

} /* end of Make_Recursive_Icosahedron_Vertex() */






struct VERTEX* Add_Vertex_Stack(Vhead,pos,num)
 struct VERTEX *Vhead;
 float pos[3];
 int   num;
{
 struct VERTEX *an,*nn;
  int i; 
	   
  nn = Vhead->next;
  Vhead->next = (struct VERTEX*)malloc(sizeof(struct VERTEX));
  an = Vhead->next;
  an->next = nn;
 
  for (i=0;i<3;++i) an->Pos[i] = pos[i];
  an->num = num;
  an->mark = 0;
  an->xn = NULL; an->yn = NULL;
  return(an);
 
} /* end of Add_Vertex_Stack() */


struct VERTEX* Add_Vertex_Stack_Parent(Vhead,pos,num,xn,yn)
 struct VERTEX *Vhead;
 float pos[3];
 int   num;
 struct VERTEX *xn,*yn;
{
 struct VERTEX *an,*nn;
  int i; 
	   
  nn = Vhead->next;
  Vhead->next = (struct VERTEX*)malloc(sizeof(struct VERTEX));
  an = Vhead->next;
  an->next = nn;
  for (i=0;i<3;++i) an->Pos[i] = pos[i];
  an->num = num;
  an->mark = 0;
  if (xn->num < yn->num) {an->xn = xn; an->yn = yn; }
                    else {an->xn = yn; an->yn = xn; }

  return(an);
 
} /* end of Add_Vertex_Stack_Parent() */



struct VERTEX* Find_Vertex_Parent(Vhead,xn,yn)
 struct VERTEX *Vhead;
 struct VERTEX *xn,*yn;
{
  struct VERTEX *vn;
  struct VERTEX *Xn,*Yn;
  char xok,yok;
  if (xn->num < yn->num) {Xn = xn; Yn = yn;}	
                    else {Xn = yn; Yn = xn;}	
  vn = Vhead;

  while (vn->next != NULL)
  {
   vn = vn->next;
   if ((vn->xn!=NULL)&&(vn->xn->num == Xn->num) &&
       (vn->yn!=NULL)&&(vn->yn->num == Yn->num)  ) return(vn);
   } 
 
  return(NULL);
 
} /* end of Find_Vertex_Parent() */







struct TRIANGLE* Add_Triangle_Stack(Thead,an,bn,cn)
 struct TRIANGLE *Thead;
 struct VERTEX *an,*bn,*cn;
{
  struct TRIANGLE *tn,*nn;
  int i; 

  /* 
  printf("#Add_Triangle_Stack");
  if (an != NULL) printf(" %d",an->num); else printf(" null"); 
  if (bn != NULL) printf(" %d",bn->num); else printf(" null"); 
  if (cn != NULL) printf(" %d",cn->num); else printf(" null"); 
  printf("\n");
  */
 
  nn = Thead->next;
  Thead->next = (struct TRIANGLE*)malloc(sizeof(struct TRIANGLE));
  tn = Thead->next;
  tn->next = nn;
 
  tn->an  = an;
  tn->bn  = bn;
  tn->cn  = cn;

  tn->pn  = NULL; tn->qn  = NULL; tn->rn  = NULL;

} /* end of Add_Triangle_Stack() */



void Normalize(X)
 float X[3];
{
 float D;
 D = X[0]*X[0] + X[1]*X[1] + X[2]*X[2];
 if (D>0.0)
 { D = sqrt(D);
   X[0] /= D; X[1] /= D; X[2] /= D; }
} /* end of Normalize() */



void Write_Vertex_In_PDB(fname,Vhead)
 char *fname;
 struct VERTEX *Vhead;
{
 FILE *fp;
 struct VERTEX *an;

 printf("#Write_DB_File -> \"%s\"\n",fname);
 fp = fopen(fname,"w");
 if (fp==NULL) { printf("#ERROR:Can't write to \"%s\"\n",fname); exit(1);}

 an = Vhead;
 while (an->next != NULL)
 {
  an = an->next;
  fprintf(fp,"ATOM  ");
  fprintf(fp,"%5d %4s %3s %c%5d   %8.3f%8.3f%8.3f\n",
       an->num,"CA","ISO",' ',an->num, 10*an->Pos[0],10*an->Pos[1],10*an->Pos[2]);

 } /* while */
  fprintf(fp,"END\n");
 fclose(fp);

} /* end of Write_Vertex_In_PDB() */


void Vertex_Mark_Set(Vhead,val)
 struct VERTEX *Vhead;
 char val;
{
 struct VERTEX *vn;

 vn = Vhead;
 while (vn->next != NULL)
 { vn = vn->next;
   vn->mark = val; }

} /* end of Vertex_Mark_Set() */

