/*
 <Cluster.h>

*/

extern void Make_Cluster_Of_Atoms();
extern void Cal_Volume_Of_Residues();
extern float All_Volume_Of_Residues();
extern void Reorder_Atom_By_Residue();
extern void Write_Contact_Atoms_For_Each_Cluster();
extern void Assign_Contact_Cluster_For_Each_Residue();
extern void Remove_Small_Clusters();
