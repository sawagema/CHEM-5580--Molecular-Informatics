/*

<pdbstructs.h>

Definition of basic structures

*/

#define MAX_MEMORY_MEGA 1000

struct RADIUS{
 char   Atom[5];
 char   Resi[4];
 float  R;
 struct RADIUS *next,*prev;
};

struct OVERLAP{
 struct ATOM    *atom;
 struct OVERLAP *next;
};


struct NEIGHBOR_ATOM{
 struct ATOM *atom;
 struct NEIGHBOR_ATOM *next,*prev;
};



/** Face (spherical triangle face) for "Spherical Hull" */
struct SH_FACE{
 int    num;
 struct ATOM *atom[3]; /* counter-clockwise from outside (0->1->2) */
 float  nvec[3];       /* Normal Vector */
 float  tpnt[3][3];    /* Three tanget points [0,1,2][x,y,z] */
 float  R;             /* Radius */
 float  RR;            /* Radius * Radius */
 float  Cen[3];        /* Center of Sphere with radius R */
 char   visible;       /* Mark for visibility (0 or 1)   */
 char   type;
 struct ATOM *probe;    /* Pointer to corresponding probe sphere */
 struct  SH_FACE *next,  *prev;  /* Pointer for the standard linked list */
};




/** ATOM : for both protein atoms and probe spheres */
struct ATOM{
 float Pos[3];        /* X,Y,Z coordinates */
 float R;             /* Radius            */ 
 float RR;            /* Radius^2          */ 
 int   num;           /* Atom Number (0...Natom-1)*/
 int   rnum;          /* Residue Number */
 char  Anum[7];       /* Atom Number String */
 char  Atom[5];       /* Name of Atom */
 char  Resi[5];       /* Name of Residue */
 char  Rnum[6];       /* Residue Number String */
 char  Chain;         /* Chain ID */
 char  altLoc;        /* Alternate location indicator */
 float Occup;         /* Occupancy */ 
 float tFactor;       /* Temparature Factor */ 
 char  AHtype;        /* 'A'tom, 'H'etatm */
 float  ASA;
 struct ATOM *next,*prev;    /* Pointer for atom list (bi-direction) */
 struct RESIDUE *res;        /* Pointer to corresponding residues */
 struct ATOM *rnext,*rprev;  /* Pointer for the list from RESIDUE (bi-direction)*/
 char   region;
 char   mark;           /* Mark for various purpose */
 struct ATOM *con[3];   /* Pointer to Contacted Protein Atoms (only for probe spheres)*/ 
 struct OVERLAP Ohead;  /* Pointer to overlapped atoms        */
 float  Vprobe;         /* Volume of Contacted Probes */
 /*** For calculating convex hull / spherical hull ***/
 float nvec[3];   /* Normal Vector from ConvexHull triangles */
 int    Nedge;    /* Number of edges connected with this atom */
 char   surface;  /* 1:on the surface. (Node of spherical triangle) */ 
 char   subtype;  /* Type for various purpose */
 float  value;    /* Value for various purpose such as "SortAtom.c" */  
 struct NEIGHBOR_ATOM  NAhead;  /* Head for Neighboring Atoms */
 char   indRlarge; /* Index for Rlarge for calculate Rlarge_max in "MulRlarge.c" */
};



/** RESIDUE : for both protein residues and probe clusters */
struct RESIDUE{
 int    num;           /* Residue Number */
 char   Resi[5];       /* Name of Residue */
 char   Rnum[6];       /* Residue Number String */
 char   Chain;         /* Chain ID */
 int    Natom;         /* Number of Atoms */ 
 float  Vresidue;      /* Volume of all the atoms belong to this residue */
 int    Nprobe_surf;   /* Number of Contacted Probes before removing by Rlarge probe spheres */
 float  Vprobe;        /* Volume of Contacted Probes */
 int    Nprobe;        /* Number of Contacted Probes */
 float  Vcluster;      /* Volume of Largest Contacted Probe Cluster */
 char   *con_clus;     /* [Ncluster] : String of Contacted Cluster Number (malloc later) */       
 struct RESIDUE *next,*prev; /* Pointer for RESIDUE list (bi-direction) */
 struct ATOM    Ahead; /* Head of ATOM list, belonged to the residue (using ATOM->rnext, rprev) */
 float  value;         /* Value for various purpose such as Sorting */  
 float  Racc;          /* Raccess  calculated by "MulRlarge.c"   */    
 int    *Nprobe_multi; /* [NRlarge] only malloced for "MulRlarge.c" */
};




/** MATRIX : simple 2D matrix for general purpose **/
struct MATRIX{
 int   N;     /* Number of rows and columns        */
 float **m;  /* 2D valiable: M[1..N][1..N]   */
};




/** PARAMETERS: for globally defined important parameters **/
struct PARAMETERS{
 char   COMMAND[256];
 char   HETtype;   /* Read HETATM ('T' or 'F') */
 char   radfile[128];
 char   REGION;    /* 'T':regionA and regionB are assigned */
 /* For Marching Cube */
 float  cvox_grid; /* Grid Size for ColVoxel */
 float  vvox_grid; /* Grid Size for Volume Calculation */
 float  Phardsp;  /* Densitity value for hard sphere shell */
 char   SpType;   /* Type of Sphere Distribution 'H'ardsphere 'G'auss 'S'igmoid */
 float  Asigmoid; /* Parameter for Sigmoid functions */
 char   SumType;  /* 'N'ormal Take 'M'ax value */
 int    Ncolor;   /* Number of Color */
 /* For Reading PDB */
 char   Het2Atm;         /*  Change HETATM to ATOM for group with (N,CA,C). (T or F) */
 /* Others */
 char   SubType;        /* Type for Various Purpuse */
 float  Lcrash_permit;  /* Permissible Crash Length (Angstrom) */
 float  eps;            /* Very small number for numerical calculation (Angstrom) */
 char   Vtype;          /* Visible for progress of calculation */ 
};


/** GLOBAL VARIABLES **/

extern struct PARAMETERS PAR;

