/*
 <DifSpCnvHul.h>
*/

/*** FUNCTIONS ***/
extern void ConstructHull_DifSp();
extern int  Initial_Double_Triangle_DifSp();
extern void Output_Faces_VRML_DifSp();
extern int  Free_Faces_DifSp();
extern void Remove_Atoms_Crashed_With_Planes();
extern void Write_PDB_File_Planes();
