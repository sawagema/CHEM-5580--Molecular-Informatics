/*
 <Radius.c>
 
 Functions for assigning radius to atoms

 coded by Takeshi Kawabata (takawaba@is.naist.jp)

*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <strings.h>
#include "pdbstruct.h" 
#include "defradius.h" 

/*** FUNCTIONS (GLOBAL) ***/
void Read_Radius_File();
void Set_Default_Radius();
void Set_Unified_Radius();
void Assign_Radius();
void Assign_Unified_Radius();
void Assign_Occup_Radius();


/*** FUNCTIONS (LOCAL) ***/
static int Match();
static void Get_Part_Of_Line();


void Read_Radius_File(fname,Rhead)
 char *fname;
 struct RADIUS *Rhead;
{
 FILE *fp;
 char line[128],atom[5],resi[4],buff[32];
 int i,L;
 struct RADIUS *rn;

 fp = fopen(fname,"r");
 if (fp==NULL){printf("#ERROR:Can't open radius file \"%s\"\n",fname); exit(1);}

 rn = Rhead;
 rn->next = rn->prev = NULL;
 
 while (feof(fp)==0)
 { 
  line[0] = '\0';
  fgets(line,127,fp); 
  L = strlen(line);
  if ((line[0] != '#')&&(L>5))
  {
   Get_Part_Of_Line(atom,line,0,3);
   Get_Part_Of_Line(resi,line,5,7);
   Get_Part_Of_Line(buff,line,8,L-1);
   rn->next = (struct RADIUS *)malloc(sizeof(struct RADIUS));
   rn->next->prev = rn;
   rn->next->next = NULL;
   rn  = rn->next; 
   sprintf(rn->Atom,"%s",atom); 
   sprintf(rn->Resi,"%s",resi); 
   rn->R = atof(buff); 
  }  
 } 
 fclose(fp);

} /* end of Read_Radius_File() */







void Set_Default_Radius(Rhead)
 struct RADIUS *Rhead;
{
 char line[128],atom[5],resi[4],buff[32];
 int i,L;
 struct RADIUS *rn;

 rn = Rhead;
 rn->next = rn->prev = NULL;

 for (i=0;i<NRADLINE;++i)
 { 
  sprintf(line,"%s",RADLINE[i]); 
  L = strlen(line);
  if ((line[0] != '#')&&(L>5))
  {
   Get_Part_Of_Line(atom,line,0,3);
   Get_Part_Of_Line(resi,line,5,7);
   Get_Part_Of_Line(buff,line,8,L-1);
   rn->next = (struct RADIUS *)malloc(sizeof(struct RADIUS));
   rn->next->prev = rn;
   rn->next->next = NULL;
   rn  = rn->next; 
   sprintf(rn->Atom,"%s",atom); 
   sprintf(rn->Resi,"%s",resi); 
   rn->R = atof(buff); 
  }  
 } 

} /* end of Set_Default_Radius() */



void Set_Unified_Radius(Rhead,radius)
 struct RADIUS *Rhead;
 float radius;
{
 char atom[5],resi[4];
 struct RADIUS *rn;

 rn = Rhead;
 rn->next = rn->prev = NULL;

 rn->next = (struct RADIUS *)malloc(sizeof(struct RADIUS));
 rn->next->prev = rn;
 rn->next->next = NULL;
 rn  = rn->next; 
 sprintf(rn->Atom,"xxx"); 
 sprintf(rn->Resi,"xxx"); 
 rn->R = radius; 

} /* end of Set_Unified_Radius() */




void Assign_Radius(Ahead,Rhead)
 struct ATOM   *Ahead;
 struct RADIUS *Rhead;
{
 struct ATOM   *an;
 struct RADIUS *rn;
 char hit;

 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  rn = Rhead;
  hit = 0;
  while ((hit==0)&&(rn->next != NULL))
  {
   rn = rn->next;
   if ((Match(rn->Resi,3,an->Resi,0)==1) &&
       (Match(rn->Atom,3,an->Atom,0)==1) )
   {hit = 1; 
    an->R = rn->R; 
    an->RR = an->R * an->R;
    }
  }
 } /* an */

} /* end of Assign_Radius() */


void Assign_Unified_Radius(Ahead,Radius)
 struct ATOM   *Ahead;
 float  Radius;
{
 struct ATOM   *an;
 printf("#Assign_Unified_Radius(Radius %f)\n",Radius);
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  an->R = Radius; 
  an->RR = an->R * an->R;
 } /* an */

} /* end of Assign_Unified_Radius() */


void Assign_Occup_Radius(Ahead)
 struct ATOM   *Ahead;
{
 struct ATOM   *an;
 printf("#Assign_Occup_Radius()\n");
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  an->R = an->Occup; 
  an->RR = an->R * an->R;
 } /* an */

} /* end of Assign_Occup_Radius() */





int Match(Pat,plen,Str,offset)
 char *Pat;
 int  plen;
 char *Str;
 int offset;
{
  /*** Strict Pattern Matching ***/

  int i,j,ok,slen;
  char psym,ssym;

  slen = strlen(Str);
  if ((plen==0)||(slen==0)) return(0);

  if (slen>=plen)
  {
   for (i= offset;i<(slen - plen+1);++i)
    { ok = 1; j = 0;
      while ((ok==1) && (j<plen))
      {
       if ((Pat[j]!='x')&&(Pat[j] != Str[i+j])) { ok = 0; }
       ++j; }

     if (ok==1) return(1);
   }

  }
 return(0);

} /* end of Match */




void Get_Part_Of_Line(part,line,s,e)
  char *part;
  char *line;
  int  s,e;
{
 int i,E,L;
 L = strlen(line)-1;
 if (line[L] == '\n') L -= 1;
 if (e>L) E = L; else E = e;
 for (i=s;i<=E;++i) part[i-s] = line[i];
 part[E-s+1] = '\0';

} /* end of Get_Part_of_Line() */

