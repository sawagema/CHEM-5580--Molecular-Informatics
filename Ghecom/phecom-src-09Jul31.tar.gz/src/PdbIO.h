/*

 <PdbIO.h>

*/

extern void Read_PDB_File();
extern void Write_PDB_File();
extern void Write_PDB_File_Probe();
extern void Write_PDB_File_Residue();
extern void Read_PDB_File_Probes();
extern void Set_Pseudo_Three_Contacting_Atoms_To_Probes();
extern void Delete_Probes_DoNot_Contact_Protein();
extern void Find_Filename_Core();
extern void Get_Part_Of_Line();
extern char *Get_Date_String();
extern char *Get_Date_String_PDB();
extern int Number_Of_Atom();
extern int Number_Of_Residue();
extern int Number_Of_Chain();
extern void Malloc_MATRIX();
extern void Free_MATRIX();
extern int  Free_ATOMs();
extern void Cal_Distance_MATRIX();
extern void Set_Region_Of_Atoms();
extern void Write_Residue_File();
extern void Set_AtomName_Of_Probes_By_Contacted_Three_Atoms();
extern void Set_Constant_tFactor();
extern void Renumber_Atom_Number();
extern void Renumber_Residue_Number();
extern void Add_Atom_To_Residue_Head();
extern void Add_Atom_To_Residue_Tail();
extern void Output_Residues_Atoms();
extern void Write_PDB_File_With_Nvec();
extern void Write_Comment_PDB_Remark();
