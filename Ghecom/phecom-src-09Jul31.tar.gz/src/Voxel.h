/*

 <Voxel.h>

*/

struct VOXEL{
 int   N[3];     /* Number of XYZ column 0:X, 1:Y, 2:Z */  
 float gridlen;  /* Grid Length  */ 
 float min[3];   /* Real XYZ coordinates on the grid (0,0,0) */
 float G[3];     /* Center of Gravity */
 char mal;       /* 1:already malloced 0: not malloced */
 float ***dat;   /* [0..X-1][0..Y-1][0..Z-1] */
};


extern void Malloc_Voxel();
extern void Free_Voxel();
extern void Cal_Voxel_Of_PDB();
extern void Write_Voxel_File();
extern void Cal_Density_Of_Molecule();
extern void Cal_Size_Of_Voxel_By_Molecule();
