/*
 
 <SortAtom.h>

*/
extern void Sort_Atom_Order_From_Gravity_Center();
extern void Sort_Atom_Order_From_Gravity_Center_Atom();
extern void Sort_Atom_Order_From_Gravity_Center_Atom_MinDis();
extern void Check_Distance_Jump_Between_Previous_Atoms();
extern void Recover_Atom_Order_By_Atom_Number();
extern void Resort_Distance_Isolated_Atoms_After_The_Closest();
extern void Resort_Distance_Isolated_Atoms_To_The_End();
