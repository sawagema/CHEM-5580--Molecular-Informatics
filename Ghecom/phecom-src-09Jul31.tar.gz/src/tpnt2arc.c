/*

 <tpnt2arc.c> 
 
 A program for chaning tangent point file to spherical arcs 
 
 coded by Takeshi Kawabata (takawaba@is.naist.jp)

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <math.h>

static char LastModDate[] = "Mar 2, 2008";

 
/*** Structure for Tangent Poitn Atom ***/
/*
REMARK #atm  atm res  #res       Xtpnt   Ytpnt   Ztpnt  Rprb  #prb #atm1#atm2#atm3    Xprb    Yprb    Zprb
*/

struct TANPNT{
 float Pos[3];        /* X,Y,Z coordinates */
 float R;             /* Radius            */
 int   num;           /* Atom Number */
 int   rnum;          /* Residue Number */
 char  Anum[7];       /* Atom Number String */
 char  Atom[5];       /* Name of Atom */
 char  Resi[5];       /* Name of Residue */
 char  Rnum[6];       /* Residue Number String */
 char  Chain;         /* Chain ID */
 char  altLoc;        /* Alternate location indicator */
 float Occup;         /* Occupancy */
 float tFactor;       /* Temparature Factor */
 char  AHtype;        /* 'A'tom, 'H'etatm */
 struct TANPNT *next,*prev;  /* Pointer for atom list */
 int   PrbNum;        /* Probe Number */
 int   ConAtmNum[3];  /* Contacted Atom Number */   
 float PrbCen[3];     /* X,Y,Z coordinates of probe center */ 
};



/*** Function (LOCAL) ***/
static void Write_Spherical_Triangle_In_Gnuplot();
static void Write_Spherical_Triangle_In_VRML();
static void Write_Arc_In_Gnuplot();
static void Write_Arc_In_VRML();
static void Cal_XY_axis_from_A_B_O();
static void Read_Tangent_Point_PDB_File();
static void Get_Part_Of_Line();
static void Sub_Vec();
static void Equal_Vec();
static void Normalize();
static float Dot_Prod();


main(argc, argv)
 int argc;
 char **argv;
{
 struct TANPNT TpntHead;
 int  Nang_div,i;
 char tpntfile[512],Otype,outfile[512];
 
 Nang_div = 10;
 
 if (argc<3)
 {
  printf("tpnt2arc [tpntfile] [Type('G'nuplot or 'V'rml)] [outputfile] (Ndiv[%d])\n",Nang_div);
  printf(" for chaning tangent point file to spherical arcs.\n");
  printf(" coded by T.Kawabata. LastModified:%s\n",LastModDate);   
  exit(1); 
 } 
 sprintf(tpntfile,"%s",argv[1]);
 Otype = argv[2][0]; 
 sprintf(outfile,"%s",argv[3]);
 if (argc>4) Nang_div = atoi(argv[4]);

 Read_Tangent_Point_PDB_File(tpntfile,&TpntHead);

 if (Otype=='G') Write_Spherical_Triangle_In_Gnuplot(outfile,&TpntHead,Nang_div);
 if (Otype=='V') Write_Spherical_Triangle_In_VRML(outfile,&TpntHead,Nang_div);

} /* end of main() */


/*****************/
/*** FUNCTIONS ***/
/*****************/

void Write_Spherical_Triangle_In_Gnuplot(ofname,Thead,Nang_div)
 char   *ofname;
 struct TANPNT *Thead;
 int  Nang_div;
{
 struct TANPNT *tn,*an,*bn,*cn;
 float X[3],Y[3],Theta,th;
 FILE *fpo;
 
 printf("#Write_Spherical_Triangle_In_Gnuplot() --> \"%s\"\n",ofname);
 fpo = fopen(ofname,"w");
 if (fpo==NULL){printf("#ERROR:Can't write to arcfile \"%s\"\n",ofname); exit(1); }
 
 tn = Thead;
 an = bn = cn = NULL;
 while (tn->next != NULL)
 {
  tn = tn->next;
  
  if ((an==NULL)&&(bn==NULL)&&(cn==NULL)&&(tn->next!=NULL)&&( tn->next->next != NULL))
  {
   an = tn; 
   bn = tn->next;
   cn = tn->next->next;
 
   Cal_XY_axis_from_A_B_O(X,Y,&Theta,an->Pos,bn->Pos,an->PrbCen);
   Write_Arc_In_Gnuplot(fpo,an->R,X,Y,an->PrbCen,Theta,Nang_div);

   Cal_XY_axis_from_A_B_O(X,Y,&Theta,bn->Pos,cn->Pos,an->PrbCen);
   Write_Arc_In_Gnuplot(fpo,an->R,X,Y,an->PrbCen,Theta,Nang_div);

   Cal_XY_axis_from_A_B_O(X,Y,&Theta,cn->Pos,an->Pos,an->PrbCen);
   Write_Arc_In_Gnuplot(fpo,an->R,X,Y,an->PrbCen,Theta,Nang_div);

   tn = tn->next->next;
   an = bn = cn = NULL;  
  } 

 } /* tn */

 fclose(fpo);

} /* end of Write_Spherical_Triangle_In_Gnuplot() */




void Write_Spherical_Triangle_In_VRML(ofname,Thead,Nang_div)
 char   *ofname;
 struct TANPNT *Thead;
 int  Nang_div;
{
 struct TANPNT *tn,*an,*bn,*cn;
 float X[3],Y[3],Theta,th;
 FILE *fpo;
 int Nface,i, j,k;
 
 printf("#Write_Spherical_Triangle_In_VRML() --> \"%s\"\n",ofname);
 fpo = fopen(ofname,"w");
 if (fpo==NULL){printf("#ERROR:Can't write to arcfile \"%s\"\n",ofname); exit(1); }

 /** OUTPUT HEADER **/
 fprintf(fpo,"#VRML V2.0 utf8\n"); 
 
 fprintf(fpo,"Transform{\n");
 fprintf(fpo," translation 0.0 0.0 0.0\n");
 fprintf(fpo,"children[\n");
 fprintf(fpo,"Shape{\n");
 fprintf(fpo," geometry IndexedLineSet{\n");


 /** Output Points XYZ Coordinates **/
 fprintf(fpo,"  coord Coordinate{\n");
 fprintf(fpo,"   point[\n");
 
 tn = Thead; Nface = 0;
 an = bn = cn = NULL;
 while (tn->next != NULL)
 {
  tn = tn->next;
  
  if ((an==NULL)&&(bn==NULL)&&(cn==NULL)&&(tn->next!=NULL)&&( tn->next->next != NULL))
  {
   an = tn; 
   bn = tn->next;
   cn = tn->next->next;
 
   Cal_XY_axis_from_A_B_O(X,Y,&Theta,an->Pos,bn->Pos,an->PrbCen);
   Write_Arc_In_VRML(fpo,an->R,X,Y,an->PrbCen,Theta,Nang_div);
   fprintf(fpo,",\n");
   Cal_XY_axis_from_A_B_O(X,Y,&Theta,bn->Pos,cn->Pos,an->PrbCen);
   Write_Arc_In_VRML(fpo,an->R,X,Y,an->PrbCen,Theta,Nang_div);
   fprintf(fpo,",\n");

   Cal_XY_axis_from_A_B_O(X,Y,&Theta,cn->Pos,an->Pos,an->PrbCen);
   Write_Arc_In_VRML(fpo,an->R,X,Y,an->PrbCen,Theta,Nang_div);
   if (cn->next!=NULL) fprintf(fpo,",\n"); else fprintf(fpo,"\n");

   tn = tn->next->next;
   an = bn = cn = NULL;
   ++Nface;  
  } 
 } /* tn */

 fprintf(fpo,"]\n");
 fprintf(fpo,"}\n");

 /** Output Connection Data **/
 fprintf(fpo,"coordIndex[\n");
 k = 0; 
 for (i=0;i<Nface;++i)
 {
  for (j=0;j<Nang_div;++j) { fprintf(fpo,"%d %d -1,\n",k,k+1); ++k;}
  ++k;
  for (j=0;j<Nang_div;++j) { fprintf(fpo,"%d %d -1,\n",k,k+1); ++k;}
  ++k;
  for (j=0;j<Nang_div;++j) 
   { fprintf(fpo,"%d %d -1",k,k+1); 
     if ((i==(Nface-1))&&(j==(Nang_div-1)))fprintf(fpo,"\n"); else fprintf(fpo,",\n"); 
     ++k; }
  ++k;
 }
 fprintf(fpo,"]\n"); 
 

 /** Output Color Data **/
 /*
 fprintf(fpo,"color Color{\n");
 fprintf(fpo," color[1 1 1,1 1 1]\n",1,0,0); 
 fprintf(fpo,"}\n");
 fprintf(fpo,"colorIndex[");
 for (i=0;i<Nface;++i)
 {
  for (j=0;j<Nang_div;++j) fprintf(fpo," 0");
  for (j=0;j<Nang_div;++j) fprintf(fpo," 0");
  for (j=0;j<Nang_div;++j) fprintf(fpo," 0");
  fprintf(fpo,"\n"); 
 }
 fprintf(fpo,"]\n"); 
 fprintf(fpo,"colorPerVertex FALSE\n");
 */

 /* Ending */ 
 fprintf(fpo,"}\n"); 
 fprintf(fpo,"}\n"); 
 fprintf(fpo,"]\n"); 
 fprintf(fpo,"}\n"); 
 fclose(fpo);

} /* end of Write_Spherical_Triangle_In_VRML() */








void Write_Arc_In_Gnuplot(fpo,R,X,Y,O,Theta,Ndiv)
 FILE *fpo;
 float R,X[3],Y[3],O[3],Theta;
 int  Ndiv;
{
 float P[3],Rcos_t,Rsin_t,th;
 int i;

 for (i=0;i<=Ndiv;++i)
  { th = (i*Theta)/Ndiv;
    Rcos_t = R*cos(th);
    Rsin_t = R*sin(th);
    P[0] = Rcos_t * X[0] + Rsin_t * Y[0] + O[0];
    P[1] = Rcos_t * X[1] + Rsin_t * Y[1] + O[1];
    P[2] = Rcos_t * X[2] + Rsin_t * Y[2] + O[2];
    fprintf(fpo,"%f %f %f ARC\n",P[0],P[1],P[2]); 
 }
 fprintf(fpo,"\n\n");

} /* end of Write_Arc_In_Gnuplot() */



void Write_Arc_In_VRML(fpo,R,X,Y,O,Theta,Ndiv)
 FILE *fpo;
 float R,X[3],Y[3],O[3],Theta;
 int  Ndiv;
{
 float P[3],Rcos_t,Rsin_t,th;
 int i;

 for (i=0;i<=Ndiv;++i)
  { th = (i*Theta)/Ndiv;
    Rcos_t = R*cos(th);
    Rsin_t = R*sin(th);
    P[0] = Rcos_t * X[0] + Rsin_t * Y[0] + O[0];
    P[1] = Rcos_t * X[1] + Rsin_t * Y[1] + O[1];
    P[2] = Rcos_t * X[2] + Rsin_t * Y[2] + O[2];
    fprintf(fpo,"%f %f %f",P[0],P[1],P[2]); 
    if (i<Ndiv) fprintf(fpo,",\n");
 }

} /* end of Write_Arc_In_VRML() */


void Cal_XY_axis_from_A_B_O(X,Y,Theta,A,B,O)
 float X[3]; /* axis for X coordinates */
 float Y[3]; /* axis for Y coordinates */
 float *Theta; /* Angle between OA and OB */
 float A[3]; /* point A on sphere */
 float B[3]; /* point B on sphere */
 float O[3]; /* center of sphere */
{
 float OB[3],YY[3],XxOB; 
 double cos_t,theta;

 Sub_Vec(X,A,O);
 Normalize(X);   /* X = OA/|OA| */
 Sub_Vec(OB,B,O);
 XxOB = Dot_Prod(X,OB);
 Y[0] = OB[0] - XxOB * X[0];
 Y[1] = OB[1] - XxOB * X[1];
 Y[2] = OB[2] - XxOB * X[2];
 Normalize(Y);   /* Y = (OB - (X*OB)X)/|OB - (X*OB)X| */

 Normalize(OB);
 cos_t = Dot_Prod(X,OB);
 theta = acos(cos_t);
 *Theta = (float)theta;

} /* end of Cal_XY_axis_from_A_B_O() */



 
void Read_Tangent_Point_PDB_File(fname,Ahead)
 char *fname;
 struct TANPNT *Ahead;
{
 FILE *fp;
 char line[256],B[32],Aname[32],Rname[32],atomtype,chain,altloc,end;
 float P[3];
 int accept,anum;
 struct TANPNT *an;
/*
>> FILE FORMAT EXAMPLE <<
HEADER    Tangent points "tpnt.pdb"
REMARK #atm  atm res  #res       Xtpnt   Ytpnt   Ztpnt  Rprb  #prb #atm1#atm2#atm3    Xprb    Yprb    Zprb
HETATM10000  TAN TAN  2171      13.098   3.668  11.064  1.87     1   327  320  323  13.625   1.925  11.488
HETATM10001  TAN TAN  2171      13.568   3.660  12.183  1.87     1   327  320  323  13.625   1.925  11.488
HETATM10002  TAN TAN  2171      12.945   3.347  12.495  1.87     1   327  320  323  13.625   1.925  11.488
:
:
*/ 

 anum = 0;
 Ahead->next = NULL;
 an = Ahead; end = 0;
 
 fp = fopen(fname,"r");
 if (fp==NULL){printf("#ERROR:Can't open pdbfile \"%s\"\n",fname); exit(1);}

 while ((feof(fp)==0)&&(end==0))
 {
  line[0] = '\0';
  fgets(line,255,fp);
       if (strncmp(line,"ATOM",4)==0)   atomtype = 'A';
  else if (strncmp(line,"HETATM",6)==0) atomtype = 'H';
  else atomtype = ' ';
                                                                                                     
  if (strncmp(line,"ENDMDL",6)==0) end = 1;
  
  if (atomtype=='H')
   {
     Get_Part_Of_Line(Aname,line,12,15);
     Get_Part_Of_Line(Rname,line,17,19);

     an->next = (struct TANPNT *)malloc(sizeof(struct TANPNT));
     an->next->prev = an;
     an = an->next;
     an->next = NULL;
     Get_Part_Of_Line(B,line,30,37); an->Pos[0] = atof(B);
     Get_Part_Of_Line(B,line,38,45); an->Pos[1] = atof(B);
     Get_Part_Of_Line(B,line,46,53); an->Pos[2] = atof(B);
     Get_Part_Of_Line(an->Anum,line,6,10);
     Get_Part_Of_Line(an->Atom,line,12,15);
     Get_Part_Of_Line(an->Resi,line,17,19);
     Get_Part_Of_Line(an->Rnum,line,22,26);
     Get_Part_Of_Line(B,line,54,59); an->R = an->Occup  = atof(B);
     Get_Part_Of_Line(B,line,60,65); an->tFactor = atof(B);
     an->Chain  = chain;
     an->altLoc = altloc;
     an->num   = anum;
     an->AHtype = atomtype;
     Get_Part_Of_Line(B,line,83,90);  an->PrbCen[0] = atof(B);
     Get_Part_Of_Line(B,line,91,98);  an->PrbCen[1] = atof(B);
     Get_Part_Of_Line(B,line,99,106); an->PrbCen[2] = atof(B);
     ++anum;

  } /* atomtype == 'H' */
                                                                                                     
 } /* while */
                                                                                                     
 fclose(fp);

} /* end of Read_Tangent_Point_PDB_File() */



void Get_Part_Of_Line(part,line,s,e)
  char *part;
  char *line;
  int  s,e;
{
 int i,E,L;
 L = strlen(line)-1;
 if (line[L] == '\n') L -= 1;
 if (e>L) E = L; else E = e;
 for (i=s;i<=E;++i) part[i-s] = line[i];
 part[E-s+1] = '\0';
 
} /* end of Get_Part_of_Line() */

                                                                                                                 
void Sub_Vec(C,A,B)
 float C[3],A[3],B[3];
{  C[0] = A[0]-B[0];
   C[1] = A[1]-B[1];
   C[2] = A[2]-B[2];
} /* end of Sub_Vec(A,B) */
                                                                                                                 
                                                                                                                 
void Equal_Vec(A,B)
 float A[3],B[3];
{  A[0] = B[0];
   A[1] = B[1];
   A[2] = B[2];
} /* end of Equal_Vec(A,B) */
                                                                                                                 
                                                                                                                 
                                                                                                                 
void Normalize(A)
 float A[3];
{  float dis;
  dis = A[0]*A[0] + A[1]*A[1] + A[2]*A[2];
  if (dis>0.0)
   { dis = sqrt(dis);
     A[0] /= dis; A[1] /= dis; A[2] /= dis; }
} /* end Normalize() */
                                                                                                                 


float Dot_Prod(A,B)
 float *A,*B;
{ int i;
  float prod;
  prod = 0.0;
  for (i=0;i<3;++i) prod += A[i]*B[i];
  return(prod);
} /* end of Dot_Prod() */


