/*

 <ResMergeSort.h>
 
*/

extern struct RESIDUE *Merge_Sort_List_RESIDUE();
extern void Merge_Sort_Double_Linked_List_RESIDUE();
