/*

 <NeiNvec.c>

 Functions for calculating normal vector for each atom
 using gravity center of neighboring atoms

 coded by Takeshi Kawabata (takawaba@is.naist.jp)

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "pdbstruct.h"

/** FUNCTIONS (GLOBAL) **/
void Make_NEIGHBOR_ATOM();
void Set_Nvec_to_Atoms_By_NEIGHBOR_ATOMS();
void Free_NEIGHBOR_ATOM();

/** FUNCTIONS (LOCAL) **/
static void Add_NEIGHBOR_ATOM_to_Atom();
static void Normalize();

void Make_NEIGHBOR_ATOM(Ahead,Dmap,Rprobe)
 struct ATOM *Ahead;
 struct MATRIX *Dmap;
 float  Rprobe;
{
 struct ATOM *an,*bn;
 float Dthre;
 /*
 Criteria for neighbor 

  Distance is less than (Ra + 2*Rprobe + Rb)

   |Ra x Ra |Rprobe x Rprobe|Rb x Rb|

 */

 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  an->NAhead.prev = an->NAhead.next = NULL;
  Dthre = 2.0*Rprobe + an->R;
  bn = Ahead;
  while (bn->next != NULL)
  {
    bn = bn->next;
    if ((an->num != bn->num)&&(Dmap->m[an->num][bn->num] <= (Dthre + bn->R)))
     Add_NEIGHBOR_ATOM_to_Atom(an,bn);
  } /* bn */

 } /* an */

} /* end of Make_NEIGHBOR_ATOM() */









void Add_NEIGHBOR_ATOM_to_Atom(an,neighbor)
 struct ATOM *an;
 struct ATOM *neighbor;
{
 struct NEIGHBOR_ATOM *nn;

 nn = an->NAhead.next;
 an->NAhead.next = (struct NEIGHBOR_ATOM*)malloc(sizeof(struct NEIGHBOR_ATOM));
 an->NAhead.next->next = nn;
 an->NAhead.next->prev = &(an->NAhead);
 if (nn != NULL) nn->prev = an->NAhead.next;

 an->NAhead.next->atom = neighbor;

 /*
 Show_NEIGHBOR_FACE(an);
 */

} /* end of Add_NEIGHBOR_FACE_to_Atom() */


void Set_Nvec_to_Atoms_By_NEIGHBOR_ATOMS(Ahead)
  struct ATOM *Ahead;
{
 struct ATOM *an;
 struct NEIGHBOR_ATOM *nn;
 float G[3];
 int i,Nneighbor;

 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  if ((an->mark == 1)&&(an->surface == 1))
  {
   G[0] = G[1] = G[2] = 0.0; Nneighbor = 0;
   nn = &(an->NAhead);
   while (nn->next != NULL)
   {
     nn = nn->next;
     if (nn->atom->mark==1)
     {
      ++Nneighbor;
      for (i=0;i<3;++i) G[i] += nn->atom->Pos[i]; 
      }
    } /* nn */

    /* printf("#Nneighbor %d\n",Nneighbor); */
    if (Nneighbor>0) 
    { G[0] /= Nneighbor; G[1] /= Nneighbor; G[2] /= Nneighbor;
      /* printf("Gcenter %f %f %f\n",G[0],G[1],G[2]);  */
      an->nvec[0] = an->Pos[0] - G[0];
      an->nvec[1] = an->Pos[1] - G[1];
      an->nvec[2] = an->Pos[2] - G[2];
      Normalize(an->nvec); 
    } else an->nvec[0] = an->nvec[1] = an->nvec[2] = 0.0;
  } /* an is marked and surface */

 } /* an */


} /* end of Set_Nvec_to_Atoms_By_NEIGHBOR_ATOMS() */



void Free_NEIGHBOR_ATOM(Ahead)
 struct ATOM *Ahead;
{
 struct ATOM *an;
 struct NEIGHBOR_ATOM *nn;

 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  nn = &(an->NAhead);
  while (nn->next != NULL)  nn = nn->next; 

  while (nn->prev != NULL)
   {  nn = nn->prev; 
      free(nn->next); } 
 
  an->NAhead.next = NULL;

 } /* an */
 

} /* end of Free_NEIGHBOR_ATOM() */

                                                                                                                          
void Normalize(A)
 float A[3];
{  float dis;
  dis = A[0]*A[0] + A[1]*A[1] + A[2]*A[2];
  if (dis>0.0)
   { dis = sqrt(dis);
     A[0] /= dis; A[1] /= dis; A[2] /= dis; }
} /* end Normalize() */

