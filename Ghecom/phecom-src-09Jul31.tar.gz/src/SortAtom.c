/*

 <SortAtom.c>

 Sorting atom order for calculating spherical hull.

 coded by Takeshi Kawabata (takawaba@is.naist.jp)

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "pdbstruct.h"
#include "AtmMergeSort.h"

/*** FUNCTION (GLOBAL) ***/
void Sort_Atom_Order_From_Gravity_Center();
void Sort_Atom_Order_From_Gravity_Center_Atom();
void Sort_Atom_Order_From_Gravity_Center_Atom_MinDis();
void Check_Distance_Jump_Between_Previous_Atoms();
void Recover_Atom_Order_By_Atom_Number();
void Resort_Distance_Isolated_Atoms_After_The_Closest();
void Resort_Distance_Isolated_Atoms_To_The_End();


/*** FUNCTION (LOCAL) ***/
static void Set_Atom_Order_tFactor();

void Sort_Atom_Order_From_Gravity_Center(Ahead)
 struct ATOM *Ahead;
{
 struct ATOM *an;
 float G[3],D[3];
 int Natom,i;

 printf("#Sort_Atom_Order_From_Gravity_Center(Ahead)\n");
 /* (1) Calculate Gravity Center */
 G[0] = G[1] = G[2] = 0.0;
 Natom = 0;
 an = Ahead;
 while (an->next != NULL)
 { an = an->next;
   ++Natom;
   for (i=0;i<3;++i) G[i] += an->Pos[i]; 
  }
 
  G[0] /= Natom; G[1] /= Natom; G[2] /= Natom;

 printf("#G %f %f %f\n",G[0],G[1],G[2]);
 /* (2) Calculate Distance From Gravity Center */
 an = Ahead;
 while (an->next != NULL)
 { an = an->next;
   for (i=0;i<3;++i) D[i] = an->Pos[i] - G[i];
   an->value = D[0]*D[0] + D[1]*D[1] + D[2]*D[2];  
 }

 /* (3) Sort */
 Merge_Sort_Double_Linked_List_ATOM(Ahead,'N');
 Set_Atom_Order_tFactor(Ahead);

} /* end of Sort_Atom_Order_From_Gravity_Center() */






void Sort_Atom_Order_From_Gravity_Center_Atom(Ahead)
 struct ATOM *Ahead;
{
 struct ATOM *an,*gn;
 float G[3],Gatm[3],D[3],DD,DDmin;
 int Natom,i;

 printf("#Sort_Atom_Order_From_Gravity_Center_Atom()\n");
 /* (1) Calculate Gravity Center */
 G[0] = G[1] = G[2] = 0.0;
 Natom = 0;
 an = Ahead;
 while (an->next != NULL)
 { an = an->next;
   ++Natom;
   for (i=0;i<3;++i) G[i] += an->Pos[i]; 
 }
 
 G[0] /= Natom; G[1] /= Natom; G[2] /= Natom;

 /* (2) Find the Nearest Atom From Gravity Center */
 an = Ahead; 
 DDmin = -1.0; 
 gn = NULL;
 while (an->next != NULL)
 { an = an->next;
   for (i=0;i<3;++i) D[i] = an->Pos[i] - G[i];
   DD = D[0]*D[0] + D[1]*D[1] + D[2]*D[2];  
   if ((DDmin<0.0)||(DD<DDmin)) {DDmin = DD; gn = an;}
 }

 for (i=0;i<3;++i) Gatm[i] = gn->Pos[i];
 printf("#G %f %f %f Gatm %f %f %f\n",G[0],G[1],G[2],Gatm[0],Gatm[1],Gatm[2]); 
 /* (3) Calculate Distance From Gravity Center */
 an = Ahead;
 while (an->next != NULL)
 { an = an->next;
   for (i=0;i<3;++i) D[i] = an->Pos[i] - Gatm[i];
   an->value = D[0]*D[0] + D[1]*D[1] + D[2]*D[2];  
 }

 /* (4) Sort */
 Merge_Sort_Double_Linked_List_ATOM(Ahead,'N');
 Set_Atom_Order_tFactor(Ahead);

} /* end of Sort_Atom_Order_From_Gravity_Center_Atom() */




void Sort_Atom_Order_From_Gravity_Center_Atom_MinDis(Ahead,Dmat)
 struct ATOM  *Ahead;
 struct MATRIX *Dmat;
{
 struct ATOM *an,*gn,*bn,*mn;
 float G[3],D[3],DD,DDmin,minD,minDall;
 int gnum,Natom,Nmark,i;
 
 printf("#Sort_Atom_Order_From_Gravity_Center_Atom_MinDis()\n");

 /* (1) Calculate Gravity Center */
 G[0] = G[1] = G[2] = 0.0;
 Natom = 0;
 an = Ahead;
 while (an->next != NULL)
 { an = an->next;
   an->mark = 0; 
   ++Natom;
   G[0] += an->Pos[0]; 
   G[1] += an->Pos[1]; 
   G[2] += an->Pos[2]; }
 
 G[0] /= Natom; G[1] /= Natom; G[2] /= Natom;

 printf("#G %f %f %f\n",G[0],G[1],G[2]);

 /* (2) Find the Nearest Atom From Gravity Center */
 an = Ahead; 
 DDmin = -1.0; 
 gn = NULL;
 while (an->next != NULL)
 { an = an->next;
   D[0] = an->Pos[0] - G[0];
   D[1] = an->Pos[1] - G[1];
   D[2] = an->Pos[2] - G[2];
   DD = D[0]*D[0] + D[1]*D[1] + D[2]*D[2];  
   if ((DDmin<0.0)||(DD<DDmin)) {DDmin = DD; gn = an; gnum = an->num;}
 }

 /* (3) Choose the closet atom from previous cluster one by one */
 printf("#gn %d\n",gn->num); 
 gn->mark = 1; gn->value = 0.0; 
 an = Ahead;
 for (i=1;i<Natom;++i)
 {
  minDall = -1.0;
  mn = NULL;
  an = Ahead; 
  while (an->next != NULL)
  { an = an->next;

   if (an->mark == 0)
   {
    bn = Ahead;
    minD = -1.0;
    while (bn->next != NULL)
    {
     bn = bn->next;
    
     if (bn->mark == 1)
     {
      if ((minD<0.0)||(Dmat->m[an->num][bn->num] < minD)) minD = Dmat->m[an->num][bn->num];
      } 
 
    } /* bn */

/*
     printf("an %d minD %f minDall %f\n",an->num,minD,minDall);   
*/ 
    if ((minDall<0.0)||(minD < minDall)) { minDall  = minD;  mn = an;}
  
  } /* an->mark = 0 */  

  } /* an */

  printf("i %d Natom %d\n",i,Natom);
  if (mn == NULL) {printf("#ERROR:mn is NULL!!\n"); printf("mn %d\n",mn->num); exit(1);}
  mn->mark = 1;
  sprintf(mn->Rnum,"%5d",i);
 } /* i */


 /* (4) Sort */
 Merge_Sort_Double_Linked_List_ATOM(Ahead,'N');
 Set_Atom_Order_tFactor(Ahead);

} /* end of Sort_Atom_Order_From_Gravity_Center_Atom_MinDis() */





void Resort_Distance_Isolated_Atoms_After_The_Closest(Ahead,Dmat,Dthre)
 struct ATOM *Ahead;
 struct MATRIX *Dmat;
 float Dthre;
{
 int i,Natom,Nmark0;
 struct ATOM *an,*bn,*mn; 
 float minD,dis;
 char initial;

  printf("#Resort_Distance_Isolated_Atoms_After_The_Closest(Dthre %f)\n",Dthre);
 /* (1) Set mark = 0*/ 
 an = Ahead; Natom = 0;
 while (an->next !=NULL){ 
   an = an->next;
   an->mark  = 0; 
   ++Natom; }

 /* (2) Check Minimum Distance, and if less than threshold set mark = 1 */ 
 an = Ahead; i = 0; Nmark0 = 0;
 while (an->next != NULL){
  an = an->next;
  ++i;
  initial = 1;
  bn = Ahead;
  while ((bn->next != NULL)&&(bn->next!=an)){
    bn = bn->next;
    if (bn->mark==1){
     dis = Dmat->m[an->num][bn->num] - an->R - bn->R;
     if ((initial==1)||(dis<minD)) {minD = dis; initial = 0;}
    }  
  }
  if ((initial==0)&&(minD > Dthre)) {an->mark = 0; ++Nmark0;} else an->mark = 1; 
  if (an->mark==0)
  printf("#%s %s %s %s minD %f mark %d\n",an->Anum,an->Atom,an->Rnum,an->Resi,minD,an->mark); 
 }  

 printf("#Natom %d Nmark0 %d\n",Natom,Nmark0);

 if (Nmark0>0){
  /* 
  (3) For atom an with mark = 0, find the closest atom mn with mark=1, and insert an after mn  
  */ 
  an = Ahead;
  while (an->next != NULL){
    an = an->next;
    if (an->mark == 0){
     bn = Ahead;
     initial = 1;
     while (bn->next != NULL){
      bn = bn->next; 
      if (bn->mark==1)
      { dis = Dmat->m[an->num][bn->num] - an->R - bn->R;
        if ((initial==1)||(dis<minD)) {minD = dis; mn = bn; initial = 0;} }
     } /* bn */
 
     printf("#an %s value %f -> mn %s value %f %f minD %f\n",
     an->Anum,an->value,mn->Anum,mn->value,mn->tFactor,minD);
     an->value   = mn->value + 0.001; 
    }
   } /* an */

 /* (4) Sort Again */
 Merge_Sort_Double_Linked_List_ATOM(Ahead,'N');
 Set_Atom_Order_tFactor(Ahead);

 } /* Nmark0>0 */

} /* end of Resort_Distance_Isolated_Atoms_After_The_Closest() */



void Resort_Distance_Isolated_Atoms_To_The_End(Ahead,Dmat,Dthre)
 struct ATOM *Ahead;
 struct MATRIX *Dmat;
 float Dthre;
{
 int i,Natom,Nmark0;
 struct ATOM *an,*bn,*mn; 
 float minD,dis,maxD;
 char initial;

 printf("#Resort_Distance_Isolated_Atoms_To_The_End(Dthre %f)\n",Dthre);
 /* (1) Set mark = 0*/ 
 an = Ahead; Natom = 0;
 while (an->next !=NULL) 
 { an = an->next;
   maxD = an->value;
   an->mark  = 0; 
   ++Natom; }

 printf("#maxD %f\n",maxD);
 /* (2) Check Minimum Distance, and if less than threshold set mark = 1 */ 
 an = Ahead; i = 0; Nmark0 = 0;
 while (an->next != NULL){
  an = an->next;
  ++i;
  initial = 1;
  bn = Ahead; minD = Dthre;
  while ((bn->next != NULL)&&(bn->next!=an)){
    bn = bn->next;
    if (bn->mark==1){
     dis = Dmat->m[an->num][bn->num] - an->R - bn->R;
      /* printf("%d %d dis %f\n",an->num,bn->num,dis); */   
     if ((initial==1)||(dis<minD)) {minD = dis; initial = 0;}
    }  
  } /* bn */
  if ((initial==0)&&(minD > Dthre)) {an->mark = 0; ++Nmark0;} else an->mark = 1; 
  if (an->mark==0)
  printf("#%s %s %s %s minD %f mark %d\n",an->Anum,an->Atom,an->Rnum,an->Resi,minD,an->mark); 
 } /* an */  

 printf("#Natom %d Nmark0 %d\n",Natom,Nmark0);
 if (Nmark0>0){
 /* 
   (3) Check Minimum Distance again for mark0_atom against mark1_atom 
       Still Minimum Disntace > Dthre, set an->value to very large value.
 */ 
  
  an = Ahead;
  while (an->next != NULL){
    an = an->next;
    if (an->mark == 0){
     bn = Ahead;
     initial = 1;
     while (bn->next != NULL){
      bn = bn->next; 
      if (bn->mark==1)
      { dis = Dmat->m[an->num][bn->num] - an->R - bn->R;
        if ((initial==1)||(dis<minD)) {minD = dis; mn = bn; initial = 0;} }
     } /* bn */
 
     printf("#Move_to_end an %s value %f -> mn %s value %f %f minD %f\n",
     an->Anum,an->value,mn->Anum,mn->value,mn->tFactor,minD);
     an->value = maxD + minD;   
    }
   } /* an */
 /* (4) Sort Again */
 Merge_Sort_Double_Linked_List_ATOM(Ahead,'N');
 Set_Atom_Order_tFactor(Ahead);

 } /* Nmark0>0 */

} /* end of Resort_Distance_Isolated_Atoms_To_The_End(); */





void Check_Distance_Jump_Between_Previous_Atoms(Ahead,fname,Dthre)
 struct ATOM *Ahead;
 char *fname;
 float Dthre;
{
 int Natom,i;
 struct ATOM *an,*bn; 
 struct MATRIX Dmat;
 float minD,dis;
 char initial;
 FILE *fp;

 printf("Check_Distance_Jump_Between_Previous_Atoms(Ahead)-->\"%s\"\n",fname);
 fp = fopen(fname,"w");
 fprintf(fp,"#COMMAND %s\n",PAR.COMMAND);
 /* Count Natom and set mark = 0*/ 
 Natom = 0;
 an = Ahead;
 while (an->next !=NULL) 
 { an = an->next;
   an->mark  = 0;
   ++Natom; }

 Malloc_MATRIX(&Dmat,Natom);
 Cal_Distance_MATRIX(Ahead,&Dmat); 

 /* Check Minimum Distance */ 
 
 an = Ahead; i = 0;
 while (an->next != NULL)
 {
  an = an->next;
  ++i;
  initial = 1;
  bn = Ahead;
  while ((bn->next != NULL)&&(bn->next!=an)) 
  {
    bn = bn->next;
    if (bn->mark==1)
    {
     dis = Dmat.m[an->num][bn->num] - an->R - bn->R;
     if ((initial==1)||(dis<minD)) {minD = dis; initial = 0;}
    }  
  }
  if (minD > Dthre) an->mark = 0; else an->mark = 1; 
  fprintf(fp,"%d %f %s %s %s %s mark %d\n",i,minD,an->Anum,an->Atom,an->Rnum,an->Resi,an->mark); 
  if (an->mark==0)
  {
   fprintf(fp,"#ATOM ");
   fprintf(fp,"%5s %4s %3s %c%5s   %8.3f%8.3f%8.3f%6.2f%6.2f\n",
        an->Anum,an->Atom,an->Resi,an->Chain,an->Rnum,
        an->Pos[0],an->Pos[1],an->Pos[2],an->R,an->tFactor);
   } 
 }  

 fclose(fp);
} /* end of Check_Distance_Jump_Between_Previous_Atoms() */




void Set_Atom_Order_tFactor(Ahead)
 struct ATOM *Ahead;
{
 struct ATOM *an;
 int Natom,i;
 
 an = Ahead; Natom = 0;
 while (an->next != NULL)
 { an = an->next;
   ++Natom; }

 an = Ahead; i = 0; 
 while (an->next != NULL)
 { an = an->next;
   ++i;
   an->tFactor = (float)(100.0*i/Natom);}

} /* end of Set_Atom_Order_tFactor() */





void Recover_Atom_Order_By_Atom_Number(Ahead)
 struct ATOM *Ahead;
{
 struct ATOM *an;
 
 an = Ahead;
 an->num = 0;
 while (an->next != NULL)
 { an = an->next;
   an->value = an->num; }

 Merge_Sort_Double_Linked_List_ATOM(Ahead,'N');

} /* end of Recover_Atom_Order_By_Atom_Number() */
