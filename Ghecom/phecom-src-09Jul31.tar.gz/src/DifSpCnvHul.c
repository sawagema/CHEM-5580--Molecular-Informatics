/*

<DifSpCnvHul.c>
 
 for making 3D Convex Hull of Spheres with different radius.

 coded by Takeshi Kawabata (takawaba@is.naist.jp)


 This is based on : 
  Joseph O'Rourke "Computational Geometry in C" (1998), 
   Second Edition,Cambridge.

 however, these functions do not use sturct EDGE.


*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "pdbstruct.h" 
#include "DifSpCnvHul.h" 
#include "PdbIO.h" 

/** FUNCTION (GLOBAL) **/
void ConstructHull_DifSp();
int  Initial_Double_Triangle_DifSp();
void Output_Faces_VRML_DifSp();
int  Free_Faces_DifSp();
void Remove_Atoms_Crashed_With_Planes();
void Write_PDB_File_Planes();

/** FUNCTION (LOCAL) **/
static int Add_One_Atom_To_CnvHul_DifSp();
static char Collinear();
static struct SH_FACE* Make_SH_FACE();
static int VolSign_F_to_farthestP();
static void CleanFaces();
static int Cal_NormVec_Of_Plane_Tangent_To_Three_Atoms();
static void Make_CounterClockWise_By_Nvec();
static void Cross_Vec();
static float Dot_Prod();
static int Choose_One_Nvec_By_Face_Atoms();
static int Add_NewFace_With_Nvec_By_Three_Atoms();
static int Check_Visibility_For_Surface_Atom();
static int Check_Outside_From_Nvec_Atoms_Of_Face();
static void Add_New_Face_By_FacePointer();
static void Set_Nvec_to_Face();
static void Sub_Vec();
static void Normalize();
static void Increment_Plus();
static void Increment_Minus();
static void Set_Nvec_to_Atoms_By_Faces();
static void Show_Face_Info_DifSp();
static void Initialize_Mark();




void ConstructHull_DifSp(Ahead,Fhead)
 struct ATOM *Ahead;
 struct SH_FACE *Fhead;
{
 struct ATOM *an;

 printf("#ConstructHull_DifSp(Plane-probed hull)\n");
 Set_Nvec_to_Atoms_By_Faces(Ahead,Fhead);
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
 /*
  printf(">>>>an %s (%d) mark %d\n",an->Anum,an->num,an->mark);  fflush(stdout);
 */ 
  if (an->mark == 0)
  {
    an->mark = 1;
    Add_One_Atom_To_CnvHul_DifSp(an,Ahead,Fhead);
    Set_Nvec_to_Atoms_By_Faces(Ahead,Fhead); 
   }
 }

} /* end of ConstructHull_DifSp() */





int Add_One_Atom_To_CnvHul_DifSp(p,Ahead,Fhead)
 struct ATOM *p;    /* Atom to be added */
 struct ATOM *Ahead;
 struct SH_FACE *Fhead;
{
 struct ATOM *an;
 struct SH_FACE *f, *nf;
 struct SH_FACE NewFaceHead;
 int vsign,Nvisible,Nnf,nsign;
 int i;
 char out[3];
 int Noutside,nout;

 /*
 printf("#Add_One_Atom_To_CnvHul_DifSp(one_atom[%d] %s %s %s %s)\n",
  p->num,p->Atom,p->Anum,p->Resi,p->Rnum); 
 */

 /* (0) Set all an->surface to zero */
 an = Ahead;
 while (an->next != NULL) { an = an->next; an->surface = 0;}

 /* (1) Mark faces visible from p */
 NewFaceHead.next = NULL; 

 f = Fhead; Nvisible = Noutside = Nnf = 0;
 while (f->next != NULL)
 {
  f = f->next;
  f->atom[0]->surface =  f->atom[1]->surface =  f->atom[2]->surface = 1;

  vsign = VolSign_F_to_farthestP(f,p);

  /** [VISIBLE]  **/
  /*
    Atom p is outside of probe sphere of f. 
    Making new three sp-triangles by p and atom[0],atom[1],atom[2] of f for both side.
    f->visible is set to 1. --> f is supposed to be deleted.
  */

  if (vsign<0)
   { f->visible = 1; 
     ++Nvisible; 
     Nnf += Add_NewFace_With_Nvec_By_Three_Atoms(&NewFaceHead,p,f->atom[0],f->atom[1]);
     Nnf += Add_NewFace_With_Nvec_By_Three_Atoms(&NewFaceHead,p,f->atom[1],f->atom[2]);
     Nnf += Add_NewFace_With_Nvec_By_Three_Atoms(&NewFaceHead,p,f->atom[2],f->atom[0]);
   }

 /** [OUTSIDE]  **/
  /*
   Atom p is outside of probe sphere of f, but invisible by f.
   But, atom p is outside from nvec.
   Making new three sp-triangles by p and atom[0],atom[1],atom[2] of f including outside atom
   for both sides.
   f->visible is not set to 1. --> f is not supposed to be deleted.
 */

 else 
  {  f->visible = 0;
     nout = Check_Outside_From_Nvec_Atoms_Of_Face(f,p,out);

     if (nout >0)
     {
       ++Noutside;
       if ((out[0]==1)||(out[1]==1)) 
        Nnf += Add_NewFace_With_Nvec_By_Three_Atoms(&NewFaceHead,p,f->atom[0],f->atom[1]);
       if ((out[1]==1)||(out[2]==1)) 
        Nnf += Add_NewFace_With_Nvec_By_Three_Atoms(&NewFaceHead,p,f->atom[1],f->atom[2]);
       if ((out[2]==1)||(out[0]==1)) 
        Nnf += Add_NewFace_With_Nvec_By_Three_Atoms(&NewFaceHead,p,f->atom[2],f->atom[0]);
     }

   }
 
 } /* f */

 /* (2) If no faces are visible from p, then p is inside the hull. */
 
 if ((Nvisible==0) && (Noutside==0))
  { printf("##atom[%s] is inside the hull\n",p->Anum);  
    return(0); }


 /* (3) Checking visiblity of  newfaces from previsous convex-hull vertex atoms  */
 nf = &NewFaceHead;
 while (nf->next != NULL)
 {
  nf = nf->next;

 if (nf->nvec[0]* nf->nvec[0] +
     nf->nvec[1]* nf->nvec[1] +
     nf->nvec[2]* nf->nvec[2] <= 0.0)
 { printf("#WOOPSpre0 %d norm nvec is zero (%f %f %f)\n",
   nf->num,nf->nvec[0], nf->nvec[1], nf->nvec[2]); } 
  

  if (Check_Visibility_For_Surface_Atom(Ahead,nf)==0)
  {
   Add_New_Face_By_FacePointer(Fhead,nf);
  }
 
  /*
 else printf("nf(%s %s %s) is not ok\n", nf->atom[0]->Anum, nf->atom[1]->Anum, nf->atom[2]->Anum);
 */
 
 }

 CleanFaces(Fhead);
 Free_Faces_DifSp(&NewFaceHead);
 return(1);

} /* end of Add_One_Atom_To_CnvHul_DifSp() */



int Check_Visibility_For_Surface_Atom(Ahead,nf)
 struct ATOM *Ahead;
 struct SH_FACE *nf;
{
 struct ATOM *an;
 int vsign;

 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  if ( (an->surface == 1)  
       && (nf->atom[0]->num != an->num)
       && (nf->atom[1]->num != an->num)
       && (nf->atom[2]->num != an->num) ) 
  {
    vsign = VolSign_F_to_farthestP(nf,an);
   
    /* 
    if (vsign < 0)
    { printf("face %s %s %s is visible by %s\n",
      nf->atom[0]->Anum,nf->atom[1]->Anum,nf->atom[2]->Anum,an->Anum); }
   */

    if (vsign < 0)  return(1); 
   }
 } /* an */
 
 return(0);
 
} /* end of Check_Visibility_For_Surface_Atoms() */







void CleanFaces(Fhead)
 struct SH_FACE *Fhead;
{
 struct SH_FACE *f,*df;
 int Nall,Ndelete;

 /* Delete the face f if f->visible = 1 */
 f = Fhead; Nall =  Ndelete = 0;
 while (f->next != NULL)
 {
   f = f->next;
/*
   printf("f %d del %d\n",f->num,f->visible); 
*/ 
   ++Nall;
   if (f->visible==1)
   {
 
     df = f;
     f->prev->next = f->next;
     if (f->next != NULL) f->next->prev = f->prev;
     f = f->prev;    
     free(df); 
     ++Ndelete; 
   }
 } 

/*
 printf("#CleanFaces() --> delete %d faces from %d faces\n",Ndelete,Nall);
 */

} /* end of CleanFaces() */







int Initial_Double_Triangle_DifSp(Ahead,Fhead)
 struct ATOM  *Ahead;  
 struct SH_FACE  *Fhead;
{
 struct ATOM *an,*bn,*cn;
 struct SH_FACE *f[2]; 
 char find;
 float Nv[2][3],pos[3];
 int Nplane,i,j,k;

 printf("#Initial_float_Triangle_DifSp()\n");
 Fhead->num = -1;
 Fhead->next = NULL; 

 /** (0) Initialize mark of atom **/
 an = Ahead;
 while (an->next != NULL)
 { an = an->next;
   an->mark = 0; }

 /** (1) Find three non-collinear atoms **/
 an = Ahead; find = 0;
 while ((an->next != NULL)&&(find==0))
 {
   an = an->next;
   printf("%d\n",an->num);
   if ((an->next != NULL)&&(an->next->next != NULL) &&
       (Collinear(an->Pos,an->next->Pos,an->next->next->Pos)==0) && 
       (Cal_NormVec_Of_Plane_Tangent_To_Three_Atoms(Nv[0],Nv[1],an,an->next,an->next->next)>=2))
   {
    find = 1;
    bn = an->next;
    cn = an->next->next;
   }
 }

 if (find==0) 
  {printf("#ERROR:all points are collinear.\n"); return(0);}

 printf("an %d bn %d cn %d\n",an->num,bn->num,cn->num);

 /*** (2) Cal Tangent Points for (an, bn, cn) ***/

 Nplane = Cal_NormVec_Of_Plane_Tangent_To_Three_Atoms(Nv[0],Nv[1],an,bn,cn);
 if (Nplane < 2)
 { printf("#ERROR:Can't find two inital tangent plane.(Nplane %d)\n",Nplane); 
   return(0); }

 /** (3) Mark the atoms as processed **/
 an->mark = 1; bn->mark = 1; cn->mark = 1; 

 /** (4) Making Face f[0] and f[1] **/

 for (i=0;i<2;++i) 
 {
  f[i] = Make_SH_FACE(Fhead,an,bn,cn);
  Set_Nvec_to_Face(f[i],Nv[i]);
  Make_CounterClockWise_By_Nvec(f[i],f[i]->nvec);
 }

 return(1);

} /* end of Initial_float_Triangle_DifSp() */





char Collinear(a,b,c)
 float a[3],b[3],c[3];
{
 float crs[3];

 /* crs = (b-a) x (c-a) */

 crs[0] = (b[1]-a[1])*(c[2]-a[2]) - (b[2]-a[2])*(c[1]-a[1]);
 crs[1] = (b[2]-a[2])*(c[0]-a[0]) - (b[0]-a[0])*(c[2]-a[2]);
 crs[2] = (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0]);

 if ((fabs(crs[0])<PAR.eps)&&(fabs(crs[1])<PAR.eps)&&(fabs(crs[2]<PAR.eps))) 
   return(1); else return(0); 

} /* end of Collinear() */






void Add_New_Face_By_FacePointer(Fhead,face)
 struct SH_FACE *Fhead;
 struct SH_FACE *face;
{
 struct SH_FACE *f,*nf;
 int i,j;
 float norm;

 /* >> Add new face on Fhead in stacking way << */
 nf = (struct SH_FACE*)malloc(sizeof(struct SH_FACE));
 f = Fhead->next;
 Fhead->next = nf;
 nf->next = f;
 nf->prev = Fhead;
 if (f != NULL) { f->prev = nf; nf->num = f->num + 1; } else nf->num = 0;

 nf->atom[0] = face->atom[0]; 
 nf->atom[1] = face->atom[1]; 
 nf->atom[2] = face->atom[2]; 

 for (i=0;i<3;++i) nf->nvec[i] =  face->nvec[i];
 norm = face->nvec[0]* face->nvec[0] + face->nvec[1]* face->nvec[1] +
        face->nvec[2]* face->nvec[2];
 if (norm <= 0.0)
 { printf("#WOOPS1 norm nvec is zero (%f %f %f)\n",
   face->nvec[0], face->nvec[1], face->nvec[2]); } 

 for (i=0;i<3;++i)
  for (j=0;j<3;++j) nf->tpnt[i][j] = face->tpnt[i][j];

 nf->probe = NULL;
 nf->visible = 0;

} /* end of Add_NewFace_By_FacePointer() */





int Add_NewFace_With_Nvec_By_Three_Atoms(Fhead,a0,a1,a2)
 struct SH_FACE *Fhead;
 struct ATOM *a0,*a1,*a2;
{
 struct SH_FACE *nf;
 int Nplane,v,i,k;
 float Nv[2][3];  /* Normal Vector */

 Nplane = Cal_NormVec_Of_Plane_Tangent_To_Three_Atoms(Nv[0],Nv[1],a0,a1,a2);

 if (Nplane<2)
 {
  /*
   printf("#WARNING:atom(%s %s %s)Nplane[%d] is less than 2.\n",
    a0->Anum,a1->Anum,a2->Anum,Nplane);  
   */
  return(0);}

 nf = Make_SH_FACE(Fhead,a0,a1,a2);

 v = Choose_One_Nvec_By_Face_Atoms(nf,Nv);

 if (v>=0)
 {
  Set_Nvec_to_Face(nf,Nv[v]);

 if ((nf->nvec[0]* nf->nvec[0] +
      nf->nvec[1]* nf->nvec[1] +
      nf->nvec[2]* nf->nvec[2] ) <= 0.0)
 { printf("#WOOPS00 norm nvec is zero (%f %f %f)\n",
   nf->nvec[0], nf->nvec[1], nf->nvec[2]); } 
  
   return(1); }
 else
 {
  printf("#WOOPS!!:no nvecs directs to (a1-a0)x(a2-0). Nplane %d v %d\n",Nplane,v);
  printf("ATOM  %5s %4s %3s %c%5s   %8.3f%8.3f%8.3f%6.2f%6.2f\n",
       a0->Anum,a0->Atom,a0->Resi,a0->Chain,a0->Rnum,
       a0->Pos[0],a0->Pos[1],a0->Pos[2],a0->R,a0->tFactor);
  printf("ATOM  %5s %4s %3s %c%5s   %8.3f%8.3f%8.3f%6.2f%6.2f\n",
       a1->Anum,a1->Atom,a1->Resi,a1->Chain,a1->Rnum,
       a1->Pos[0],a1->Pos[1],a1->Pos[2],a1->R,a1->tFactor);
  printf("ATOM  %5s %4s %3s %c%5s   %8.3f%8.3f%8.3f%6.2f%6.2f\n",
       a2->Anum,a2->Atom,a2->Resi,a2->Chain,a2->Rnum,
       a2->Pos[0],a2->Pos[1],a2->Pos[2],a2->R,a2->tFactor);
  exit(1);
  }

} /* end of Add_NewFace_With_Nvec_By_Three_Atoms() */





struct SH_FACE *Make_SH_FACE(Fhead,a0,a1,a2)
 struct SH_FACE *Fhead;
 struct ATOM *a0,*a1,*a2;
{
 struct SH_FACE *f,*nf;
 int i,j;
 /* >> Add new face on Fhead in stacking way << */
 nf = (struct SH_FACE*)malloc(sizeof(struct SH_FACE));
 f = Fhead->next;
 Fhead->next = nf;
 nf->next = f; 
 nf->prev = Fhead;
 if (f != NULL) { f->prev = nf; nf->num = f->num + 1; } else nf->num = 0;
 nf->atom[0] = a0; nf->atom[1] = a1; nf->atom[2] = a2;

 for (i=0;i<3;++i) nf->nvec[i] =  0.0;
 for (i=0;i<3;++i) 
  for (j=0;j<3;++j) nf->tpnt[i][j] = 0.0;

 nf->probe = NULL; 
 nf->visible = 0;

 return(nf);

} /* end of Make_SH_FACE() */










void Show_Face_Info_DifSp(Fhead)
 struct SH_FACE *Fhead;
{
 struct SH_FACE *fn;
 int i;
 float norm;
 fn = Fhead;
 
 printf("#Show_Face_Info_DifSp()\n");
 while (fn->next != NULL)
 {
   fn = fn->next;
   printf("face[%d] atom ", fn->num);
   for (i=0;i<3;++i)
    if (fn->atom[i]!=NULL) printf(" %s",fn->atom[i]->Anum); else printf(" null");
   norm = fn->nvec[0] * fn->nvec[0] +
          fn->nvec[1] * fn->nvec[1] +
          fn->nvec[2] * fn->nvec[2];
   printf(" nvec %f %f %f norm %f",fn->nvec[0],fn->nvec[1],fn->nvec[2],norm); 
   printf(" visible %d", fn->visible);
   printf("\n");
  }

} /* end of Show_Face_Info_DifSp() */





int VolSign_F_to_farthestP(f,p)
 struct SH_FACE *f;
 struct ATOM *p;
{
 /* If the atom p is visible from the face f, this returns negative
    sign of volume.  
 
   The face is defined by three tangent points (tpnt[3][3]).

  */

 float vol;
 float ax,ay,az,bx,by,bz,cx,cy,cz;
 float X[3]; /* Farthest Point on ATOM p in Nvec direction of FACE f */ 
 
 X[0] = p->Pos[0] + p->R * f->nvec[0];
 X[1] = p->Pos[1] + p->R * f->nvec[1];
 X[2] = p->Pos[2] + p->R * f->nvec[2];

 ax = f->tpnt[0][0] - X[0];
 ay = f->tpnt[0][1] - X[1];
 az = f->tpnt[0][2] - X[2];

 bx = f->tpnt[1][0] - X[0];
 by = f->tpnt[1][1] - X[1];
 bz = f->tpnt[1][2] - X[2];

 cx = f->tpnt[2][0] - X[0];
 cy = f->tpnt[2][1] - X[1];
 cz = f->tpnt[2][2] - X[2];


 vol =  ax * (by*cz - bz*cy)
      + ay * (bz*cx - bx*cz)
      + az * (bx*cy - by*cx);

 /* printf("vol %f\n",vol);  */

      if (vol >  PAR.eps) return(1);
 else if (vol < -PAR.eps) return(-1);
 else return(0);

} /* end of VolSign_F_to_farthestP() */


int Check_Outside_From_Nvec_Atoms_Of_Face(f,p,outside)
 struct SH_FACE *f;
 struct ATOM *p;
 char outside[3];   /* if outside[i] = 1, atom[i] is outside. otherwise inside */  
{
 int i,nout;
 float PX[3],dotprod;

 /*
 printf("#Check_Outside(for %s by %s %s %s)\n",
  p->Anum,f->atom[0]->Anum,f->atom[1]->Anum,f->atom[2]->Anum);
 */
 nout = 0;
 for (i=0;i<3;++i)
 {
  Sub_Vec(PX,p->Pos,f->atom[i]->Pos); 
  dotprod = Dot_Prod(f->atom[i]->nvec,PX);
  /* printf("atom %s dotprod %f\n", f->atom[i]->Anum,dotprod); */
  if (dotprod>0.0) { outside[i] = 1; ++nout;} else outside[i] = 0; 
  }

 return(nout);

} /* end of Check_Outside_From_Nvec_Atoms_Of_Face() */




void Output_Faces_VRML_DifSp(fname,Fhead)
 char *fname;
 struct SH_FACE *Fhead; 
{
 FILE *fp;
 struct SH_FACE *f; 
 int Nver;
 
 if (fname[0]=='-') fp = stdout;
 else 
 { fp = fopen(fname,"w");
   printf("#Output_Faces_VRML_DifSp()-->\"%s\"\n",fname);
   if (fp==NULL){printf("#ERROR:Can't write to \"%s\"\n",fname); exit(1);}
 }
/** Output Header ***/
 fprintf(fp,"#VRML V2.0 utf8\n");
 fprintf(fp,"#%s\n",fname);
 fprintf(fp,"Shape{\n");
 fprintf(fp," appearance Appearance{\n");
 fprintf(fp," material Material{\n");
 fprintf(fp," diffuseColor 0.7 1.0 0.7\n");
 fprintf(fp,"  transparency 0.5\n");
 fprintf(fp,"}\n");
 fprintf(fp,"}\n");

 /** Output IndexedFaceSet ***/

 /* Points */
 fprintf(fp,"geometry IndexedFaceSet{\n");
 fprintf(fp," coord Coordinate{\n");
 fprintf(fp," point[\n");
 f = Fhead;
 while (f->next != NULL)
  {
   f = f->next;
   fprintf(fp,"%f %f %f,\n",f->tpnt[0][0],f->tpnt[0][1],f->tpnt[0][2]);
   fprintf(fp,"%f %f %f,\n",f->tpnt[1][0],f->tpnt[1][1],f->tpnt[1][2]);
   fprintf(fp,"%f %f %f",   f->tpnt[2][0],f->tpnt[2][1],f->tpnt[2][2]);
   if (f->next != NULL) fprintf(fp,",\n"); else fprintf(fp,"\n");
  }

 fprintf(fp,"]}\n");

 /* Faces */
 Nver = 0; 
 fprintf(fp,"  coordIndex[\n");
 f = Fhead;
 if (f != NULL)
 while (f->next != NULL) 
 {
  f = f->next;
  fprintf(fp,"%d, %d, %d, -1,\n", Nver, Nver+1, Nver+2);
  Nver += 3; 
 }
 fprintf(fp,"]\n");
 fprintf(fp,"solid FALSE\n");
 fprintf(fp,"}}\n");

 if (fp != stdout) fclose(fp);

} /* end of Output_Faces_VRML_DifSp() */








int Cal_NormVec_Of_Plane_Tangent_To_Three_Atoms(N1,N2,p,q,r)
 float N1[3],N2[3];        /* Normal Vector */
 struct ATOM *p,*q,*r;
 /* Return number of solutions (0 or 1 or 2 ) */
{
 /*
 
  This function based on the appendix of a following paper.
  T.O.Yeates. 
  "Algorithms for Evaluating the Long-range Accessibility
   of Protein Surfaces"
  J.Mol.Biol. (1995), Vol.249, 804-815

  <Basic Principle>
  Basically, we try to solve a following two equations 
    N[] dot (q->Pos[] - p->Pos[]) = p->R - q->R  (1) 
    N[] dot (r->Pos[] - p->Pos[]) = p->R - r->R  (2)
  And Norm[] should satisfy       
    N[] dot N[] = 1                              (3)

  <How to solve (1),(2) and (3) ?>
  By matrix vector representaion, (1) and (2) becomes
   W[(2)][(3)] dot N[(3)] = dR[(2)];       (4)   

  To solve equation (3) and (4), one of the three components
  of N[(3)] (N[0], N[1], N[2]) is chosen, 
  make a quadratic equation with chosen components.
  If N[2] is chosen,

  (4) becomes
    |W[0][0] W[0][1]|   |N[0]| = |dR[0]| - N[2] |W[0][2]|
    |W[1][0] W[1][1]|   |N[1]|   |dR[1]|        |W[1][2]|
    
     T      dot (N[0],N[1]) = dR - N[2] (W[0][2],W[2][2]) 

    (N[0],N[1]) = inv_T dot dR - N[2] inv_T (W[0][2],W[2][2])  (5)
    (N[0],N[1]) = a[(2)] - N[2] b[(2)]                         

  If (5) is inserted to (3),
    (N[0],N[1]) dot (N[0],N[1]) + N[2]*N[2] = 1 
    (a-N[2]b) dot (a-N[2]b) + N[2]*N[2] = 1 
    (b*B+1)N[2]*N[2] - 2 * a*b N[2] + a*a -1  = 0 (6)

  The simple quadratic equation (6) can be solved easily.  
  Normally, the quadratic equation has two solutions,
  however, if the equation is degenerated, it has only one solution.  
  Therefore,  we have to chose the variable with 
  non-zero determinant of (6) (DetQ). 
 
  <Selection of x,y,z>
  The scheme described above is based on z-coordinates (N[2]) is
  the variable of quadratic equation(6). However, it is not always
  the best choice, you should choose N[0] or N[1] for the case of atom
  plane (p,q,r) is parallel to Z-axis. Therefore, we choose the optimal
  (x,y,z) among (0,1,2),(2,0,1),(1,2,0) by choosing the largest |detT|. 
 
  <Float or Double ?>
  For precise calculation all the real numbers are calculated using "double"
  in this function, although all atom Position and Radius are stored in "float".

 */

 double W[2][3];          /* vector p->q, vector p->r */
 double T[2][2],iT[2][2]; /* Inverse of T[2][2] */
 double dR[2],a[2],b[2];
 double A,B,C; /* terms for quadra equation */
 double DetT; /* Determinant for matrix T */
 double DetQ; /* Determinant for quadratic equation */
 double DetT012,DetT201,DetT120;
 int i,x,y,z;
 double LenN1,LenN2;

 dR[0] = p->R - q->R; dR[1] = p->R - r->R;

 for (i=0;i<3;++i)
 { W[0][i] = q->Pos[i] - p->Pos[i];
   W[1][i] = r->Pos[i] - p->Pos[i]; }

 /** [0] for the case when all three radiuses are zero (very special case) **/ 
 if ((p->R==0.0)&&(q->R==0.0)&&(r->R==0.0)) 
 { N1[0] = W[0][1]*W[1][2] - W[0][2]*W[1][1];
   N1[1] = W[0][2]*W[1][0] - W[0][0]*W[1][2];
   N1[2] = W[0][0]*W[1][1] - W[0][1]*W[1][0];

   LenN1 = N1[0]*N1[0] + N1[1]*N1[1] + N1[2]*N1[2];
   if (LenN1>0.0) LenN1 = sqrt(LenN1); 
     else {printf("#ERROR(simple outprod):norm N1 is zero\n"); exit(1);}
   N1[0] /= LenN1;  N1[1] /= LenN1;  N1[2] /= LenN1;  

   N2[0] = -N1[0];
   N2[1] = -N1[1];
   N2[2] = -N1[2]; 
   return(2);
 } 

 /*** [1] Try combination of (x,y,z) until finding DetQ(T)!= 0 ***/
 x = 0; y = 1; z = 2;
 DetT012 = fabs(W[0][x]*W[1][y] - W[0][y]*W[1][x]);
 x = 2; y = 0; z = 1;
 DetT201 = fabs(W[0][x]*W[1][y] - W[0][y]*W[1][x]); 
 x = 1; y = 2; z = 0;
 DetT120 = fabs(W[0][x]*W[1][y] - W[0][y]*W[1][x]);


 if ((DetT012<PAR.eps)&&(DetT201<PAR.eps)&&(DetT120<PAR.eps))
 { /* Give Up ! */ return(0); }
 else
 { 
       if ((DetT012>=DetT201)&&(DetT012>=DetT120)) { x = 0; y = 1; z = 2;}
  else if ((DetT201>=DetT012)&&(DetT201>=DetT120)) { x = 2; y = 0; z = 1;}
  else if ((DetT120>=DetT012)&&(DetT120>=DetT201)) { x = 1; y = 2; z = 0;}
  DetT = W[0][x]*W[1][y] - W[0][y]*W[1][x]; 
 }

 /*** [2] Set T,iT,a,b  ***/

 T[0][0] = W[0][x]; T[0][1]=W[0][y];
 T[1][0] = W[1][x]; T[1][1]=W[1][y];

 iT[0][0] =  T[1][1]/DetT; iT[0][1] = -T[0][1]/DetT;
 iT[1][0] = -T[1][0]/DetT; iT[1][1] =  T[0][0]/DetT;

 a[0] = iT[0][0]*dR[0] + iT[0][1]*dR[1];
 a[1] = iT[1][0]*dR[0] + iT[1][1]*dR[1];

 b[0] = iT[0][0]*W[0][z] + iT[0][1]*W[1][z];
 b[1] = iT[1][0]*W[0][z] + iT[1][1]*W[1][z];


 /*** [3] Solve quadratic equation to DetQermine N[z]  ***/
 /***     Then calculate N[x] and N[y] by N[z]        ***/

 A = b[0]*b[0] + b[1]*b[1] + 1.0;
 B = -2.0*(a[0]*b[0] + a[1]*b[1]);
 C = a[0]*a[0]+a[1]*a[1] - 1.0;
 
 DetQ = B*B-4.0*A*C;

 /*
 printf("A %lf B %f C %lf DetQ %lf %e\n",A,B,C,DetQ,DetQ);
 */

 
 if (DetQ <0.0) 
 { 
  /*
  printf("#WARNING DetQ[%f] is less than 0\n",DetQ);
  printf("ATOM  %5s %4s %3s %c%5s   %8.3f%8.3f%8.3f%6.2f%6.2f\n",
  p->Anum,p->Atom,p->Resi,p->Chain,p->Rnum,p->Pos[0],p->Pos[1],p->Pos[2],p->R,p->tFactor);
  printf("ATOM  %5s %4s %3s %c%5s   %8.3f%8.3f%8.3f%6.2f%6.2f\n",
  q->Anum,q->Atom,q->Resi,q->Chain,q->Rnum,q->Pos[0],q->Pos[1],q->Pos[2],q->R,q->tFactor);
  printf("ATOM  %5s %4s %3s %c%5s   %8.3f%8.3f%8.3f%6.2f%6.2f\n",
  r->Anum,r->Atom,r->Resi,r->Chain,r->Rnum,r->Pos[0],r->Pos[1],r->Pos[2],r->R,r->tFactor);
  printf("#x %d y %d z %d\n",x,y,z);
  printf("a %lf %lf b %lf %lf\n",a[0],a[1],b[0],b[1]);
  printf("DetT %lf %e\n",DetT,DetT);
  printf("A %lf B %lf C %lf\n",A,B,C);
  */
  return(0);
 }


 if (DetQ<PAR.eps) /* Approximately, DetQ == 0.0 */
  {
   N1[z] = -B/(2.0*A);
   N1[x] = a[0] - N1[z]*b[0];
   N1[y] = a[1] - N1[z]*b[1];
   LenN1 = N1[0]*N1[0] + N1[1]*N1[1] + N1[2]*N1[2];
   if (LenN1>0.0) LenN1 = sqrt(LenN1); 
    else {printf("#ERROR:norm N1 is zero.(%f %f %f)\n",N1[0],N1[1],N1[2]); exit(1);}
   N1[0] /= LenN1;  N1[1] /= LenN1;  N1[2] /= LenN1;  
   return(1);
  }

  if (DetQ > 0.0)
  {
   DetQ = sqrt(DetQ);
   N1[z] = (-B+DetQ)/(2.0*A);
   N1[x] = a[0] - N1[z]*b[0];
   N1[y] = a[1] - N1[z]*b[1];
   N2[z] = (-B-DetQ)/(2.0*A);
   N2[x] = a[0] - N2[z]*b[0];
   N2[y] = a[1] - N2[z]*b[1];

   LenN1 = N1[0]*N1[0] + N1[1]*N1[1] + N1[2]*N1[2];
   if (LenN1>0.0) LenN1 = sqrt(LenN1); 
    else {printf("#ERROR:norm N1 is zero.(%f %f %f)\n",N1[0],N1[1],N1[2]); exit(1);}
   N1[0] /= LenN1;  N1[1] /= LenN1;  N1[2] /= LenN1;  

   LenN2 = N2[0]*N2[0] + N2[1]*N2[1] + N2[2]*N2[2];
   if (LenN2>0.0) LenN2 = sqrt(LenN2); 
    else {printf("#ERROR:norm N2 is zero.(%f %f %f)\n",N2[0],N2[1],N2[2]); exit(1);}
   N2[0] /= LenN2;  N2[1] /= LenN2;  N2[2] /= LenN2;  

   return(2);
  }

} /* end of Cal_NormVec_Of_Plane_Tangent_To_Three_Atoms() */



void Make_CounterClockWise_By_Nvec(f,nvec)
 struct SH_FACE *f;
 float  nvec[3];  /* Normal Vector */
{
 int    i;
 float Vx[3],Vy[3],Vz[3],dprod,buf_pos[3]; 
 struct ATOM *buf_atm; 
 /*
 if CounterClockWise
      t0 
    /  |
  t1--t2   (t0->t1) x (t0->t2) is the direction of nvec

 */

 printf("#Make_CounterClockWise_By_Nvec(f[%d])\n",f->num);
 for (i=0;i<3;++i) Vx[i] = f->tpnt[1][i] - f->tpnt[0][i]; 
 for (i=0;i<3;++i) Vy[i] = f->tpnt[2][i] - f->tpnt[0][i]; 
 
 Cross_Vec(Vz,Vx,Vy);
 dprod = Dot_Prod(nvec,Vz);
 
 if (dprod<0) 
 { 
   buf_atm = f->atom[1]; 
   f->atom[1] = f->atom[2];
   f->atom[2] = buf_atm; 
   for (i=0;i<3;++i) buf_pos[i] = f->tpnt[1][i]; 
   for (i=0;i<3;++i) f->tpnt[1][i] = f->tpnt[2][i]; 
   for (i=0;i<3;++i) f->tpnt[2][i] = buf_pos[i]; 
 }


} /* end of Make_CounterClockWise_By_Nvec() */


int Choose_One_Nvec_By_Face_Atoms(f,nvec)
 struct SH_FACE *f;   
 float  nvec[2][3];  /* Given Two Normal Vectors */
{
 int   i,k;
 float Vx[3],Vy[3],Vz[3],dprod; 
 /*

 
 if CounterClockWise
      a0 
    /  |
  a1--a2   (a0->a1) x (a0->a2) is the direction of nvec

  
 */

 /*
 printf("#Choose_One_Nvec_By_Face_Atoms(f[%d] atm %s %s %s)\n",
		  f->num,f->atom[0]->Anum,f->atom[1]->Anum,f->atom[2]->Anum);
 */ 

 /* (1) Calculate normal vector Vz for atoms in face f */ 
 for (k=0;k<3;++k) Vx[k] = f->atom[1]->Pos[k] - f->atom[0]->Pos[k]; 
 for (k=0;k<3;++k) Vy[k] = f->atom[2]->Pos[k] - f->atom[0]->Pos[k]; 
 Cross_Vec(Vz,Vx,Vy);

 
 /* (2) Devide which nvec is the direction of  Vz, and return 0 or 1 */ 
 for (i=0;i<2;++i)
 {
  dprod = Dot_Prod(nvec[i],Vz);
  /* 
  printf("#nvec[%d] %f %f %f dprod %f\n", i,nvec[i][0],nvec[i][1],nvec[i][2],dprod);
  */
  if (dprod>0.0) return(i); 
 } 

 /* (3) If both nvecs are not directed to Vz, return -1 */ 
 
 printf("Vz    %f %f %f\n",Vz[0],Vz[1],Vz[2]);
 printf("nv0 %f %f %f dprod(nv0,Vz) %f\n",nvec[0][0],nvec[0][1],nvec[0][2],Dot_Prod(nvec[0],Vz));
 printf("nv1 %f %f %f dprod(nv1,Vz) %f\n",nvec[1][0],nvec[1][1],nvec[1][2],Dot_Prod(nvec[1],Vz));

 return(-1);


} /* end of Choose_One_Nvec_By_Face_Atoms() */



void Cross_Vec(C,A,B)   /* This function is only for 3-D */
 float C[3],A[3],B[3];
{ C[0] = A[1]*B[2] - A[2]*B[1];
  C[1] = A[2]*B[0] - A[0]*B[2];
  C[2] = A[0]*B[1] - A[1]*B[0]; }


float Dot_Prod(A,B)
 float *A,*B;
{ int i;
  float prod;
  prod = 0.0;
  for (i=0;i<3;++i) prod += A[i]*B[i];
  return(prod); }






int Free_Faces_DifSp(Fhead)
 struct SH_FACE *Fhead;
{
 struct SH_FACE *f,*pf;
 int Nfree;

 /* 
 printf("#Free_Faces_DifSp(Fhead)\n"); fflush(stdout);
 */ 
 if (Fhead->next == NULL) return(0); 

 f = Fhead; pf = NULL; Nfree = 0;
 while (f->next != NULL)
  {
   pf = f; 
   f = f->next;
   /* printf("fnum %d\n",f->num); fflush(stdout); */
   if ((pf != Fhead)&&(pf != NULL)) { free(pf); pf = NULL; ++Nfree;}
  }

 if (f!=NULL) { free(f); f = NULL; ++Nfree;}
 Fhead->next = NULL;
 return(Nfree);

} /* end of Free_Faces_DifSp() */



void Initialize_Mark(Ahead)
 struct ATOM *Ahead;
{
 struct ATOM *an;

 an = Ahead; 
 while (an->next != NULL) 
  { an = an->next; 
    an->mark = 0; }

} /* end of Set_Mark_Zero() */





void Set_Nvec_to_Face(f,nvec)
 struct SH_FACE *f;
 float nvec[3];
{
 int i,k;

 for (k=0;k<3;++k) f->nvec[k] = nvec[k];

 /** Cal tpnt **/
 for (i=0;i<3;++i)
 {
   for (k=0;k<3;++k)
    f->tpnt[i][k] = f->atom[i]->Pos[k] + f->atom[i]->R * nvec[k];
  }

} /* end of  Set_Nvec_to_Face() */




void Set_Nvec_to_Atoms_By_Faces(Ahead,Fhead)
  struct ATOM *Ahead;
  struct SH_FACE *Fhead;
{
 struct ATOM *an;
 struct SH_FACE *fn;
 int i;
 float E0[3],E1[3],E2[3];

 /*
  Normal Vector of Atoms is defined as averaged vector from connected neighbors.
  
   nvec = 1/Nneighbor sum_{neighbor_atoms}[(Pos - neighbor.Pos)/|Pos - neighbor.Pos|]
 */

 /* printf("#Set_Nvec_to_Atoms_By_Faces()\n"); */
 /** [1] Initialize nvec[] and Nedge **/ 
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  an->nvec[0] = an->nvec[1] = an->nvec[2] = 0.0;
  an->Nedge = 0;
 } 

 /** [2] Sum up all the edge vectors **/ 
 fn = Fhead;
 while (fn->next != NULL)
 {
  fn = fn->next;
  Sub_Vec(E0,fn->atom[1]->Pos,fn->atom[0]->Pos); 
  Normalize(E0);
  Sub_Vec(E1,fn->atom[2]->Pos,fn->atom[1]->Pos); 
  Normalize(E1);
  Sub_Vec(E2,fn->atom[0]->Pos,fn->atom[2]->Pos); 
  Normalize(E2);
  Increment_Plus(fn->atom[1]->nvec,E0); 
  Increment_Minus(fn->atom[0]->nvec,E0); 
  
  Increment_Plus(fn->atom[2]->nvec,E1); 
  Increment_Minus(fn->atom[1]->nvec,E1); 
  
  Increment_Plus(fn->atom[0]->nvec,E2); 
  Increment_Minus(fn->atom[2]->nvec,E2); 
  
  fn->atom[0]->Nedge += 2; 
  fn->atom[1]->Nedge += 2; 
  fn->atom[2]->Nedge += 2; 
 }

 /** [3] Calculate nvec[] **/ 
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  if (an->Nedge>0)
  { an->nvec[0] /= an->Nedge;
    an->nvec[1] /= an->Nedge;
    an->nvec[2] /= an->Nedge; }
  Normalize(an->nvec); 
 }

} /* end of Set_Nvec_to_Atoms_By_Faces() */




void Sub_Vec(C,A,B)
 float C[3],A[3],B[3];
{  C[0] = A[0]-B[0]; 
   C[1] = A[1]-B[1];
   C[2] = A[2]-B[2];
} /* end of Sub_Vec(A,B) */



void Normalize(A)
 float A[3];
{  float dis;
  dis = A[0]*A[0] + A[1]*A[1] + A[2]*A[2];
  if (dis>0.0)
   { dis = sqrt(dis);
     A[0] /= dis; A[1] /= dis; A[2] /= dis; }
} /* end Normalize() */


void Increment_Plus(A,B)
 float A[3],B[3];
{ A[0] += B[0];
  A[1] += B[1];
  A[2] += B[2];
} /* end of Increment_Plus(A,B) */



void Increment_Minus(A,B)
 float A[3],B[3];
{ A[0] -= B[0];
  A[1] -= B[1];
  A[2] -= B[2];
} /* end of Increment_Minus(A,B) */





void Remove_Atoms_Crashed_With_Planes(Phead,Fhead)
 struct ATOM *Phead;   /* Head of probed atoms to be checked */
 struct SH_FACE *Fhead; /* Head of Faces of Convex Hull */
{
 struct ATOM *pn,*rn;
 struct SH_FACE *fn;
 char crash;
 float  PV[3],dis;

 printf("#Remove_Atoms_Crashed_With_Planes()\n"); fflush(stdout);
 pn = Phead; crash = 0;
 while (pn->next != NULL)
 {
   pn = pn->next;
   fn = Fhead;
   crash = 0;
   while ((fn->next != NULL) &&(crash==0))
   {
    fn = fn->next;
    PV[0] = pn->Pos[0] - fn->tpnt[0][0];
    PV[1] = pn->Pos[1] - fn->tpnt[0][1];
    PV[2] = pn->Pos[2] - fn->tpnt[0][2];
    dis = fn->nvec[0] * PV[0] + fn->nvec[1] * PV[1] + fn->nvec[2] * PV[2];
    if (dis < 0.0) dis = fabs(dis);
    if (dis < pn->R) crash = 1;
   }

   if (crash == 1)
   { sprintf(pn->Resi,"XXX");
     pn->prev->next = pn->next;
     if (pn->next != NULL) pn->next->prev = pn->prev; }
 }

} /* end of Remove_Atoms_Crashed_With_Planes() */




void Write_PDB_File_Planes(ofname,Fhead,mode,comment,command)
 char *ofname;
 struct SH_FACE *Fhead; /* Head of Faces of Convex Hull */
 char mode; /* 'a'ppend, 'w'rite */
 char *comment;
 char *command;
{
 FILE *fpo;
 struct SH_FACE *fn;
 int Nface;

 if (ofname[0]=='-') fpo = stdout;
 else
 { if (mode=='a') fpo = fopen(ofname,"a");
            else  fpo = fopen(ofname,"w");
   if (fpo == NULL) { printf("#ERROR:Can't write to \"%s\"\n",ofname); exit(1);} 
   printf("#Write_PDB_File_Planes()-->\"%s\"\n",ofname);
 }

 fprintf(fpo,"HEADER FILES FOR TANGENT PLANES\n");
 fprintf(fpo,"REMARK One of the three tangent points and normal vectors are described.\n");
 if (comment[0]!='\0') { fprintf(fpo,"REMARK %s\n",comment); }
 if (command[0]!='\0') { fprintf(fpo,"REMARK COMMAND %s\n",command); }

 fprintf(fpo,"REMARK DATE %s\n",Get_Date_String());
 fprintf(fpo,"REMARK%5s %4s %3s  %4s    %8s%8s%8s%6s%6s%6s\n",
  "","","","","Tpnt0x","Tpnt0y","Tpnt0z","Nv_x","Nv_y","Nv_z");
 fn = Fhead; Nface = 0;
 while (fn->next != NULL)
 {
  fn = fn->next;
  ++Nface;
  fprintf(fpo,"HETATM%5d %4s %3s %c%4d    %8.3f%8.3f%8.3f%6.3f%6.3f%6.3f\n",
       Nface,"CA ","PLN",'P',(Nface/10)+1,
       fn->tpnt[0][0],fn->tpnt[0][1],fn->tpnt[0][2], fn->nvec[0],fn->nvec[1],fn->nvec[2]);
 } /* fn */

 fprintf(fpo,"TER\n");
 fclose(fpo);

} /* end of void Write_PDB_File_Planes() */

