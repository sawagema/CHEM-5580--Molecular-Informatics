#!/usr/bin/perl


$LastModDate = "Sep 14, 2004";

if (scalar(@ARGV)<1)
{
 print "corbind.pl [res_probe_file] [ligand_file]\n";
 print " coded by T.Kawabata. LastModified:$LastModDate\n";
 exit(1);
}

$probfile = $ARGV[0];
$ligfile  = $ARGV[1];


&Read_Residue_Based_Probe_File($probfile,\@RNUMlist,\%PDAT);
&Read_Ligand_File($ligfile,\@RNUMlistL,\%LDAT);

print "#probfile \"$probfile\" ligfile \"$ligfile\"\n";

#foreach $r (@RNUMlist)
#{
# printf("%s %s %s %s %d\n",
#   $r,$PDAT{$r}->{'rnum'},$PDAT{$r}->{'res'},$PDAT{$r}->{'Mprb'},$LDAT{$r}->{'Nc_tar'});
#}

@Xitem = ('Nprb','Vprb','Mprb');
#@Yitem = ('Nc_self','Dc_min');
@Yitem = ('Nc_self');


foreach $xi (@Xitem)
{
 foreach $yi (@Yitem)
 {
  printf("CC %-8s vs %-8s %lf\n",$xi,$yi,&CorrCoeff(\@RNUMlist,\%PDAT,$xi,\%LDAT,$yi));
 }
}

#################
### FUNCTIONS ###
#################

sub CorrCoeff{
 my($rlist,$xdat,$xitem,$ydat,$yitem) = @_;
 my($r); my($x); my($y);
 my($Sx) = 0.0; my($Sxx) = 0.0; 
 my($Sy) = 0.0; my($Syy) = 0.0; my($Sxy) = 0.0; 
 my($N) = 0; my($Mx); my($My); my($SDx); my($SDy);
 my($Vx); my($Vy); my($CC);
 
 foreach $r (@{$rlist})
 {
  $x = $xdat->{$r}->{$xitem};  
  $y = $ydat->{$r}->{$yitem};  
 # print "x $x y $y\n";
  $Sx += $x;
  $Sy += $y;
  $Sxx += $x*$x;
  $Syy += $y*$y;
  $Sxy += $x*$y;
  ++$N;
 }

 $Mx  = $Sx/$N;
 $Vx  = $Sxx/$N - $Mx*$Mx;
 $My  = $Sy/$N;
 $Vy  = $Syy/$N - $My*$My;
 $Vxy = $Sxy/$N - $Mx*$My; 
 #print "N $N Mx $Mx Vx $Vx My $My Vy $Vy Vxy $Vxy \n"; 
 if ($Vx > 0)  {$SDx = sqrt($Vx); } else {return(0.0);}
 if ($Vy > 0)  {$SDy = sqrt($Vy); } else {return(0.0);}

 $CC = $Vxy/$SDx/$SDy;
 return($CC);

} ## end of CorrCoeff() ##



sub Read_Residue_Based_Probe_File{
 my($fname,$rnumlist,$dat) = @_; 
 my($F); my(@D);
 my($rnum); my($chain); my($res);
 my($Natm); my($Nprb); my($Vprb); my($Mprb);
 my($n) = 0; my($s);

 @{$rnumlist} = (); %{$dat} = ();
 #<< FILE_FORMAT_EXAMPLE >>
 # #>> Volume of Pocket Probes <<
 # #[RNUM] [CHAIN] [RES] [Natm] [Nprb] [Vprb(A^3)] [Mprb] [Mmxcl] [clus_num]
 #   2  - LYS    9    0   0.00   0.00   0.00
 #  10  - THR    7    4  27.68   1.13  13.78 1
 #  11  - GLN    9    0   0.00   0.00   0.00
 #  12  - THR    7    7  40.37   1.65  13.78 1
 #  13  - GLY    4    0   0.00   0.00   0.00
 #  14  - LYS    9   15 105.43   4.32  13.78 1
 #  15  - THR    7    5  31.22   1.28  13.78 1

 open(F,$fname) || die "#ERROR:Can't open probfile \"$fname\"";
 while (<F>)
 {
  if ($_ !~/^#/)
 {
   $_ =~s/^\s+//;
   $_ =~s/\s+$//;
   ($rnum,$chain,$res,$Natm,$Nprb,$Vprb,$Mprb) = split(/\s+/,$_); 

   $r = "$rnum$chain";
   push(@{$rnumlist},$r);
   $dat->{$r}->{'chain'} = $chain;
   $dat->{$r}->{'res'}   = $res;
   $dat->{$r}->{'rnum'}  = $rnum;
   $dat->{$r}->{'Natm'}  = $Natm;
   $dat->{$r}->{'Nprb'}  = $Nprb;
   $dat->{$r}->{'Vprb'}  = $Vprb;
   $dat->{$r}->{'Mprb'}  = $Mprb;
   ++$n; 
   } 
 }
 close(F);

} ## end of Read_Residue_Based_Probe_File() ##






sub Read_Ligand_File{
 my($fname,$rnumlist,$dat) = @_;
 my($flag);
 my($rnum); my($chain); my($res); 
 my($Nc_self); my($Dc_min); my($plain_num);
 @{$rnumlist} = (); %{$dat} = ();

 #<< FILE_FORMAT_EXAMPLE >>
 # MODE       P
 # PROTEIN      1|pro|-|
 #  PARTNER     2|FMN|-|171|
 # # [RNUM] [CHAIN] [RES] [Nc_pair] [Nc_atm_self] [Nc_atm_tar] [Dc_min]
 #    10  - THR  6  3  4 2.661
 #    11  - GLN  5  4  2 3.009
 #    12  - THR 11  6  4 2.598
 #    13  - GLY  3  3  1 3.192
 #
 # PROTEIN      1|pro|-|
 #  PARTNER     2|FMN|-| 170 |
 #  [RNUM] [CHAIN] [RES] [Nc_atm_self] [Dc_min] [Plain_Rnum]
 #   10  - THR  3 2.661    9
 #   11  - GLN  4 3.009   10
 #   12  - THR  6 2.598   11
 #   13  - GLY  3 3.192   12


 open(F,$fname) || die "#ERROR:Can't open ligfile \"$fname\"";

 $flag = 0; 
 while (<F>)
 {
   if (($flag==1)&&($_=~/^\/\//)) { $flag = 0; }
   if ($flag == 1)
   {   
    $_ =~s/^\s+//;
    $_ =~s/\s+$//;
    ($rnum,$chain,$res,$Nc_self,$Dc_min,$plain_num) = split(/\s+/,$_); 
    $r = "$rnum$chain";
    push(@{$rnumlist},$r);
    $dat->{$r}->{'chain'} = $chain;
    $dat->{$r}->{'res'}   = $res;
    $dat->{$r}->{'rnum'}  = $rnum;
    $dat->{$r}->{'Nc_self'} = $Nc_self;
    $dat->{$r}->{'Dc_min'}  = $Dc_min;
    $dat->{$r}->{'plain_min'}  = $plain_min;
     
    } 
   if ($_ =~/^ PARTNER/) {$flag = 1;}
  
 }  # while #

 close(F);

}## end of Read_Ligand_File() ##a



