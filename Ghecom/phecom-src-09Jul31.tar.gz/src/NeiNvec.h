/*

 <NeiNvec.h>

*/

/** FUNCTIONS (GLOBAL) **/
extern void Make_NEIGHBOR_ATOM();
extern void Set_Nvec_to_Atoms_By_NEIGHBOR_ATOMS();
extern void Free_NEIGHBOR_ATOM();
