#!/usr/bin/perl
#
# <corres.pl>
#

$LastModDate = "Sep 14, 2004";

if (scalar(@ARGV)<1)
{
 print "corres.pl [residue_file1] [residue_file2] [col1] [col2]\n";
 print " coded by T.Kawabata. LastModified:$LastModDate\n";
 exit(1);
}

$resfile1 = $ARGV[0];
$resfile2 = $ARGV[1];
$col1     = $ARGV[2];
$col2     = $ARGV[3];

&Read_Residue_Based_File($resfile1,\@RNUMlist1,\%DAT1);
&Read_Residue_Based_File($resfile2,\@RNUMlist2,\%DAT2);

print "#resfile1 \"$resfile1\" resfile2 \"$resfile2\"\n";

foreach $r (@RNUMlist1)
{
 printf("%s %s %s %s %s %s\n",
   $DAT1{$r}->{$col1},$DAT2{$r}->{$col2}, 
   $r,$DAT1{$r}->{'rnum'},$DAT1{$r}->{'chain'},$DAT1{$r}->{'res'});
}


#################
### FUNCTIONS ###
#################

sub CorrCoeff{
 my($rlist,$xdat,$xitem,$ydat,$yitem) = @_;
 my($r); my($x); my($y);
 my($Sx) = 0.0; my($Sxx) = 0.0; 
 my($Sy) = 0.0; my($Syy) = 0.0; my($Sxy) = 0.0; 
 my($N) = 0; my($Mx); my($My); my($SDx); my($SDy);
 my($Vx); my($Vy); my($CC);
 
 foreach $r (@{$rlist})
 {
  $x = $xdat->{$r}->{$xitem};  
  $y = $ydat->{$r}->{$yitem};  
 # print "x $x y $y\n";
  $Sx += $x;
  $Sy += $y;
  $Sxx += $x*$x;
  $Syy += $y*$y;
  $Sxy += $x*$y;
  ++$N;
 }

 $Mx  = $Sx/$N;
 $Vx  = $Sxx/$N - $Mx*$Mx;
 $My  = $Sy/$N;
 $Vy  = $Syy/$N - $My*$My;
 $Vxy = $Sxy/$N - $Mx*$My; 
 #print "N $N Mx $Mx Vx $Vx My $My Vy $Vy Vxy $Vxy \n"; 
 if ($Vx > 0)  {$SDx = sqrt($Vx); } else {return(0.0);}
 if ($Vy > 0)  {$SDy = sqrt($Vy); } else {return(0.0);}

 $CC = $Vxy/$SDx/$SDy;
 return($CC);

} ## end of CorrCoeff() ##



sub Read_Residue_Based_File{
 my($fname,$rnumlist,$dat) = @_; 
 my($F); my(@D);
 my($rnum); my($chain); my($res);
 my($n) = 0; my($s);

 @{$rnumlist} = (); %{$dat} = ();
 #<< FILE_FORMAT_EXAMPLE >>
 # #>> Volume of Pocket Probes <<
 # #[RNUM] [CHAIN] [RES] [val1] [val2] [val3] ..
 #   2  - LYS    9    0   0.00   0.00   0.00
 #  10  - THR    7    4  27.68   1.13  13.78 1
 #  11  - GLN    9    0   0.00   0.00   0.00
 #  12  - THR    7    7  40.37   1.65  13.78 1
 #  13  - GLY    4    0   0.00   0.00   0.00
 #  14  - LYS    9   15 105.43   4.32  13.78 1
 #  15  - THR    7    5  31.22   1.28  13.78 1

 open(F,$fname) || die "#ERROR:Can't open probfile \"$fname\"";
 while (<F>)
 {
  if ($_ !~/^#/)
 {
   $_ =~s/^\s+//;
   $_ =~s/\s+$//;
   @D = split(/\s+/,$_);

   $rnum  = $D[0];
   $chain = $D[1];
   $res   = $D[2];
   
   $r = "$rnum$chain";
   push(@{$rnumlist},$r);
   $dat->{$r}->{'chain'} = $chain;
   $dat->{$r}->{'res'}   = $res;
   $dat->{$r}->{'rnum'}  = $rnum;
   for ($i=3;$i<scalar(@D);++$i) { $dat->{$r}->{$i-3} = $D[$i]; }
   ++$n; 
   } 
 }
 close(F);

} ## end of Read_Residue_Based_File() ##


