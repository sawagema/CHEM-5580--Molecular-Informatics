/*

 <EachVol.h>

*/

extern void Cal_Each_Atom_Probe_Volume();
extern float Standard_Volume();
extern float Cal_Atoms_Volume_By_Marching_Cube();
extern void Cal_Each_Residue_Nprobe_surf();
