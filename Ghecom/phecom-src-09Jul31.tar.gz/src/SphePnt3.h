/*

 <SphePnt3.h>

*/

extern int  Cal_Sphere_On_Three_Atoms();
extern void Make_Probe_Spheres_Three_Contact();
extern void Make_Probe_Spheres_Three_Contact_ColVoxel();
extern void Make_Probe_Spheres_Three_Contact_PairColVoxel();
extern void Make_Probe_Spheres_Three_Contact_PairColVoxel_Overlap();
extern void Make_Probe_Spheres_Three_Contact_Overlap();
extern void Make_Probe_Spheres_Three_Contact_ColVoxel_Overlap();
extern int  Make_Probe_One_Probe_Two_Protein();
extern void Remove_Crashed_Atom();
extern void Joint_Atom_List();
extern void Assign_ChainID();
extern int  Check_Crash_Pos_and_Atoms();
extern void Add_Atom_Stack();
extern void Renumber_AnumRnum();
