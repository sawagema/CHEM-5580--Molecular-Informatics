/*
 <MulRlarge.h>
*/

extern void Try_Multiple_Large_Spheres();
extern void Generate_Multiple_Large_Spheres();
