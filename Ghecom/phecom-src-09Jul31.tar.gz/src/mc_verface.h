/*

<mc_verface.h>

 Definition of Vertex and Face for Marching Cube,
 and MIDPNT and MIDMAP for overlap checking map
 
  When we want to know a midpoint between [x0][y0][z0] and [x1][y1][z1] is
  already constructed or not, 
  we check MIDMAP[x0][y0][z0]->ver[x1-x0+1][y1-y0+1][z1-z0+1] is NULL or not.

*/


struct MC_VERTEX{
 int num;                 /* Number of Vertex [0..Nvertex-1]*/
 float pos[3];            /* XYZ coordinates  */
 struct MC_VERTEX *next;  /* for linked list  */
};


struct MC_FACE{
 struct MC_VERTEX *a,*b,*c; /* Three MC vertices which composed of triangle */
 struct MC_FACE *next;      /* for linked list  */
};


/*
 
 MIDPNT and MIDMAP are for checking overlap of midpoints quickly. 

*/


struct MIDPNT{
 /*
   dx = (-1,0,+1) -> [0,1,2] 
   dy = (-1,0,+1) -> [0,1,2] 
   dz = (-1,0,+1) -> [0,1,2] 
  */
 struct MC_VERTEX *ver[3][3][3];
}; 


struct MIDMAP{
 int Y,Z; 
 struct MIDPNT **map; /* map[Y][Z] */
};
