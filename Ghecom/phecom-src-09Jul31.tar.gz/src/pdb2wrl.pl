#!/usr/bin/perl
#
# <pdb2wrl.pl>
#

$LastModDate = "Oct 8, 2004";

$OPT{'X'} = $OPT{'Y'} = $OPT{'Z'} = 20;
$OPT{'A'} eq '';
$OPT{'of'} = '';
$OPT{'R'} = 'C';
$OPT{'C'} = 'C';
$OPT{'tr'} = '0.0';
$OPT{'minr'} = '0.0';
$OPT{'maxr'} = '100000.0';

if (scalar(@ARGV)<1)
{
 print "pdb2wrl.pl [pdbfile]\n";
 print " to change PDB file to SpaceFill vrml file (*.wrl)\n";
 print " coded by T.Kawabata. LastModified:$LastModDate\n";
 printf(" -of   : Output file [%s]\n",$OPT{'of'});
 printf(" -R    : Radius type 'C'pk 'O'ccup 'T'factor 'U'nified [%s]\n",$OPT{'R'});
 printf(" -C    : Color  type 'C'pk 'U'nified [%s]\n",$OPT{'C'});
 printf(" -r    : unified radius [%s]\n",$OPT{'co'});
 printf(" -co   : unified color  [%s]\n",$OPT{'co'});
 printf(" -tr   : transparency  [%s]\n",$OPT{'tr'});
 printf(" -minr : Minimum Radius  [%s]\n",$OPT{'minr'});
 printf(" -maxr : Maximum Radius  [%s]\n",$OPT{'maxr'});
 exit(1);
}

$pdbfile = $ARGV[0];
&Read_Options(\@ARGV,\%OPT);
&Read_PDB_File($pdbfile,'-','A',\%DAT);
&Set_Atom_Radius_Color(\%DAT);


if ($OPT{'of'} eq '')
{
 ($head,$tail) = split(/\./,$pdbfile);
 $OPT{'of'} = $head.'.wrl';
}
&Output_VRML_File($OPT{'of'},\%DAT);


#################
### FUNCTIONS ###
#################

sub Output_VRML_File{
 my($ofile,$dat) = @_;
 my($OF);
 my($i);

 if ($ofile ne '-') {printf("#Output_VRML_File() --> \"%s\"\n",$ofile);}
 open(OF,">$ofile");
 print OF "#VRML V2.0 utf8\n";

 for ($i=0;$i<scalar(@{$dat->{'X'}});++$i)
{
 if ($dat->{'R'}->[$i]>0.0)
 {

 printf(OF "#%s %s %s\n",$dat->{'atom'}->[$i],$dat->{'res'}->[$i],$dat->{'rnum'}->[$i]);
 print OF "Transform{\n";
 #printf(OF " translation %.1f %.1f %.1f\n",
 #  $dat->{'X'}->[$i],$dat->{'Y'}->[$i],$dat->{'Z'}->[$i]);
 printf(OF " translation %f %f %f\n",
   $dat->{'X'}->[$i],$dat->{'Y'}->[$i],$dat->{'Z'}->[$i]);
 print OF " children[\n";
 print OF " Shape{\n";
 print OF "  appearance Appearance{\n";
 print OF "   material Material{\n";
    if ($dat->{'color'}->[$i] eq 'red')    {$r = 1.0; $g = 0.0; $b = 0.0;}
 elsif ($dat->{'color'}->[$i] eq 'blue')   {$r = 0.0; $g = 0.0; $b = 1.0;}
 elsif ($dat->{'color'}->[$i] eq 'yellow') {$r = 1.0; $g = 1.0; $b = 0.0;}
 elsif ($dat->{'color'}->[$i] eq 'gray')   {$r = 0.7; $g = 0.7; $b = 0.7;}
 elsif ($dat->{'color'}->[$i] eq 'orange') {$r = 1.0; $g = 0.5; $b = 0.0;}
 elsif ($dat->{'color'}->[$i] eq 'green')  {$r = 0.0; $g = 1.0; $b = 0.0;}
 printf(OF "   diffuseColor %.1f %.1f %.1f\n",$r,$g,$b);
 printf(OF "   transparency %.1f\n",$dat->{'trans'}->[$i]);
 print OF "   }}\n";
 printf(OF "  geometry Sphere{ radius %f} }\n",$dat->{'R'}->[$i]);
 print OF " ]\n";
 print OF "}\n";
 }
}

close(OF);

} ## end of Output_VRML_File() ##



sub Set_Atom_Radius_Color{
 my($dat) = @_;

 my($i);

 my(%Radius); my(%Color); my(%Trans);

 $Radius{'N'} = 1.65;
 $Radius{'C'} = 1.87;
 $Radius{'O'} = 1.40;
 $Radius{'S'} = 1.85;
 
 $Color{'N'} = 'blue';
 $Color{'C'} = 'gray';
 $Color{'O'} = 'red';
 $Color{'S'} = 'yellow';
 $Color{'P'} = 'green';
 
 $Trans{'N'} = 0.0;
 $Trans{'C'} = 0.0;
 $Trans{'O'} = 0.0;
 $Trans{'S'} = 0.0;
 $Trans{'P'} = 0.6;

 for ($i=0;$i<$dat->{'Natom'};++$i)
 {
  $atomtype = substr($dat->{'atom'}->[$i],1,1);

  $dat->{'trans'}->[$i] = $OPT{'tr'};
  ### RADIUS ASSIGNMENT ### 
     if ($OPT{'R'} eq 'O') { $dat->{'R'}->[$i]  = $dat->{'occup'}->[$i];  } 
  elsif ($OPT{'R'} eq 'T') { $dat->{'R'}->[$i]  = $dat->{'tFactor'}->[$i];  } 
  elsif ($OPT{'R'} eq 'C') 
    { $dat->{'R'}->[$i]      = $Radius{$atomtype}; }
  elsif ($OPT{'R'} eq 'U') { $dat->{'R'}->[$i]  = $OPT{'r'}; }
  else { $dat->{'R'}->[$i]  = 1.87;}

  if ($dat->{'R'}->[$i] < $OPT{'minr'}) { $dat->{'R'}->[$i] = $OPT{'minr'};}
  if ($dat->{'R'}->[$i] > $OPT{'maxr'}) { $dat->{'R'}->[$i] = 0.0;}

  ### COLOR ASSIGNMENT ### 

   if ($OPT{'C'} eq 'C') 
  { $dat->{'color'}->[$i] = $Color{$atomtype}; 
    if ($Trans{$atomtype} ne '') {$dat->{'trans'}->[$i]  = $Trans{$atomtype}; }
  #  printf("%s %s %s %s\n",$dat->{'atom'}->[$i],$atomtype,$dat->{'R'}->[$i],$dat->{'trans'}->[$i]);
    }
  elsif ($OPT{'C'} eq 'U') { $dat->{'color'}->[$i] = $OPT{'co'}; }
  else  {$dat->{'color'}->[$i] = 'blue';}
 } ## $i ##

} ## end of Set_Atom_Radius_Color() ##




sub Read_Sphere_List{
 my($fname,$dat) = @_;
 my($x); my($y); my($z); my($r);
  
 %{$dat} = ();

 open(F,$fname) || die "#ERROR:Can't open \"$fname\"";
 while (<F>)
 {
  if ($_!~/^#/)
  {
    chomp;
    ($x,$y,$z,$r) = split(/\s+/,$_); 
    push(@{$dat->{'X'}},$x);
    push(@{$dat->{'Y'}},$y);
    push(@{$dat->{'Z'}},$z);
    push(@{$dat->{'R'}},$r);
    push(@{$dat->{'RR'}},$r*$r);
   } 
 } 
 close(F);

} ## end of Read_Sphere_List() ##



sub Read_Options{
 # $_[0] : ref of \@ARGV
 # $_[1] : ref of \%OPT

 # This script is reading following style options :
 #   psiscan.pl org41list -lib 95pdb01Mar4Mx -tail -I -C
 # In principle, the format is the style like  "[-option] [value]"
 # If [value] is omitted, [option] is set to '1'.

 my($x); my($x1); my($i);

 $i = 0;
 while ($i<scalar(@ARGV))
 {
  $x  = $_[0]->[$i];
  $x1 = $_[0]->[$i+1];
  if ($x =~/^\-/)
   { $x =~s/^\-//;
     if (($x1 !~ /^\-\w+/)&&(length($x1)>0)) { $_[1]->{$x} = $x1; ++$i; }
     else { $_[1]->{$x} = 1;}
   }
  ++$i;
 }

} ## end of Read_Options() ##



sub Read_PDB_File{
 my($pdbfile, $spe_chain,$HETtype,$dat) = @_;
 #my($spe_chain) = $_[1]; ## Specified Chain ( if "", not-specified) ##
 #my($HETtype)   = $_[2]; ## 'A'll,'W':excluding waters, 'N'o ##
 #my($newchain)  = $_[3]; ## if "", not-newly assigned.
   
 if ($spe_chain eq '-') {$spe_chain = "";}

 my($F); 
 my($pdb); my($dir);
 my($X);  my($Y);  my($Z);
 my($head); my($tail); my($atom); my($res); my($ch);
 my($out); my($head); my($tail);
 my($tFactor);  my($occup);
   
 open(F,$pdbfile) || die "#ERROR:Can't open pdbfile \"$pdbfile\"";

 $end = 0; $readon = 0;
 $dat->{'Natom'} = 0;
 while(($_=<F>)&&($end==0))
 {
  if ((/^ATOM/)||(/^HETATM/))
   {
    $out = 0;
    $c = substr($_,21,1);
    $atom = substr($_,12,4);
    $res  = substr($_,17,3);
    $rnum  = substr($_,22,4);
    $X = substr($_,30,8); $Y = substr($_,38,8); $Z = substr($_,46,8);
    $ch = substr($head,21,1);
    $occup   = substr($_,54,6);
    $tFactor = substr($_,60,6);
    #print "\"$_\" tFactor \"$tFactor\" occup \"$occup\"\n";
    if (/^ATOM/)
     { if (($spe_chain eq "") ||($ch eq $spe_chain)) {$out = 1;}   }

    if (/^HETATM/)
    { if ($HETtype  eq 'A') {$out = 1;}
      if (($HETtype eq 'W')&&($res ne 'HOH')) {$out = 1;} }

    if ($out == 1)
    {
     if ($newchain ne "")  { substr($head,21,1) = $newchain; }
     #print "atom \"$atom\"\n";
     push(@{$dat->{'X'}},$X); 
     push(@{$dat->{'Y'}},$Y); 
     push(@{$dat->{'Z'}},$Z); 
     push(@{$dat->{'atom'}},$atom); 
     push(@{$dat->{'res'}},$res); 
     push(@{$dat->{'rnum'}},$rnum); 
     push(@{$dat->{'tFactor'}},$tFactor); 
     push(@{$dat->{'occup'}},$occup); 
     $dat->{'Natom'} += 1; 
    }
  }


 } ## while ##
close(F);

} ## end of Read_PDB_File() ##


