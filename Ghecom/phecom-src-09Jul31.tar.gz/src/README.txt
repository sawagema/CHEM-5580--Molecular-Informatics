 >>  PHECOM : Probe based HECOMi finder <<

Oct 21, 2007 

written by Takeshi Kawabata (takawaba@is.naist.jp)

Reference :

 Kawabata T, Go N. "Detection of pockets on protein surfaces
  using small and large probe spheres to find putative ligand binding sites".
   Proteins, 68, 516-529, (2007).


[I] COMPILE 

A program phecom is written in C (gcc), developed in Linux environment.
The procedure for compiling is as follows : 

 >gunzip phecom-src-[date].tar.gz
 >tar xvf phecom-src-[date]-tar
 >cd src
 >make

You will get the execution file "phecom" in the upper directory of "src". 

[II] How to use "phecom"

If you type,
 >phecom -help
detailed information about the options of phecom are shown.


[1] Just calculate pockets 

  >phecom [pdbfile] 
  
 If you want to specify chain identifier, 
  >phecom [pdbfile] -ch [chain identifier]

 The program outputs two files.
   a) [pdbfile].ppdb 
  
       Protein atoms and calculated pocket small sphere probes in PDB format.     
       Pocket small  probes are described with the residue name 'PRB' and
       chain identifier 'P'. The residue name corresponds to the cluster
       number of pocket probes.

   b) [pdbfile].res
 
       Residue-based summary of pockets.

 The RasMol script file "probe.ras" in the 'src' directory
 is helpful to view the [pdbfile].ppdb, by RasMol. If you employ 1.87
 angstrom probes, you should type in the command prompt.

 >rasmol [pdbfile].ppdb
   RasMol> select PRB
   RasMol> color cyan    
   RasMol> spacefill 468

 or just type
   RasMol>script "probe.ras"

 The default radius of small and large probes is 1.87 and 6.0 angstrom.
 These values can be changed by the following options :
 -rs  : Radius of Small Probe [1.870000]
 -rl  : Radius of Large Probe [6.000000]

 We recommend users to try various values of radius of large probes (-rl). 
 Larger radius of large probe sphere genelate larger number of pocket probe spheres.  
 For example, if you want to employ 8 angstom spheres as large probes, you
 just type :
 
  >phecom [pdbfile] -rl 8.0

 The option "-mc" is another important option to control number of pocket probes.
  -mc  : Delete probe clusters with Mprobe <= mc [0.000000]
 This option deletes small pockets with its Mprobe is less than [mc] values.
 The default is zero (don't delete any small pockets).  
 If you feel the most of the generated pockets are too small for your putative
 ligands, I recommend you try  for example,
  
  phecom [pdbfile] -mc 4


[2] Calculate Rinaccess for all the surface small probes
  
  >phecom [pdbfile] -pl M

  The program outputs two files.

   a) [pdbfile].mpdb 
       Protein atoms and calculated surface probes in PDB format.
       "Rinaccess" values are written in the column of tFactor 
       for both protein atoms and probe spheres.
       
      If you want to see all the probes by the Rinaccess coloring:
  >rasmol [pdbfile].mpdb
     RasMol> select
     RasMol> wireframe false 
     RasMol> spacefill false 
     RasMol> select PRB
     RasMol> color temperature    
     RasMol> spacefill 468

      If you want to see all the protein atoms probes by the Rinaccess coloring:
  >rasmol [pdbfile].mpdb
     RasMol> select
     RasMol> wireframe false 
     RasMol> spacefill false 
     RasMol> select protein 
     RasMol> color temperature    
     RasMol> spacefill 

   b) [pdbfile].rac
       Residue-based summary of "Raccess".

  When "-pl M" option is chosen, the phecom program try 13 kinds of
  large probe spheres (3,4,5,6,7,8,9,10,11,12,13,14,15,plane).

  Please note that generating 13 different size large spheres takes 13 times
  longer time than only using one large probe spheres. 

  Rinaccess can have two special state : 
    "plane-accessible"  and 
    "plane-inaccessible,but the largest-sphere-inaccessible".

  In the [pdbfile].mpdb, these two special states has following real values 
  for Rinaccess.

    [plane-inaccessible,but the largest-sphere-inaccessible]  
       --> largest radius + 2.0 angstrom 
    [plane-accessible]
       --> largest radius + 4.0 angstrom 

  The number of trying large probe sphres can be chosed by "-nrl" option.
  
  >phecom [pdbfile] -pl M  -nrl 3
    --> Rlarge = (3,6,9,plane).
  >phecom [pdbfile] -pl M  -nrl 5
    --> Rlarge = (3,5,7,9,11,plane).
  >phecom [pdbfile] -pl M  -nrl 7 
    --> Rlarge = (3,5,7,9,11,13,15,plane).
  >phecom [pdbfile] -pl M  -nrl 13 
    --> Rlarge = (3,4,5,6,7,8,9,10,11,12,13,14,15,plane).
  >phecom [pdbfile] -pl M  -nrl 15 
    --> Rlarge = (3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,plane).


(3) Calculate Rinaccess for the ligand atoms

  This option is usefull to characterize depth of binding ligands.

  >phecom [pdbfile] -ilg [ligand_pdb_file] -olg [output_ligand_pdb_file] -pl M

  Only HETATM lines in the [ligand_pdb_file] are taken as 'ligand' atoms.
  The format of [output_ligand_pdb_file] is same as that of [*.mpdb] file.


----------------------------------------------------------------------

[III] All the options of phecom program

>>phecom : Probe-based HECOMi(pocket) finder <<
   coded by Takeshi Kawabata. LastModified:Oct 21, 2007
 A pocket region is defined as:
  'a space into which a small probe can enter, but a large probe cannot'.
phecom [pdbfile] <options>
<options>
 -help, -h : Show this detailed help
** Input protein PDB file **
 -het : Read HETATM ('T' or 'F') [F]
 -ch  : Chain Identifyer [-]
 -rf  : VdW Radius File []
 -ha : Change HETATM to ATOM for res with(N,CA,C,O) (TF) [T]
** Generating small probes **
 -ps  : Type of Small Probe Generation
      : 'I'cosahedron '3'-contact '2'-contact 'X':3-con-fast 'S'pheHull[S]
 -rs  : Radius of Small Probe [1.870000]
 -is  : Input small probes PDB file[]
 -isl : Input ligand PDB file as small probes[]
 -rsl : Radius of input ligand PDB file -1:CPK radius -2:Occup radius [1.870000]
** Generating large probes **
 -pl  : Type of Large Probe Generation
      : 'I'cosa '3'-con '2'-con 'X':3-con-fast 'P'lane 'S'pheHull
      : 'M'ultiple-size probes 'm':write multiple size probes [S]
 -rl  : Radius of Large Probe [6.000000]
 -il  : Input large probes PDB file[]
 -ilm : Input Multiple large probes PDB file[]
** Output result files **
 -op  : Output Pocket Probe PDB File (probe and protein atoms) [*.ppdb]
 -opo : Output Pocket Probe PDB File (only probes) []
 -or  : Output Pocket Residue Volume File [*.res]
 -oR  : Output Pocket Residue Raccess File [*.rac]
 -oc  : Output Pocket Probe Cluster PDB File []
 -osw : Output Pocket surface VRML(*.wrl) File []
 -osp : Output Pocket surface PDB  File []
 -ops : Output Small Probe PDB File []
 -ots : Output Small Probe tangent point PDB File []
 -ons : Output Small Probe normal vector PDB File []
 -opl : Output Large Probe PDB File []
 -otl : Output Large Probe tangent point PDB File []
 -onl : Output Large normal vector PDB File []
 -oso : Output Sorted PDB  File []
** Other parameters for pocket detection **
 -mc  : Delete probe clusters with Mprobe <= mc [0.000000]
 -V   : Volume Calculation ('T' or 'F') [T]
 -C   : Clustering of Probes ('T' or 'F') [T]
 -Ca  : Clustering of Atoms for checking 'island' of proteins ('T' or 'F') [F]
 -c3  : Assign Probe Atom Name such as 'CCC','OCC' ('T' or 'F')[T]
 -S   : Sub Type[-]
 -so  : Atom Sorting before probing 'G'ravity 'A'tom_gravity 'h'ybrid1 'H'ybrid2 'N'ot_sort[h]
 -cc  : Check Crash just 'c'heck,'d'etele crashed probes [d]
 -gc  : grid_size for collision check [0.800000]
 -gv  : grid_size for MarCube volume calculation [0.800000]
 -rgb: RGBcolor (R G B Trans)[0.0 1.0 0.0 0.0]
 -nrl : Number of trying Rlarge for '-pl M' option.  [13]
