#!/usr/bin/perl

$LastModDate = "Oct 15, 2006";

if (scalar(@ARGV)<1)
{
 print "mkhist_op.pl [op_file by lig-prb]\n";
 exit(1);
}

$fname = $ARGV[0];

#<< EXAMPLE OF FILE FORMAT >>
# PROBE_INFORMATION
# #[AtomNum] [C3Atm] [C3Res] [Rsurvive] [Novatom]|OvResNum1 OvAtmNum1 Ov1|OvResNum2 OvAtmNum2 Ov2|...
#     1 OCC DDD  19.0   0
#     2 OCc DDD  19.0   0
#     3 OCO DDD  19.0   0
#     4 OOC DDD  19.0   0
#     5 Oco DDE  19.0   0
#     6 OoC DEE  19.0   0
#     :
#   629 OCO YKD  19.0   0
#   630 OON EEN  19.0   0
#   631 OCO EEE  19.0   0
#   632 OCC EEE  19.0   0
#   633 OCC EME   9.0   6|1   842 81|1   841 79|1   840 50|1   843 37|1   839 19|1   835  4
#   634 ONC ENN  17.0   2|1   838 48|1   836  7
#   635 OCC ENE   8.0   4|1   838 60|1   836 20|1   835  4|1   839  1
# 

open(F,$fname) || die "#ERROR:Can't open '$fname'";
$readon = 0;
while (<F>)
{
 chomp;
 if ($_!~/^#/)
 {
 if (/^LIGAND\_INFORMATION/) {$readon = 0;}
 if (/^LIGAND\_ATOM\_INFORMATION/) {$readon = 0;}
 if ($readon==1)
 {
  $_=~s/^\s+//;
  ($head,$tail) = split(/\|/,$_); 
  ($AtomNum,$C3Atm,$C3Res,$Rsurvive,$Novatom) = split(/\s+/,$head); 
  #print "$_\n";
  #print "Rsurvive $Rsurvive Novatom $Novatom\n"; 
  $Nrsur{$Rsurvive} += 1; 
  if ($Novatom>0) {$Nrsur_lig{$Rsurvive} += 1; }
 }
 if (/^PROBE\_INFORMATION/) {$readon = 1;}
 }
}

close(F);
@rsurlist = keys(%Nrsur);
@srsurlist = sort {$a <=> $b} @rsurlist;
foreach $r (@srsurlist)
{
 printf("%s %d %d\n",$r,$Nrsur{$r},$Nrsur_lig{$r});
}
