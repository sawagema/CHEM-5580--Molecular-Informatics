/*

 <phecom.c>

 for finding Probe and Pockets in PDB structure.

 coded by Takeshi Kawabata (takawaba@is.naist.jp)

 Algorithm is described in 

 Kawabata T, Go N. "Detection of pockets on protein surfaces 
  using small and large probe spheres to find putative ligand binding sites". 
   Proteins, 68, 516-529, (2007). 

 Algorithm is inspired by:

 G. Patrick Brady Jr. & Peter F.W.Stouten
 "Fast prediction and visualization of protein binding pockets
  with PASS"

   Journal of Computer-aided Molecular Design, vol.14, 383-401, 2000

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <math.h>
#include "pdbstruct.h"
#include "PdbIO.h"
#include "Radius.h"
#include "Voxel.h"
#include "MCubeFunc.h"
#include "mc_verface.h"
#include "SphePnt3.h"
#include "SpheIcosa.h"
#include "Amino.h"
#include "ColCheck.h"
#include "EachVol.h"
#include "Overlap.h"
#include "Cluster.h"
#include "ResMergeSort.h"
#include "AtmMergeSort.h"
#include "DifSpCnvHul.h"
#include "SpheHull.h"
#include "SortAtom.h"
#include "NeiNvec.h"
#include "MulRlarge.h"

static char LastModDate[] = "July 31, 2009";

struct PARAMETERS PAR;

/*** Functions (LOCAL) ***/
static void MAKE_PROBE_SPHERES();

main(argc,argv)
 int argc;
 char **argv;
{
 int   i,j,k,L,N; 
 char  ipdbfile[128],oswrlfile[128],corename[128];
 char  oprobfile[128],ospdbfile[128],oresfile[128],oracfile[128],oclusfile[128],oprobonlyfile[128];
 char  iprobfileS[128],iprobfileSlig[128],iprobfileL[128],iprobfileLmul[128];
 char  oprobfileS[128],otpntfileS[128],onvecfileS[128];
 char  oprobfileL[128],otpntfileL[128],onvecfileL[128],osortpdbfile[128];
 struct ATOM     HeadAtom;
 struct RESIDUE  HeadResidue,HeadClusterAtom,HeadClusterS; 
 struct RADIUS   HeadRadius; 
 struct MC_VERTEX   MC_Vhead; /* For Marching Cube */
 struct MC_FACE     MC_Fhead; /* For Marching Cube */
 struct SH_FACE     SH_FheadS; /* For Sphere Hull for small probes  */
 struct SH_FACE     SH_FheadL; /* For Sphere Hull for large probes  */
 struct ATOM *an,*bn;
 struct RADIUS *rn;
 struct RESIDUE *gn; 
 struct VOXEL Vox;
 struct MATRIX Dmat;
 struct ATOM HeadProbeS; /* Small Probe Spheres */
 struct ATOM HeadProbeL; /* Large Probe Spheres */
 int Natom,Nprobe,NprobeS, NprobeL,NRlarge; 
 char buff[256],PotenType,ChainID;
 float Rall,RprobeS,RprobeL,R,G,B,T,ExpParam,Threshold,RprobeSlig;
 char ProbeTypeS, ProbeTypeL, Con3AtomType; 
 char chainA,chainB,VolType,ClusType,ClusAtomType,SortAtomType,ChkCrashType; 
 float Vprobe,Mprobe_min;
 char  comment[256];
 int   NrecurS, NrecurL,Ncluster;

 /*** Initialize to the default parameters ***/
 ipdbfile[0] = '\0';  
 PAR.radfile[0] = '\0';
 PAR.HETtype = 'F';
 PAR.Het2Atm = 'T';
 PAR.SubType = '-';
 PAR.Lcrash_permit = 0.0001;
 PAR.eps = 0.000000001;
 oswrlfile[0] = ospdbfile[0] = oresfile[0] = oracfile[0] = '\0';
 oprobfile[0]  = oprobonlyfile[0] = oclusfile[0] = '\0';
 oprobfileS[0] = otpntfileS[0] = onvecfileS[0] = '\0';
 oprobfileL[0] = otpntfileL[0] = onvecfileL[0] = osortpdbfile[0] = '\0';
 iprobfileS[0] = iprobfileSlig[0] = iprobfileL[0] = iprobfileLmul[0] = '\0'; 
 R = 0.0; G = 1.0; B = 0.0; T = 0.0;
 PotenType = 'N';
 ExpParam = 0.1;
 ChainID = '-';
 Set_AAnum();
 Rall = 2.5;
 RprobeS = 1.87;  RprobeSlig = 1.87;
 chainA = chainB = '-';
 PAR.REGION = 'F';
 RprobeL = 6.0;
 NrecurS = 2; NrecurL = 2; 
 ProbeTypeS = 'S'; ProbeTypeL = 'S';
 VolType = 'T'; ClusType = 'T'; ClusAtomType = 'F';
 PAR.cvox_grid = 0.8;
 PAR.vvox_grid = 0.8;
 Mprobe_min = 0.0;
 HeadResidue.next = NULL; HeadClusterS.next = NULL;
 Con3AtomType = 'T';
 SortAtomType = 'h';
 ChkCrashType = 'd';
 PAR.Vtype = 'F';
 NRlarge = 13;

 if ((argc>=2)&& ((strcmp(argv[1],"-help")==0)||(strcmp(argv[1],"-h")==0))){
  /** Detailed Help **/
  printf(">>phecom : Probe-based HECOMi(pocket) finder <<\n");
  printf("   coded by Takeshi Kawabata. LastModified:%s\n",LastModDate);
  printf(" A pocket region is defined as:\n");
  printf("  'a space into which a small probe can enter, but a large probe cannot'.\n");
  printf("phecom [pdbfile] <options>\n");
  printf("<options>\n"); 
  printf(" -help, -h : Show this detailed help\n");
  printf("** Input protein PDB file **\n");  
  printf(" -het : Read HETATM ('T' or 'F') [%c]\n",PAR.HETtype);
  printf(" -ch  : Chain Identifyer [%c]\n",ChainID);
  printf(" -rf  : VdW Radius File [%s]\n",PAR.radfile);
  printf(" -ha : Change HETATM to ATOM for res with(N,CA,C,O) (TF) [%c]\n",PAR.Het2Atm);
  printf("** Generating small probes **\n");  
  printf(" -ps  : Type of Small Probe Generation\n"); 
  printf("      : 'I'cosahedron '3'-contact '2'-contact 'X':3-con-fast 'S'pheHull[%c]\n",ProbeTypeS); 
  printf(" -rs  : Radius of Small Probe [%f]\n",RprobeS);
  printf(" -is  : Input small probes PDB file[%s]\n",iprobfileS);
  printf(" -isl : Input ligand PDB file as small probes[%s]\n",iprobfileSlig);
  printf(" -rsl : Radius of input ligand PDB file -1:CPK radius -2:Occup radius [%f]\n",RprobeSlig);
  printf("** Generating large probes **\n");  
  printf(" -pl  : Type of Large Probe Generation\n"); 
  printf("      : 'I'cosa '3'-con '2'-con 'X':3-con-fast 'P'lane 'S'pheHull\n");
  printf("      : 'M'ultiple-size probes 'm':write multiple size probes [%c]\n", ProbeTypeL); 
  printf(" -rl  : Radius of Large Probe [%f]\n",RprobeL);
  printf(" -il  : Input large probes PDB file[%s]\n",iprobfileL);
  printf(" -ilm : Input Multiple large probes PDB file[%s]\n",iprobfileLmul);
  printf("** Output result files **\n");  
  printf(" -op  : Output Pocket Probe PDB File (probe and protein atoms) [*.ppdb]\n");
  printf(" -opo : Output Pocket Probe PDB File (only probes) [%s]\n",oprobonlyfile);
  printf(" -or  : Output Pocket Residue Volume File [*.res]\n");
  printf(" -oR  : Output Pocket Residue Raccess File [*.rac]\n");
  printf(" -oc  : Output Pocket Probe Cluster PDB File [%s]\n",oclusfile);
  /* printf(" -oc  : Output Pocket Probe Cluster PDB File [*.cpdb]\n"); */
  printf(" -osw : Output Pocket surface VRML(*.wrl) File [%s]\n",oswrlfile);
  printf(" -osp : Output Pocket surface PDB  File [%s]\n",ospdbfile);
  printf(" -ops : Output Small Probe PDB File [%s]\n",oprobfileS);
  printf(" -ots : Output Small Probe tangent point PDB File [%s]\n",otpntfileS);
  printf(" -ons : Output Small Probe normal vector PDB File [%s]\n",onvecfileS);
  printf(" -opl : Output Large Probe PDB File [%s]\n",oprobfileL);
  printf(" -otl : Output Large Probe tangent point PDB File [%s]\n",otpntfileL);
  printf(" -onl : Output Large normal vector PDB File [%s]\n",onvecfileL);
  printf(" -oso : Output Sorted PDB  File [%s]\n",osortpdbfile);
  printf("** Other parameters for pocket detection **\n");  
  printf(" -mc  : Delete probe clusters with Mprobe <= mc [%f]\n",Mprobe_min);
  printf(" -V   : Volume Calculation ('T' or 'F') [%c]\n",VolType);
  printf(" -C   : Clustering of Probes ('T' or 'F') [%c]\n",ClusType);
  printf(" -Ca  : Clustering of Atoms for checking 'island' of proteins ('T' or 'F') [%c]\n",ClusAtomType);
  printf(" -c3  : Assign Probe Atom Name such as 'CCC','OCC' ('T' or 'F')[%c]\n",Con3AtomType);
  printf(" -S   : Sub Type[%c]\n",PAR.SubType);
  printf(" -so  : Atom Sorting before probing 'G'ravity 'A'tom_gravity 'h'ybrid1 'H'ybrid2 'N'ot_sort[%c]\n",SortAtomType); 
  printf(" -cc  : Check Crash just 'c'heck,'d'etele crashed probes [%c]\n",ChkCrashType); 
  printf(" -gc  : grid_size for collision check [%f]\n",PAR.cvox_grid);
  printf(" -gv  : grid_size for MarCube volume calculation [%f]\n",PAR.vvox_grid);
  printf(" -rgb: RGBcolor (R G B Trans)[%.1f %.1f %.1f %.1f]\n",R,G,B,T);
  printf(" -nrl : Number of trying Rlarge for '-pl M' option.  [%d]\n",NRlarge);
  printf("        '8':3,4,..,10,  '9':3,4,..,11, '13':3,4,...,15 (angstrom)\n");
  exit(1);
 }

 else if (argc<2){
  /* Simple Help */
  printf(">>phecom : Probe-based HECOMi(pocket) finder <<\n");
  printf("   coded by Takeshi Kawabata. LastModified:%s\n",LastModDate);
  printf(" A pocket region is defined as:\n");
  printf("  'a space into which a small probe can enter, but a large probe cannot'.\n");
  printf("phecom [pdbfile] <options>\n");
  printf(" An option \"-help\" shows a detailed information about the options.\n");
  printf(" -ch  : Chain Identifyer [%c]\n",ChainID);
  printf(" -rs  : Radius of Small Probe [%f]\n",RprobeS);
  printf(" -rl  : Radius of Large Probe [%f]\n",RprobeL);
  printf(" -pl  : Type of Large Probe Generation\n"); 
  printf("      : 'I'cosa '3'-con '2'-con 'X':3-con-fast 'P'lane 'S'pheHull 'M'ultiple[%c]\n", ProbeTypeL); 
  exit(1);
 }

  /****** READ ARGUMENTS ***********/
 PAR.COMMAND[0] = '\0';
 for (k=0;k<argc;++k)  
 { if (k>0) strcat(PAR.COMMAND," ");
   strcat(PAR.COMMAND,argv[k]);   }

 sprintf(ipdbfile,"%s",argv[1]);
 k = 2;
 while (k<argc){
    if (argv[k][0]=='-'){
      L = strlen(argv[k]);
           if ((L==3)&&(argv[k][1]=='r')&&(argv[k][2]=='s')) {++k; RprobeS  = atof(argv[k]);}
      else if ((L==4)&&(argv[k][1]=='r')&&(argv[k][2]=='s')&&(argv[k][3]=='l')) {++k; RprobeSlig  = atof(argv[k]);}
      else if ((L==3)&&(argv[k][1]=='r')&&(argv[k][2]=='l')) {++k; RprobeL = atof(argv[k]);}
      else if ((L==3)&&(argv[k][1]=='p')&&(argv[k][2]=='s')) {++k; ProbeTypeS  = argv[k][0];}
      else if ((L==3)&&(argv[k][1]=='p')&&(argv[k][2]=='l')) {++k; ProbeTypeL  = argv[k][0];}
      else if ((L==3)&&(argv[k][1]=='g')&&(argv[k][2]=='c')) {++k; PAR.cvox_grid = atof(argv[k]);}
      else if ((L==3)&&(argv[k][1]=='g')&&(argv[k][2]=='v')) {++k; PAR.vvox_grid = atof(argv[k]);}
      else if ((L==3)&&(argv[k][1]=='r')&&(argv[k][2]=='f')) {++k; sprintf(PAR.radfile,"%s",argv[k]);}
      else if ((L==3)&&(argv[k][1]=='c')&&(argv[k][2]=='h')) {++k; ChainID = argv[k][0];}
      else if ((L==3)&&(argv[k][1]=='o')&&(argv[k][2]=='p')) 
                                    {++k; sprintf(oprobfile,"%s",argv[k]);}
      else if ((L==4)&&(argv[k][1]=='o')&&(argv[k][2]=='p')&&(argv[k][3]=='o')) 
                                    {++k; sprintf(oprobonlyfile,"%s",argv[k]);}
      else if ((L==4)&&(argv[k][1]=='o')&&(argv[k][2]=='s')&&(argv[k][3]=='p')) 
                                                      {++k; sprintf(ospdbfile,"%s",argv[k]);}
      else if ((L==4)&&(argv[k][1]=='o')&&(argv[k][2]=='s')&&(argv[k][3]=='w')) 
                                                      {++k; sprintf(oswrlfile,"%s",argv[k]);}
     
      else if ((L==4)&&(argv[k][1]=='o')&&(argv[k][2]=='p')&&(argv[k][3]=='s')) 
                                                      {++k; sprintf(oprobfileS,"%s",argv[k]);}
      else if ((L==4)&&(argv[k][1]=='o')&&(argv[k][2]=='t')&&(argv[k][3]=='s')) 
                                                      {++k; sprintf(otpntfileS,"%s",argv[k]);}
      else if ((L==4)&&(argv[k][1]=='o')&&(argv[k][2]=='n')&&(argv[k][3]=='s')) 
                                                      {++k; sprintf(onvecfileS,"%s",argv[k]);}
      else if ((L==4)&&(argv[k][1]=='o')&&(argv[k][2]=='p')&&(argv[k][3]=='l')) 
                                                      {++k; sprintf(oprobfileL,"%s",argv[k]);}
      else if ((L==4)&&(argv[k][1]=='o')&&(argv[k][2]=='t')&&(argv[k][3]=='l')) 
                                                      {++k; sprintf(otpntfileL,"%s",argv[k]);}
      else if ((L==4)&&(argv[k][1]=='o')&&(argv[k][2]=='n')&&(argv[k][3]=='l')) 
                                                      {++k; sprintf(onvecfileL,"%s",argv[k]);}

      else if ((L==4)&&(argv[k][1]=='o')&&(argv[k][2]=='s')&&(argv[k][3]=='o')) 
                                                      {++k; sprintf(osortpdbfile,"%s",argv[k]);}

      else if ((L==3)&&(argv[k][1]=='o')&&(argv[k][2]=='r')) {++k; sprintf(oresfile,"%s",argv[k]);}
      else if ((L==3)&&(argv[k][1]=='o')&&(argv[k][2]=='R')) {++k; sprintf(oracfile,"%s",argv[k]);}
      else if ((L==3)&&(argv[k][1]=='o')&&(argv[k][2]=='c')) {++k; sprintf(oclusfile,"%s",argv[k]);}
      else if ((L==4)&&(argv[k][1]=='i')&&(argv[k][2]=='s')&&(argv[k][3]=='l')) 
              {++k; sprintf(iprobfileSlig,"%s",argv[k]);}
      else if ((L==3)&&(argv[k][1]=='i')&&(argv[k][2]=='s')) {++k; sprintf(iprobfileS,"%s",argv[k]);}
      else if ((L==3)&&(argv[k][1]=='i')&&(argv[k][2]=='l')) {++k; sprintf(iprobfileL,"%s",argv[k]);}
      else if ((L==4)&&(argv[k][1]=='i')&&(argv[k][2]=='l')&&(argv[k][3]=='m')) 
                                                      {++k; sprintf(iprobfileLmul,"%s",argv[k]);}
      else if ((L==3)&&(argv[k][1]=='s')&&(argv[k][2]=='p')) {++k; PAR.SpType = argv[k][0];}
      else if ((L==3)&&(argv[k][1]=='s')&&(argv[k][2]=='m')) {++k; PAR.SumType = argv[k][0];}
      else if ((L==3)&&(argv[k][1]=='c')&&(argv[k][2]=='A')) {++k; chainA = argv[k][0];}
      else if ((L==3)&&(argv[k][1]=='c')&&(argv[k][2]=='B')) {++k; chainB = argv[k][0];}
      else if ((L==3)&&(argv[k][1]=='c')&&(argv[k][2]=='3')) {++k; Con3AtomType = argv[k][0];}
      else if ((L==3)&&(argv[k][1]=='s')&&(argv[k][2]=='o')) {++k; SortAtomType = argv[k][0];}
      else if ((L==3)&&(argv[k][1]=='c')&&(argv[k][2]=='c')) {++k; ChkCrashType = argv[k][0];}
      else if ((L==4)&&(argv[k][1]=='h')&&(argv[k][2]=='e')&&(argv[k][3]=='t')) {++k; PAR.HETtype = argv[k][0]; }
      else if ((L==3)&&(argv[k][1]=='h')&&(argv[k][2]=='a')) {++k; PAR.Het2Atm = argv[k][0]; }
      else if ((L==2)&&(argv[k][1]=='C')) {++k; ClusType = argv[k][0]; }
      else if ((L==3)&&(argv[k][1]=='C')&&(argv[k][2]=='a')) {++k; ClusAtomType = argv[k][0]; }
      else if ((L==2)&&(argv[k][1]=='P')) {++k; PotenType = argv[k][0]; }
      else if ((L==2)&&(argv[k][1]=='V')) {++k; VolType = argv[k][0]; }
      else if ((L==2)&&(argv[k][1]=='S')) {++k; PAR.SubType = argv[k][0]; }
      else if ((L==2)&&(argv[k][1]=='v')) {++k; PAR.Vtype = argv[k][0]; }
      else if ((L==3)&&(argv[k][1]=='m')&&(argv[k][2]=='c')) {++k; Mprobe_min = atof(argv[k]);}
      else if ((L==3)&&(argv[k][1]=='e')&&(argv[k][2]=='p')) {++k; ExpParam = atof(argv[k]);}
      else if ((L==3)&&(argv[k][1]=='r')&&(argv[k][2]=='a')) {++k; Rall = atof(argv[k]);}
      else if ((L==3)&&(argv[k][1]=='n')&&(argv[k][2]=='s')) {++k; NrecurS = atoi(argv[k]);}
      else if ((L==3)&&(argv[k][1]=='n')&&(argv[k][2]=='l')) {++k; NrecurL = atoi(argv[k]);}
      else if ((L==4)&&(argv[k][1]=='n')&&(argv[k][2]=='r')&&(argv[k][3]=='l')) {++k; NRlarge = atoi(argv[k]);}
      else if ((argv[k][1]=='r')&&(argv[k][2]=='g') &&(argv[k][3]=='b')&&((k+4)<argc))
       { R = atof(argv[k+1]);
         G = atof(argv[k+2]);
         B = atof(argv[k+3]);
         T = atof(argv[k+4]);
         k += 4; }

     else { printf("#ERROR:Can't understand option \"%s\"\n",argv[k]); exit(1);}

    } /* if '-' */

    ++k;

  } /* while k */


  printf("oprobonlyfile1 '%s'\n",oprobonlyfile);
  /**************************/
  /*** [1] READING FILES  ***/
  /**************************/
  printf("#*** [1] READING FILES  ***#\n");
  /** Procedures for Radius **/ 
  if (PAR.radfile[0] != '\0') Read_Radius_File(PAR.radfile,&HeadRadius);
  else Set_Default_Radius(&HeadRadius);

  /** Managing PDB File name **/ 
  Find_Filename_Core(corename,ipdbfile);
  if (ChainID!='-') 
   { sprintf(buff,"%s",corename); 
     sprintf(corename,"%s%c",buff,ChainID); }

       if (oresfile[0] == '\0') sprintf(oresfile,"%s.res",corename); 
  else if (oresfile[0] == '-') oresfile[0] = '\n';

       if (oprobfile[0] == '\0') 
  { sprintf(oprobfile,"%s.ppdb",corename); 
    if (ProbeTypeL == 'M')  sprintf(oprobfile,"%s.mpdb",corename); }
  
  else if (oprobfile[0] == '-')  oprobfile[0] = '\0';

 /*
       if (oclusfile[0] == '\0') sprintf(oclusfile,"%s.cpdb",corename); 
  else if (oclusfile[0] == '-')  oclusfile[0] = '\n';
 */
 
       if (oracfile[0] == '\0') sprintf(oracfile,"%s.rac",corename); 
  else if (oracfile[0] == '-')  oracfile[0] = '\n';

  Read_PDB_File(ipdbfile,&HeadAtom,PAR.HETtype,ChainID);
  Assign_Radius(&HeadAtom,&HeadRadius);
  Natom = Number_Of_Atom(&HeadAtom);
  printf("Natom %d\n",Natom); 
  if (Natom==0)
  { printf("#ERROR:PDBfile \"%s\" does not contain any atom.\n",ipdbfile);
    exit(1); }


  /* For Checking "isolated islands" of protein structure */
  if (ClusAtomType == 'T'){
   Make_Cluster_Of_Atoms(&HeadAtom,&HeadClusterAtom,RprobeS);
   printf("CLUSTER %s %c Ncluster %d",ipdbfile,ChainID,Number_Of_Residue(&HeadClusterAtom));
   gn = &HeadClusterAtom;
   while (gn->next != NULL) 
   { gn = gn->next; printf(" [%d] %d",gn->num,gn->Natom);}
   printf("\n");
   exit(1); 
  } 

  Make_Residue_List(&HeadAtom,&HeadResidue);
  Malloc_MATRIX(&Dmat,Natom);
  Cal_Distance_MATRIX(&HeadAtom,&Dmat);
 
  /** Sorting PDB Atoms **/
  if (SortAtomType == 'G') Sort_Atom_Order_From_Gravity_Center(&HeadAtom); 

  if (SortAtomType == 'A') Sort_Atom_Order_From_Gravity_Center_Atom(&HeadAtom); 
  
  if (SortAtomType == 'C') Sort_Atom_Order_From_Gravity_Center_Atom_MinDis(&HeadAtom,&Dmat);

  if (SortAtomType == 'H')
  { Sort_Atom_Order_From_Gravity_Center_Atom(&HeadAtom);  
    Resort_Distance_Isolated_Atoms_After_The_Closest(&HeadAtom,&Dmat,RprobeS); }
  
  if (SortAtomType == 'h')
  { Sort_Atom_Order_From_Gravity_Center_Atom(&HeadAtom);  
    Resort_Distance_Isolated_Atoms_To_The_End(&HeadAtom,&Dmat,RprobeS); 
  }

   if (osortpdbfile[0] != '\0')
    Write_PDB_File(osortpdbfile,&HeadAtom,'w',"SORTED PDBFILE",PAR.COMMAND); 

  /* 
   Check_Distance_Jump_Between_Previous_Atoms(&HeadAtom,"djump.out",RprobeS);
  */

  /**************************************/
  /*** [2] Making Small Probe Spheres ***/
  /**************************************/
  printf("#*** [2] Making Small Probe Spheres ***#\n");
  if (iprobfileS[0] != '\0')
    Read_PDB_File_Probes(iprobfileS,&HeadProbeS,RprobeS,&HeadAtom); 
  else if (iprobfileSlig[0] != '\0'){
   Read_PDB_File(iprobfileSlig,&HeadProbeS,'T','-');

         if (RprobeSlig <= -2.0) Assign_Occup_Radius(&HeadProbeS,&HeadRadius);
   else  if (RprobeSlig <= -1.0) Assign_Radius(&HeadProbeS,&HeadRadius);
   else Assign_Unified_Radius(&HeadProbeS,RprobeSlig);

   Set_Pseudo_Three_Contacting_Atoms_To_Probes(&HeadProbeS,&HeadAtom);
   Con3AtomType = 'F';
   ChkCrashType = 'F';
   if (ProbeTypeL != 'M') Delete_Probes_DoNot_Contact_Protein(&HeadProbeS);
  }
  else MAKE_PROBE_SPHERES(ProbeTypeS,&HeadProbeS,&HeadAtom,RprobeS,&Dmat,NrecurS,&SH_FheadS);

  NprobeS = Number_Of_Atom(&HeadProbeS);
  printf("#Number_of_Small_Probes %d\n",NprobeS);
 
  if (Con3AtomType == 'T') Set_AtomName_Of_Probes_By_Contacted_Three_Atoms(&HeadProbeS);
 
  if (otpntfileS[0] != '\0')
    { Write_PDB_File(otpntfileS,&HeadAtom,'w',"COODINATES OF TARGET PROTEIN",PAR.COMMAND);
      Write_Tpnt_Face_PDB_File_SH_FACE(otpntfileS,'a',&SH_FheadS); }
    
  if (onvecfileS[0] != '\0')
    Write_PDB_File_With_Nvec(onvecfileS,&HeadAtom,PAR.COMMAND,RprobeS);

  if ((ChkCrashType=='c')||(ChkCrashType=='d')) 
    Check_Crash_Bwn_Chains(&HeadAtom, &HeadProbeS,ChkCrashType);
   
  if (oprobfileS[0] != '\0')
    Write_PDB_File_Probes(oprobfileS,&HeadProbeS,'w',comment,PAR.COMMAND);
 
   Cal_Each_Residue_Nprobe_surf(&HeadResidue,&HeadAtom,&HeadProbeS);


  /**************************************/ 
  /*** [3] Making Large Probe Spheres ***/
  /**************************************/ 
  printf("#*** [3] Making Large Probe Spheres ***#\n");
  if (RprobeL>0.0){
   printf("#Making Large Probe Spheres\n");
   if (iprobfileL[0] != '\0')
    Read_PDB_File_Probes(iprobfileL,&HeadProbeL,RprobeL,&HeadAtom); 
   else if (ProbeTypeL == 'P'){
    Initial_Double_Triangle_DifSp(&HeadAtom,&SH_FheadL);
    ConstructHull_DifSp(&HeadAtom,&SH_FheadL);
   }
   else if (ProbeTypeL == 'M'){ 
     if (iprobfileLmul[0] != '\0')
      Try_Multiple_Large_Spheres_From_File(iprobfileLmul,
               NRlarge,&HeadAtom,&HeadResidue,&HeadProbeS,&Dmat,RprobeS,oprobfile,oracfile);
     else 
      Try_Multiple_Large_Spheres(NRlarge,&HeadAtom,&HeadResidue,&HeadProbeS,&Dmat,RprobeS,oprobfile,oprobonlyfile,oracfile);
     } 
   else if (ProbeTypeL == 'm'){ 
    if (oprobfileL[0]=='\0') sprintf(oprobfileL,"%s.apdb",corename); 
    Generate_Multiple_Large_Spheres(oprobfileL,NRlarge,&HeadAtom,&HeadResidue,&Dmat);
   }
   else MAKE_PROBE_SPHERES(ProbeTypeL,&HeadProbeL,&HeadAtom,RprobeL,&Dmat,NrecurL,&SH_FheadL);

   if (ProbeTypeL != 'P'){ 
    if ((ChkCrashType=='c')||(ChkCrashType=='d')) 
     Check_Crash_Bwn_Chains(&HeadAtom, &HeadProbeL,ChkCrashType);
    Assign_ChainID(&HeadProbeL,'L'); 
    Remove_Crashed_Atom(&HeadProbeS,&HeadProbeL);
   }
   else if (ProbeTypeL == 'P')
    Remove_Atoms_Crashed_With_Planes(&HeadProbeS,&SH_FheadL); 
  
  if (otpntfileL[0] != '\0')
    { Write_PDB_File(otpntfileL,&HeadAtom,'w',"COODINATES OF TARGET PROTEIN",PAR.COMMAND);
      Write_Tpnt_Face_PDB_File_SH_FACE(otpntfileL,'a',&SH_FheadL); }
    
  if (onvecfileL[0] != '\0')
    Write_PDB_File_With_Nvec(onvecfileL,&HeadAtom,PAR.COMMAND,RprobeL);
  
  if (oprobfileL[0] != '\0'){
    if (ProbeTypeL == 'P')
     Write_PDB_File_Planes(oprobfileL,&SH_FheadL,'w',comment,PAR.COMMAND);
    else
     Write_PDB_File_Probes(oprobfileL,&HeadProbeL,'w',comment,PAR.COMMAND);
  }
 }

 
 Renumber_Atom_Number(&HeadProbeS);
 Assign_ChainID(&HeadProbeS,'P'); 
 Nprobe = Number_Of_Atom(&HeadProbeS);

  printf("oprobonlyfile2 '%s'\n",oprobonlyfile);

 /*************************/
 /* [4] Clustering Probes */
 /*************************/
 Ncluster = 0;
 
 if (ClusType=='T'){
   printf("#*** [4] Clustering Probes ***#\n");
   Make_Cluster_Of_Atoms(&HeadProbeS,&HeadClusterS,0.0);
   Cal_Volume_Of_Residues(&HeadProbeS,&HeadClusterS);
   if (Mprobe_min > 0.0) Remove_Small_Clusters(&HeadProbeS,&HeadClusterS,Mprobe_min);
   Vprobe = All_Volume_Of_Residues(&HeadClusterS);
   printf("#Vprobe_residue %f\n",Vprobe);
   gn = &HeadClusterS;
   Merge_Sort_Double_Linked_List_RESIDUE(&HeadClusterS,'R');
   Reorder_Atom_By_Residue(&HeadProbeS,&HeadClusterS);
   Renumber_Residue_Number(&HeadClusterS);
   Renumber_Atom_Number(&HeadProbeS); 
   /* Output_Residues_Atoms(&HeadClusterS); */
   Assign_Contact_Cluster_For_Each_Residue(&HeadAtom,&HeadResidue,&HeadClusterS);
   /* Write_PDB_File_Residue("rprb.pdb",&HeadClusterS,'w',"",PAR.COMMAND); */
   Ncluster = Number_Of_Residue(&HeadClusterS);
   
   if (oclusfile[0] != '\0') 
    Write_Contact_Atoms_For_Each_Cluster(oclusfile,&HeadAtom,&HeadClusterS,PAR.COMMAND); 
  } 


 /**************************************************/
 /* [5] Volume Calculation for each atom / residue */
 /**************************************************/
  
 if (VolType == 'T'){ 
   printf("#* [5] Volume Calculation for each atom / residue *\n");
   Cal_Each_Atom_Probe_Volume(&HeadAtom,&HeadProbeS);
   Cal_Each_Residue_Probe_Volume(&HeadResidue,&HeadAtom,&HeadProbeS);
  }


 /*******************/
 /*** [6] OUTPUT ****/
 /*******************/
 
 printf("#*** [6] OUTPUT ****#\n");
  printf("oprobonlyfile3 '%s'\n",oprobonlyfile);

 if ((SortAtomType != 'N')&&(SortAtomType != '-')) Recover_Atom_Order_By_Atom_Number(&HeadAtom);

 if (oprobfile[0] != '\0') 
  Write_PDB_File(oprobfile,&HeadAtom,'w',"COODINATES OF TARGET PROTEIN",PAR.COMMAND);
 
 if (oresfile[0] != '\n') 
  {  Write_Residue_File(oresfile,&HeadResidue,RprobeS,RprobeL,Nprobe,Ncluster,Vprobe,PAR.COMMAND); }
  
  if (oprobfile[0] != '\0') 
  { sprintf(comment,"POCKET PROBES\nRadiusS %f RadiusL %f\nColumn of tFactor:Mprobe",RprobeS,RprobeL);
    Write_PDB_File_Probes(oprobfile,&HeadProbeS,'a',comment,PAR.COMMAND); 
    printf("#When you display \"%s\" using rasmol, type as follows:\n",oprobfile); 
    printf("# rasmol %s\n#  RasMol>select PRB\n#  RasMol>spacefill %d\n",
             oprobfile,(int)ceil(RprobeS*250.0)); }

   printf("OUTPUT oprobonlyfile '%s'\n",oprobonlyfile);
  if (oprobonlyfile[0] != '\0'){ 
    printf("OUTPUT oprobonlyfile '%s'\n",oprobonlyfile);
    sprintf(comment,"POCKET PROBES\nRadiusS %f RadiusL %f\nColumn of tFactor:Mprobe",RprobeS,RprobeL);
    Write_PDB_File_Probes(oprobonlyfile,&HeadProbeS,'w',comment,PAR.COMMAND); 
    printf("#When you display \"%s\" using rasmol, type as follows:\n",oprobonlyfile); 
    printf("# rasmol %s\n#  RasMol>select PRB\n#  RasMol>spacefill %d\n",
             oprobonlyfile,(int)ceil(RprobeS*250.0)); }



 /**** VRML OUTPUT ***/
 if ((oswrlfile[0] != '\0')||(ospdbfile[0] != '\0'))
 {
  PAR.SpType  = 'S'; PAR.SumType = 'X';
  PAR.Asigmoid = 10.0;
  PAR.Phardsp  = 0.5;


  Vox.gridlen =  PAR.vvox_grid;
  Cal_Size_Of_Voxel_By_Molecule(&HeadProbeS,RprobeS,Vox.gridlen,Vox.min,Vox.N,'F');

  Malloc_Voxel(&Vox,Vox.N[0], Vox.N[1], Vox.N[2]);
  Cal_Density_Of_Molecule(&Vox,&HeadProbeS);
  Marching_Cube(&Vox,&MC_Vhead,&MC_Fhead,0.5,'C');
  if (oswrlfile[0] != '\0') 
   Output_MC_Faces_VRML(oswrlfile,&MC_Vhead,&MC_Fhead,&Vox,R,G,B,T,PAR.COMMAND);
  if (ospdbfile[0] != '\0') Output_MC_Faces_PDB(ospdbfile,&MC_Vhead,&MC_Fhead,&Vox,PAR.COMMAND);
  }

} /* end main() */ 





/*****************/
/*** FUNCTIONS ***/
/*****************/

void MAKE_PROBE_SPHERES(Type,Phead,Ahead,Rprobe,Dmat,Nrecur,SH_Fhead)
 char   Type;
 struct ATOM *Phead,*Ahead;
 float  Rprobe;
 struct MATRIX *Dmat;
 int    Nrecur;
 struct SH_FACE     *SH_Fhead; 
{
 struct ATOM Thead;
 Thead.next = NULL;
 SH_Fhead->next = NULL;

        if (Type == 'I')
    Make_Probe_Spheres_Icosahedron(Phead,Ahead,Rprobe,Nrecur);
   else if (Type == 'C')
    Make_Probe_Spheres_Icosahedron_ColVoxel(Phead,Ahead,Rprobe,Nrecur);
   else if (Type == '3')
     Make_Probe_Spheres_Three_Contact(Phead,Ahead,Rprobe,Dmat);
   else if (Type == 'T')
     Make_Probe_Spheres_Three_Contact_ColVoxel(Phead,Ahead,Rprobe,Dmat);
   else if (Type == 't')
     Make_Probe_Spheres_Three_Contact_PairColVoxel(Phead,Ahead,Rprobe,Dmat);
   else if (Type == 'X')
     Make_Probe_Spheres_Three_Contact_PairColVoxel_Overlap(Phead,Ahead,Rprobe,Dmat);
   else if (Type == 'O')
     Make_Probe_Spheres_Three_Contact_ColVoxel_Overlap(Phead,Ahead,Rprobe,Dmat);
   else if (Type == 'o')
     Make_Probe_Spheres_Three_Contact_Overlap(Phead,Ahead,Rprobe,Dmat);
  else if (Type == '2')
   { Make_Probe_Spheres_Three_Contact(Phead,Ahead,Rprobe,Dmat);
     Make_Probe_One_Probe_Two_Protein(&Thead,Ahead,Rprobe,Dmat);
     Joint_Atom_List(Phead,&Thead);
   }
   else if (Type == 'S')
   {
    Make_NEIGHBOR_ATOM(Ahead,Dmat,Rprobe);
    Initial_Double_Triangle_SpheHull(Ahead,SH_Fhead,Dmat,Rprobe);
    Construct_Sphere_Hull(Ahead,SH_Fhead,Dmat,Rprobe);
    Make_Probe_Atoms_from_SH_FACE(Phead,SH_Fhead);
    Free_NEIGHBOR_ATOM(Ahead);
   }

} /* end of MAKE_PROBE_SPHERES() */

