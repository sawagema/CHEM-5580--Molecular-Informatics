/*

 <ColCheck.c>

 functions for collision check

 coded by Takeshi Kawabata (takawaba@is.naist.jp)

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <math.h>
#include "pdbstruct.h"
#include "PdbIO.h"
#include "Radius.h"
#include "Voxel.h"
#include "MCubeFunc.h"
#include "mc_verface.h"
#include "Amino.h"
#include "ColCheck.h"


/*** Functions (GLOBAL) ***/
void Cal_AtomVoxel_Neighbor();
void Malloc_Col_Voxel();
void Cal_Col_Voxel();
void Free_Col_Voxel();
int  IntXYZ_from_FloatXYZ();

/*** FUNCTION (LOCAL) ***/
static int Add_Atom_to_Neighbor();





void Malloc_Col_Voxel(cvox,x,y,z)
 struct COLVOXEL *cvox;
 int x,y,z;
{
 int i,j;
 double Mbyte;

 Mbyte = (double)x*y*z/1000.0/1000.0;
 printf("#Malloc_Col_Voxel(x %d y %d z %d) --> %.2lf Mbyte\n",x,y,z,Mbyte);

 if (Mbyte > MAX_MEMORY_MEGA)
 { 
  printf("#ERROR:Malloc_Col_Voxel():%.2f Mbyte is larger than MAX (%d Mbyte).\n",
     Mbyte,MAX_MEMORY_MEGA);
  exit(1);
 }  

 
 cvox->map = (unsigned char ***)malloc(sizeof(unsigned char **) * x);

 for (i=0;i<x;++i)
 {
  cvox->map[i] = (unsigned char **)malloc(sizeof(unsigned char *) * y);
  for (j=0;j<y;++j) cvox->map[i][j] = (unsigned char *)malloc(sizeof(unsigned char) * z);
  }

} /* end of Malloc_Col_Voxel() */






void Free_Col_Voxel(cvox,x,y,z)
 struct COLVOXEL *cvox;
 int x,y,z;
{
 int i,j;

 for (i=0;i<x;++i)
 {
  for (j=0;j<y;++j) free(cvox->map[i][j]);
  free(cvox->map[i]);
 }
 free(cvox->map);

} /* end of Free_Col_Voxel() */






void Cal_Col_Voxel(cvox,Ahead,Radd)
 struct COLVOXEL *cvox;
 struct ATOM  *Ahead;
 float  Radd;
{
 int i,j,k,x,y,z;
 struct ATOM *an,*bn;
 int minR[3],maxR[3];
 float Q[3],D[3],DD,d,R,RR;
 float minP[3];  /* Minimum Value for Probe Lattice */
 unsigned char mask[8]; 

 /*
  Each 8 neighbors for a 3D grid 
  corresponds to a following hexadecimal number.
   [-1,-1,-1] : 0 : x01
   [-1,-1, 1] : 1 : x02
   [-1, 1,-1] : 2 : x04
   [-1, 1, 1] : 3 : x08
   [ 1,-1,-1] : 4 : x10
   [ 1,-1, 1] : 5 : x20
   [ 1, 1,-1] : 6 : x40
   [ 1, 1, 1] : 7 : x80
 */

 printf("#Cal_Col_Voxel()\n");
 
 mask[0] = 0x01; mask[1] = 0x02; mask[2] = 0x04; mask[3] = 0x08;
 mask[4] = 0x10; mask[5] = 0x20; mask[6] = 0x40; mask[7] = 0x80;

 /** [1] Initialize **/
 for (x=0;x<cvox->N[0];++x)
  for (y=0;y<cvox->N[1];++y)
   for (z=0;z<cvox->N[2];++z)  cvox->map[x][y][z] = 0;

 for (i=0;i<3;++i) minP[i] = cvox->min[i] - 0.5*cvox->gridlen;


 /** [2] Fill 3D points covered by each atom "an" **/

 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  R   = an->R + Radd;
  RR = R*R;

  /* Cal min-max index for each atom */
  for (i=0;i<3;++i)
  {
   minR[i] = floor((an->Pos[i] - R - minP[i])/cvox->gridlen);
   maxR[i] =  ceil((an->Pos[i] + R - minP[i])/cvox->gridlen);
   if (minR[i] < 1)           minR[i] = 1;
   if (maxR[i] > cvox->N[i])  maxR[i] = cvox->N[i];
   }
 
  /* Fill 3D grids */
  for (x=minR[0];x<=maxR[0];++x)
  {
   Q[0] = minP[0] + cvox->gridlen * x;
   D[0] = Q[0] - an->Pos[0];
   for (y=minR[1];y<=maxR[1];++y)
   {
    Q[1] = minP[1] + cvox->gridlen * y;
    D[1] = Q[1] - an->Pos[1];
    for (z=minR[2];z<=maxR[2];++z)
    {
      Q[2] = minP[2] + cvox->gridlen * z;
      D[2] = Q[2] - an->Pos[2];
      DD = D[0]*D[0] + D[1]*D[1] + D[2]*D[2];
      if (DD <= RR) 
      {
        cvox->map[x][y][z]       |= mask[0]; 
        cvox->map[x][y][z-1]     |= mask[1]; 
        cvox->map[x][y-1][z]     |= mask[2]; 
        cvox->map[x][y-1][z-1]   |= mask[3]; 
        cvox->map[x-1][y][z]     |= mask[4]; 
        cvox->map[x-1][y][z-1]   |= mask[5]; 
        cvox->map[x-1][y-1][z]   |= mask[6]; 
        cvox->map[x-1][y-1][z-1] |= mask[7]; 
       }
     } /* z */
    } /* y */
  } /* x */
 } /* an */

} /* end of Cal_Col_Voxel() */



int IntXYZ_from_FloatXYZ(I,F,cvox)
 int I[3];
 float F[3];
 struct COLVOXEL *cvox;
{
  int i,ival;
  double val,residual;

  for (i=0;i<3;++i)
   { val  = (F[i] - cvox->min[i])/cvox->gridlen; 
     ival = (int)(val);
     residual  = val - ival;
     if (residual>0.5) I[i]  = ival; else I[i] = ival + 1; 

   if ((I[i]<0)||(I[i]>=cvox->N[i])) 
    {printf("#ERROR(Int_from_Float):I[%d] = %d from %f is out of range(0..%d).\n",
      i,I[i],F[i],cvox->N[i]); 
    return(0);
    }
   }

 return(1);

} /* end of IntXYZ_from_FloatXYZ() */

