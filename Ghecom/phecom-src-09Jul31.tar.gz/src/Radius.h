/*

 <Radius.h>

*/

extern void Read_Radius_File();
extern void Set_Default_Radius();
extern void Set_Unified_Radius();
extern void Assign_Radius();
extern void Assign_Unified_Radius();
extern void Assign_Occup_Radius();
