/*

 <ColCheck.h>

*/


/** VOXEL FOR CHECKING COLLISION  **/
struct COLVOXEL{
 int   N[3];         /* Number of grid for 0:X, 1:Y, 2:Z */
 float gridlen;
 float min[3];
 float G[3];
 unsigned char ***map;     /* [0..X-1][0..Y-1][0..Z-1] */
 /*

 map[][][] stores overlap or not for the eight surrounding nodes.
  [-1,-1,-1] : 0 : x01
  [-1,-1, 1] : 1 : x02
  [-1, 1,-1] : 2 : x04
  [-1, 1, 1] : 3 : x08
  [ 1,-1,-1] : 4 : x10
  [ 1,-1, 1] : 5 : x20
  [ 1, 1,-1] : 6 : x40
  [ 1, 1, 1] : 7 : x80
 
 * only if (map[i][j][k]===255), a point (i,j,k) is surrounding the atoms.
 
 */
};


struct NEIGHBOR{ 
 struct ATOM     *atom;
 struct NEIGHBOR *next;
};


/************************/
/** FUNCTIONS (GLOBAL) **/
/************************/

extern void Cal_AtomVoxel_Neighbor();
extern void Collision_Check();
extern void Malloc_Col_Voxel();
extern void Cal_Col_Voxel();
extern void Free_Col_Voxel();
extern int  IntXYZ_from_FloatXYZ();
