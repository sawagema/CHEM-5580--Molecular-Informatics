#!/usr/bin/perl
##
## <PrbOver.pl>
##

$LastModDate = "July 17, 2005";

if (scalar(@ARGV)<1)
{
 print "PrbOver.pl [pdbfile1] [pdbfile2]\n";
 print " coded by T.Kawabata. LastModified:$LastModDate\n";
 print " showing non-common atoms in pdbfile1 and pdbfile2.\n"; 
 exit(1);
}

$fname1 = $ARGV[0];
$fname2 = $ARGV[1];
$permitSc = 10;
&Read_PDB_File($fname1, 'P','A',\%dat1);
&Read_PDB_File($fname2, 'P','A',\%dat2);
printf("#Natom in FILE1 \"%s\" %d\n",$fname1,$dat1{'Natom'});
printf("#Natom in FILE2 \"%s\" %d\n",$fname2,$dat2{'Natom'});

## MAKE 'XYZ' hash for dat1 ##
for ($i=0;$i<$dat1{'Natom'};++$i)
{ 

  $x = int($permitSc*$dat1{'X'}->[$i]);
  $y = int($permitSc*$dat1{'Y'}->[$i]);
  $z = int($permitSc*$dat1{'Z'}->[$i]); 
  $XYZ1{$x}{$y}{$z} = $i; }

## MAKE 'XYZ' hash for dat2 ##
for ($i=0;$i<$dat1{'Natom'};++$i)
{ $x = int($permitSc*$dat2{'X'}->[$i]);
  $y = int($permitSc*$dat2{'Y'}->[$i]);
  $z = int($permitSc*$dat2{'Z'}->[$i]); 
  $XYZ2{$x}{$y}{$z} = $i; }



## CHECK dat1 for existing corresponding atoms in dat2 ##
print "#ATOMS OF FILE1 \"$fname1\", NOT INCLUDED IN FILE2 \"$fname2\"\n";
for ($j=0;$j<$dat1{'Natom'};++$j)
{
 $x = int($permitSc*$dat1{'X'}->[$j]);
 $y = int($permitSc*$dat1{'Y'}->[$j]);
 $z = int($permitSc*$dat1{'Z'}->[$j]);
 if ($XYZ2{$x}{$y}{$z} eq '') { printf("%s\n",$dat1{'line'}->[$j]); ++$Natm1_uniq;}
}


## CHECK dat2 for existing corresponding atoms in dat1 ##
print "#ATOMS OF FILE2 \"$fname2\", NOT INCLUDED IN FILE1 \"$fname1\"\n";
for ($j=0;$j<$dat2{'Natom'};++$j)
{
 $x = int($permitSc*$dat2{'X'}->[$j]);
 $y = int($permitSc*$dat2{'Y'}->[$j]);
 $z = int($permitSc*$dat2{'Z'}->[$j]);
 if ($XYZ1{$x}{$y}{$z} eq '') { printf("%s\n",$dat2{'line'}->[$j]); $Natm2_uniq;}
}

printf("#FILE $fname1 $fname2 Natom %4d %4d Nuniq %4d %4d\n",
  $dat1{'Natom'},$dat2{'Natom'},$Natm1_uniq,$Natm2_uniq); 




###################
#### FUNCTIONS ####
###################




sub Read_PDB_File{
 my($pdbfile, $spe_chain,$HETtype,$dat) = @_;
 #my($spe_chain) = $_[1]; ## Specified Chain ( if "", not-specified) ##
 #my($HETtype)   = $_[2]; ## 'A'll,'W':excluding waters, 'N'o ##
 #my($newchain)  = $_[3]; ## if "", not-newly assigned.

 if ($spe_chain eq '-') {$spe_chain = "";}

 my($F);
 my($pdb); my($dir);
 my($X);  my($Y);  my($Z);
 my($head); my($tail); my($anum); my($atom); my($res); my($ch);
 my($out); my($head); my($tail);
 my($tFactor);  my($occup);

 open(F,$pdbfile) || die "#ERROR:Can't open pdbfile \"$pdbfile\"";

 $end = 0; $readon = 0;
 $dat->{'Natom'} = 0;
 while(($_=<F>)&&($end==0))
 {
  if ((/^ATOM/)||(/^HETATM/))
   {
    chomp;  
    $out = 0;
    $c = substr($_,21,1);
    $anum = substr($_,6,5);
    $atom = substr($_,12,4);
    $res  = substr($_,17,3);
    $rnum  = substr($_,22,4);
    $X = substr($_,30,8); $Y = substr($_,38,8); $Z = substr($_,46,8);
    $ch = substr($head,21,1);
    $occup   = substr($_,54,6);
    $tFactor = substr($_,60,6);
    #print "\"$_\" tFactor \"$tFactor\" occup \"$occup\"\n";
    if (/^ATOM/)
     { if (($spe_chain eq "") ||($ch eq $spe_chain)) {$out = 1;}   }

    if (/^HETATM/)
    { if ($HETtype  eq 'A') {$out = 1;}
      if (($HETtype eq 'W')&&($res ne 'HOH')) {$out = 1;} }

    if ($out == 1)
    {
     if ($newchain ne "")  { substr($head,21,1) = $newchain; }
     #print "atom \"$atom\"\n";

      push(@{$dat->{'line'}},$_);
      push(@{$dat->{'X'}},$X);
      push(@{$dat->{'Y'}},$Y);
      push(@{$dat->{'Z'}},$Z);
      push(@{$dat->{'anum'}},$anum);
      push(@{$dat->{'atom'}},$atom);
      push(@{$dat->{'res'}},$res);
      push(@{$dat->{'rnum'}},$rnum);
      push(@{$dat->{'tFactor'}},$tFactor);
      push(@{$dat->{'occup'}},$occup);
      $dat->{'Natom'} += 1;

    }
  }

 } ## while ##

 close(F);

} ## end of Read_PDB_File() ##


