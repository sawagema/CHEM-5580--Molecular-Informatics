/*

<Cluster.c>

 for making single-linkage-clustering for probes
 
 coded by Takeshi Kawabata (takawaba@is.naist.jp)

*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <strings.h>
#include <math.h>
#include <time.h>
#include "pdbstruct.h" 
#include "PdbIO.h" 
#include "MCubeFunc.h" 
#include "mc_verface.h" 
#include "EachVol.h" 
#include "Amino.h" 

/*** FUNCTIONS(GLOBAL) ***/
void Make_Cluster_Of_Atoms();
void Cal_Volume_Of_Residues();
float All_Volume_Of_Residues();
void Reorder_Atom_By_Residue();
void Write_Contacting_Atoms_For_Each_Cluster();
void Assign_Contacting_Cluster_For_Each_Residue();
void Remove_Small_Clusters();

/*** FUNCTIONS(LOCAL) ***/
static void Mark_Neighbor();


void Make_Cluster_Of_Atoms(Ahead,Rhead,Dtole)
 struct ATOM    *Ahead;  
 struct RESIDUE *Rhead;
 float  Dtole;          /* Definition of connect : Dab <= a->R + b->R + Dtole */
{
 struct MATRIX Dmat;
 struct ATOM    *an; 
 struct RESIDUE *rn; 
 int Natom,Ncluster;

 /*
  >> Do single-linkage-clustering for probe-atoms <<
    * if (Dij <= (Ri+Rj)), then atom i and j are neighbor.
    *'an->rnum' is considered to be the cluster-number.
 */

 printf("#Make_Cluster_Of_Atoms()\n"); fflush(stdout);
 /*** [1] Inirialize rnum  and calculating distance map ***/
 Rhead->next = NULL;
 an = Ahead;  
 while (an->next != NULL) { an = an->next; an->rnum = 0; an->res = NULL;}
 Renumber_Atom_Number(Ahead);
 Natom = Number_Of_Atom(Ahead);
 Malloc_MATRIX(&Dmat,Natom);
 Cal_Distance_MATRIX(Ahead,&Dmat);

 /*** [2] Make Single Linkage Clustering ***/
 Ncluster = 0;
 an = Ahead;  rn = Rhead;
 while (an->next != NULL){
  an = an->next;
  if (an->res == NULL){ 
     /* (1) Making new RESIDUE */ 
     ++Ncluster; 
     rn->next = (struct RESIDUE *)malloc(sizeof(struct RESIDUE));
     rn->next->prev = rn;
     rn->next->next = NULL;
     rn = rn->next;
     an->rnum =  rn->num  = Ncluster;
     rn->Natom = 0;
     sprintf(rn->Resi,"PRB");
     sprintf(rn->Rnum,"%4d ",rn->num);
     rn->Ahead.rnext = NULL;
     an->res = rn;
     /* printf(">Ncluster %d %d\n",Ncluster,rn->num); */
     Add_Atom_To_Residue_Tail(rn,an); 

     /* (2) Marking Neighbor Atoms */ 
     Mark_Neighbor(Ahead,&Dmat,an,rn,Dtole); 
   }
  
 } /* an */

 printf("#Ncluster %d\n",Ncluster);

 /*** [3] Sorted by rnum ***/
 Reorder_Atom_By_Residue(Ahead,Rhead);

 Free_MATRIX(&Dmat);

} /* end of void Make_Cluster_Of_Atoms() */






void Mark_Neighbor(Ahead,Dmat,an,rn,Dtole)
 struct ATOM    *Ahead;
 struct MATRIX  *Dmat;
 struct ATOM    *an;
 struct RESIDUE *rn;
 float  Dtole;      /* Definition of connect : Dab <= a->R + b->R + Dtole */
{
 struct ATOM *bn;

/* printf("Mark_Neighbor(an %d,rn %d)\n",an->num,rn->num); */

 bn = Ahead;
 while (bn->next != NULL)
 {
   bn = bn->next;
   if ((bn->res==NULL)&&(Dmat->m[an->num][bn->num]<=(an->R + bn->R + Dtole)))
    { Add_Atom_To_Residue_Tail(rn,bn); 
      Mark_Neighbor(Ahead,Dmat,bn,rn,Dtole); }
 }

} /* end of Mark_Neighbor() */





void Reorder_Atom_By_Residue(Ahead,Rhead)
 struct ATOM *Ahead;
 struct RESIDUE *Rhead;
{
 struct ATOM *an,*last;
 struct RESIDUE *rn;
 
 rn = Rhead; last = Ahead;

 while (rn->next != NULL)
 {
  rn = rn->next;
  an = &(rn->Ahead);
  while (an->rnext != NULL)
  {
   an = an->rnext;
   an->prev   = last;
   last->next = an; 
   an->next = an->rnext; 
   last = an; 
  }

 } /* rn */

} /* end of Reorder_Atom_By_Residue() */



void Cal_Volume_Of_Residues(Ahead,Rhead)
 struct ATOM    *Ahead;
 struct RESIDUE *Rhead;
{
 struct RESIDUE *rn;
 struct ATOM *an;
 float Rprobe,Vone;

 printf("#Cal_Volume_Of_Residues()\n"); fflush(stdout);

 /*  Initialize Mark */
 an = Ahead;
 while (an->next != NULL) 
  { an = an->next; an->mark = 0; an->tFactor = 0.0;}

 rn = Rhead;
 while (rn->next != NULL)
 {
  rn = rn->next;
  /* (1) set    mark = 1 for atoms belong to rn */
  an = &(rn->Ahead);
  while (an->rnext!=NULL) { an = an->rnext; an->mark = 1; Rprobe = an->R;}

  /* (2) Cal Volume for marked atoms  */
  rn->Vresidue = rn->value = Cal_Atoms_Volume_By_Marching_Cube(Ahead,'T');

  /* (3) recover mark = 0 again, for atoms belong to rn */
  Vone = 4.0/3.0 * M_PI * Rprobe * Rprobe * Rprobe;
  an = &(rn->Ahead);
  while (an->rnext!=NULL) 
   { an = an->rnext; an->mark = 0;
     an->tFactor = rn->Vresidue/Vone;
    }

  } /* rn */

} /* end of Cal_Volume_Of_Residues() */





float All_Volume_Of_Residues(Rhead)
 struct RESIDUE *Rhead;
{
 struct RESIDUE *rn;
 float Vall;

 Vall = 0.0;
 rn = Rhead;
 while (rn->next != NULL)
 {
  rn = rn->next;
  Vall += rn->Vresidue;
 }
 
 return(Vall);

} /* end of All_Volume_Of_Residues() */





void Write_Contact_Atoms_For_Each_Cluster(fname, Ahead, Chead,command)
 char   *fname; /* Output file name */
 struct ATOM    *Ahead; /* Head Pointer of Protein Atoms */
 struct RESIDUE *Chead; /* Head Pointer of Probe Clusters */
 char   *command;
{
  FILE *fp;
  struct ATOM *pn,*an;
  struct RESIDUE *rn; 
  int i,a,NCON,Nc,Nn,No,Ns,Nx,Ncluster,Naa[21];
  float R,Vone,Fc,Fn,Fo,Fs;

  printf("#Write_Contact_Atoms_For_Each_Cluster()-->\"%s\"\n",fname);
  fp = fopen(fname,"w");
  if (fp==NULL) 
   {printf("#ERROR:Can't write to con-atom-file \"%s\"\n",fname); exit(1);} 

  /*** [1] Output Header Information  ***/
  fprintf(fp,"HEADER    PROBE CLUSTER ATOMS AND THEIR CONTACTING ATOMS\n");
  fprintf(fp,"REMARK     FILENAME \"%s\"\n",fname);
  if (command[0] != '\0') fprintf(fp,"REMARK     COMMAND \"%s\"\n",command);
  fprintf(fp,"REMARK     DATE %s\n",Get_Date_String());
  Ncluster = Number_Of_Residue(Chead);
  fprintf(fp,"REMARK     Ncluster %d\n",Ncluster);
  
  an = Ahead;
  while (an->next != NULL) { an = an->next; an->mark = 0;}

  /*** [2] Cluster (rn) loop  ***/
  rn = Chead;
  while (rn->next != NULL)
  {
   rn = rn->next;
   fprintf(fp,"#PROBE CLUSTER %d\n",rn->num);
   fprintf(fp,"REMARK     PROBE CLUSTER %d\n",rn->num);

   /* (1) Marking */
   pn = &(rn->Ahead);
   while (pn->rnext!=NULL)
   { pn = pn->rnext;
     R = pn->R; 
     for (i=0;i<3;++i) {if (pn->con[i]!=NULL) pn->con[i]->mark = 1; }
   }  

   Vone = 4.0/3.0 * M_PI * R * R * R;
  
   /* (2) Counting */
   NCON = Nc = Nn = No = Ns = Nx = 0.0;
   for (a=0;a<21;++a) Naa[a] = 0;

   an = Ahead;
   while (an->next!=NULL)
   {
    an = an->next;
    if (an->mark==1)
    {
     ++NCON;
          if (an->Atom[1]=='C') ++Nc;
     else if (an->Atom[1]=='N') ++Nn;
     else if (an->Atom[1]=='O') ++No;
     else if (an->Atom[1]=='S') ++Ns;
     else ++Nx;
     a = Number_Amino(TriAA_to_OneAA(an->Resi));
     ++Naa[a];
     } 
   }
   fprintf(fp,"REMARK     %-14s %d\n","Nprobe",rn->Natom); 
   fprintf(fp,"REMARK     %-14s %.2f\n","Rprobe",R); 
   fprintf(fp,"REMARK     %-14s %.2f\n","Vprobe",rn->Vresidue); 
   fprintf(fp,"REMARK     %-14s %.2f\n","Mprobe",rn->Vresidue/Vone); 
   fprintf(fp,"REMARK     %-14s %3d\n","Ncont_atom",NCON); 
   if (NCON>0) 
   { Fc = 100.0*Nc/NCON; 
     Fn = 100.0*Nn/NCON; 
     Fo = 100.0*No/NCON; 
     Fs = 100.0*Ns/NCON; }
   else Fc = Fn = Fo = Fs = 0.0; 
  fprintf(fp,"REMARK     %-14s %3d (%5.1f %%)\n","Ncont_atom_C",Nc,Fc); 
   fprintf(fp,"REMARK     %-14s %3d (%5.1f %%)\n","Ncont_atom_N",Nn,Fn); 
   fprintf(fp,"REMARK     %-14s %3d (%5.1f %%)\n","Ncont_atom_O",No,Fo); 
   fprintf(fp,"REMARK     %-14s %3d (%5.1f %%)\n","Ncont_atom_S",Ns,Fs); 
   for (a=0;a<20;++a)
    if (Naa[a]>0) 
     fprintf(fp,"REMARK     %-14s %c %3d (%5.1f %%)\n","Ncont_atom_res",
       Amino_Number(a),Naa[a],100.0*Naa[a]/NCON); 

   /* (3) Output Probe Atoms  */
   fprintf(fp,"REMARK%5s %4s %3s %6s   %8s%8s%8s%6s%6s%6s%6s%6s\n",
    "","","","","X","Y","Z","R","Mprob","catm1","catm2","catm3");
   fprintf(fp,"#PROBES\n");
   an = &(rn->Ahead);
   while (an->rnext!=NULL)
   {
    an = an->rnext;
    fprintf(fp,"HETATM%5s %4s %3s %c%5s   %8.3f%8.3f%8.3f%6.2f%6.2f",
         an->Anum,an->Atom,an->Resi,an->Chain,an->Rnum,
         an->Pos[0],an->Pos[1],an->Pos[2],an->R,an->tFactor);
    for (i=0;i<3;++i) 
     {if (an->con[i]!=NULL)fprintf(fp,"%6s",an->con[i]->Anum); else fprintf(fp,"%6s","NULL");}
    fprintf(fp,"\n");
   }
   
   /* (4) Output Contact Atoms */
   fprintf(fp,"#CONTACTING_ATOMS\n");
   an = Ahead;
   while (an->next!=NULL)
   {
    an = an->next;
    if (an->mark==1)
    {
          if (an->AHtype=='A')  fprintf(fp,"ATOM  ");
    else  if (an->AHtype=='H')  fprintf(fp,"HETATM");
    else  fprintf(fp,"ATOM? ");
    fprintf(fp,"%5s %4s %3s %c%5s   %8.3f%8.3f%8.3f%6.2f%6.2f\n",
         an->Anum,an->Atom,an->Resi,an->Chain,an->Rnum,
         an->Pos[0],an->Pos[1],an->Pos[2],an->R,an->tFactor);
    }
 
   } /* an */ 
  
   /* (5) Recover Mark */
   pn = &(rn->Ahead);
   while (pn->rnext!=NULL)
   { pn = pn->rnext;
     for (i=0;i<3;++i) {if (pn->con[i]!=NULL) pn->con[i]->mark = 0; }
   }  

   fprintf(fp,"TER\n");    
  } /* rn */

  fclose(fp);

} /* end of Write_Contact_Atoms_For_Each_Cluster() */






void Assign_Contact_Cluster_For_Each_Residue(Ahead, Rhead,Chead)
 struct ATOM    *Ahead; /* Head Pointer of Protein Atoms */
 struct RESIDUE *Rhead; /* Head Pointer of Residues */
 struct RESIDUE *Chead; /* Head Pointer of Probe Clusters */
{
  struct ATOM *pn,*an;
  struct RESIDUE *rn,*cn; 
  int i,Nclus;
  float R,Vone;

  printf("#Assign_Contact_Cluster_For_Each_Residue\n");

  /* Initialize */
  Nclus = Number_Of_Residue(Rhead); 
  rn = Rhead;
  while (rn->next != NULL) 
   { rn = rn->next; rn->Vcluster = 0.0;
     rn->con_clus = (char *)malloc(sizeof(char)*(Nclus+1));
     for (i=0;i<=Nclus;++i) rn->con_clus[i] = 0;
    }
  
  cn = Chead; 
  while (cn->next != NULL) 
  { cn = cn->next; 
    printf(">cn %d Vresidue %f\n",cn->num,cn->Vresidue);
    pn = &(cn->Ahead);
    while (pn->rnext != NULL) 
    {
     pn = pn->rnext;
     for (i=0;i<3;++i) 
      if (pn->con[i]!=NULL)
      { 
       pn->con[i]->res->con_clus[cn->num] = 1;
       if (pn->con[i]->res->Vcluster < cn->Vresidue)
          pn->con[i]->res->Vcluster = cn->Vresidue; 
       }
    } /* pn */    
 
  } /* cn */

} /* end of Assign_Contact_Cluster_For_Each_Residue() */



void Remove_Small_Clusters(Ahead,Rhead,Mmin)
 struct ATOM    *Ahead;
 struct RESIDUE *Rhead;
 float  Mmin;  /* Remove Probe Clusters with Mprobe <= Mmin */
{
 struct RESIDUE *rn,*xn;
 struct ATOM    *an,*yn;
 float R,Vone;
 int Nrm_clus;
 
 printf("#Remove_Small_Clusters(Mprobe_min %f)\n",Mmin);

 /* (1) Initialize mark */
 an = Ahead;
 while (an->next != NULL) {an = an->next; an->mark = 0;}

 /* (2) Remove RESIDUE with Vresidue/Vone <= Mmin, 
        and mark atoms belong to that residue.    */ 
 Nrm_clus = 0; 
 rn = Rhead;
 while (rn->next != NULL)
 {
   rn = rn->next;
   if (rn->Ahead.rnext != NULL)
   {
     R = rn->Ahead.rnext->R; 
     Vone = 4.0/3.0 * M_PI * R * R * R;
     if (rn->Vresidue <= Vone*Mmin) 
     {
       printf("#  Remove cluster [%d] Nprb %d V %f M %f\n",
        rn->num,rn->Natom,rn->Vresidue,rn->Vresidue/Vone);
       an = &(rn->Ahead);
       while (an->rnext != NULL) {an = an->rnext; an->mark = 1;}
       xn = rn; 
       xn->prev->next = xn->next;
       if (xn->next != NULL) xn->next->prev = xn->prev;
       rn = xn->prev;
       free(xn);
      } 
   }
 
 } /* rn */

 /* (3) Remove marked ATOMs  */ 
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  if (an->mark == 1)
  {
   yn = an;
   yn->prev->next = yn->next;
   if (yn->next != NULL) yn->next->prev = yn->prev;
   an = yn->prev;
   free(yn);
   }   
 } 

} /* end of Remove_Small_Clusters() */

