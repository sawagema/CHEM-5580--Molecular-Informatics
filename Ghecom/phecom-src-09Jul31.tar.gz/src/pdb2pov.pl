#!/usr/bin/perl
#
# <pdb2pov.pl>
#

$LastModDate = "Sep 6, 2006";

$OPT{'X'} = $OPT{'Y'} = $OPT{'Z'} = 20;
$OPT{'A'} eq '';
$OPT{'of'} = '';
$OPT{'R'} = 'C';
$OPT{'C'} = 'C';
$OPT{'tr'} = '0.0';
$OPT{'minr'} = '0.0';
$OPT{'maxr'} = '100000.0';
$OPT{'cdir'} = '0:0.1:1';
$OPT{'ldir'} = '0:1:0';
$OPT{'cdis'} = 4.0;
$OPT{'ldis'} = 4.0;

if (scalar(@ARGV)<1)
{
 print "pdb2pov.pl [pdbfile]\n";
 print " to change PDB file to SpaceFill povray file (*.pov)\n";
 print " coded by T.Kawabata. LastModified:$LastModDate\n";
 printf(" -of   : Output file [%s]\n",$OPT{'of'});
 printf(" -R    : Radius type 'C'pk 'O'ccup 'T'factor 'U'nified [%s]\n",$OPT{'R'});
 printf(" -C    : Color  type 'C'pk 'U'nified [%s]\n",$OPT{'C'});
 printf(" -r    : unified radius [%s]\n",$OPT{'co'});
 printf(" -co   : unified color  [%s]\n",$OPT{'co'});
 printf(" -tr   : transparency  [%s]\n",$OPT{'tr'});
 printf(" -minr : Minimum Radius  [%s]\n",$OPT{'minr'});
 printf(" -maxr : Maximum Radius  [%s]\n",$OPT{'maxr'});
 printf(" -cdir : Camera Direction  [%s]\n",$OPT{'cdir'});
 printf(" -cdis : Camera Distance (unit of Rg) [%s]\n",$OPT{'cdis'});
 printf(" -ldir : Light Direction  [%s]\n",$OPT{'ldir'});
 printf(" -ldis : Light Distancen (unit of Rg) [%s]\n",$OPT{'ldis'});
 exit(1);
}

$pdbfile = $ARGV[0];
&Read_Options(\@ARGV,\%OPT);
&Read_PDB_File($pdbfile,'-','A',\%DAT);
&Set_Atom_Radius_Color(\%DAT);
&Cal_Gcenter_Rg(\%DAT);
&Set_Gcenter_to_Origin(\%DAT);


if ($OPT{'of'} eq '')
{
 ($head,$tail) = split(/\./,$pdbfile);
 $OPT{'of'} = $head.'.pov';
}
&Output_POVRAY_File($OPT{'of'},\%DAT);


#################
### FUNCTIONS ###
#################



sub Output_POVRAY_File{
 my($ofile,$dat) = @_;
 my($OF); 
 my(@Cdir) = split(/:/,$OPT{'cdir'}); my($Clen);
 my(@Ldir) = split(/:/,$OPT{'ldir'}); my($Llen);
 my($i);

 if ($ofile ne '-') {printf("#Output_POVRAY_File() --> \"%s\"\n",$ofile);}
 open(OF,">$ofile");

 &Normalize_Vec3D(\@Cdir);
 &Normalize_Vec3D(\@Ldir);
 $Clen = $dat->{'Rg'} * $OPT{'cdis'};
 $Llen = $dat->{'Rg'} * $OPT{'ldis'};
 printf("#Cdir %s %s %s Clen %s\n",$Cdir[0],$Cdir[1],$Cdir[2],$Clen);
 printf("#Ldir %s %s %s Llen %s\n",$Ldir[0],$Ldir[1],$Ldir[2],$Llen);
  
 printf(OF "#include \"colors.inc\"\n");
 printf(OF "#include \"shapes.inc\"\n");
 printf(OF "#include \"shapes2.inc\"\n");
 printf(OF "#include \"stones.inc\"\n");
 printf(OF "#include \"woods.inc\"\n");
 printf(OF "#include \"skies.inc\"\n");
 printf(OF "#include \"stars.inc\"\n");
 printf(OF "#include \"textures.inc\"\n");
 printf(OF "\n");
 printf(OF "camera{\n");
 printf(OF "location <%f, %f, %f>\n",
   $dat->{'Gx'} + $Cdir[0]*$Clen,
   $dat->{'Gy'} + $Cdir[1]*$Clen,
   $dat->{'Gz'} + $Cdir[2]*$Clen);
 printf(OF "look_at <%s, %s, %s>\n",$dat->{'Gx'},$dat->{'Gy'},$dat->{'Gz'});
 printf(OF "}\n\n");
                                                                                
 printf(OF "light_source{<%f, %f, %f>\n",
   $dat->{'Gx'} + $Ldir[0]*$Llen,
   $dat->{'Gy'} + $Ldir[1]*$Llen,
   $dat->{'Gz'} + $Ldir[2]*$Llen);
 printf(OF " color White}\n\n");

 printf(OF "\n");
 printf(OF "sky_sphere{S_Cloud1}\n");
 printf(OF "\n");
 printf(OF "object{\n");
 printf(OF " Plane_XZ\n");
 printf(OF " translate<0,%s,0>\n",-$dat->{'Gy'}-$dat->{'Rg'}*2);
 printf(OF " texture{T_Stone12}\n");
 printf(OF "}\n");

 for ($i=0;$i<scalar(@{$dat->{'X'}});++$i)
{
 if ($dat->{'R'}->[$i]>0.0)
 {
 printf(OF "//%s %s %s\n",$dat->{'atom'}->[$i],$dat->{'res'}->[$i],$dat->{'rnum'}->[$i]);
 printf(OF "object{\n");
 printf(OF " sphere{<%s, %s, %s> %s}\n",
   $dat->{'X'}->[$i],$dat->{'Y'}->[$i],$dat->{'Z'}->[$i],$dat->{'R'}->[$i]);
    if ($dat->{'color'}->[$i] eq 'red')    {$r = 1.0; $g = 0.0; $b = 0.0;}
 elsif ($dat->{'color'}->[$i] eq 'blue')   {$r = 0.0; $g = 0.0; $b = 1.0;}
 elsif ($dat->{'color'}->[$i] eq 'yellow') {$r = 1.0; $g = 1.0; $b = 0.0;}
 elsif ($dat->{'color'}->[$i] eq 'gray')   {$r = 0.7; $g = 0.7; $b = 0.7;}
 elsif ($dat->{'color'}->[$i] eq 'orange') {$r = 1.0; $g = 0.5; $b = 0.0;}
 elsif ($dat->{'color'}->[$i] eq 'green')  {$r = 0.0; $g = 1.0; $b = 0.0;}
 printf(OF "   pigment{color rgb <%s %s %s>}\n",$r,$g,$b);
 printf(OF "   finish{specular 0.3 roughness 0.1}\n");
 printf(OF "   }\n");
 }
}

close(OF);

} ## end of Output_POVRAY_File() ##



sub Set_Atom_Radius_Color{
 my($dat) = @_;

 my($i);

 my(%Radius); my(%Color); my(%Trans);

 $Radius{'N'} = 1.65;
 $Radius{'C'} = 1.87;
 $Radius{'O'} = 1.40;
 $Radius{'S'} = 1.85;
 
 $Color{'N'} = 'blue';
 $Color{'C'} = 'gray';
 $Color{'O'} = 'red';
 $Color{'S'} = 'yellow';
 $Color{'P'} = 'green';
 
 $Trans{'N'} = 0.0;
 $Trans{'C'} = 0.0;
 $Trans{'O'} = 0.0;
 $Trans{'S'} = 0.0;
 $Trans{'P'} = 0.6;

 for ($i=0;$i<$dat->{'Natom'};++$i)
 {
  $atomtype = substr($dat->{'atom'}->[$i],1,1);

  $dat->{'trans'}->[$i] = $OPT{'tr'};
  ### RADIUS ASSIGNMENT ### 
     if ($OPT{'R'} eq 'O') { $dat->{'R'}->[$i]  = $dat->{'occup'}->[$i];  } 
  elsif ($OPT{'R'} eq 'T') { $dat->{'R'}->[$i]  = $dat->{'tFactor'}->[$i];  } 
  elsif ($OPT{'R'} eq 'C') 
    { $dat->{'R'}->[$i]      = $Radius{$atomtype}; }
  elsif ($OPT{'R'} eq 'U') { $dat->{'R'}->[$i]  = $OPT{'r'}; }
  else { $dat->{'R'}->[$i]  = 1.87;}

  if ($dat->{'R'}->[$i] < $OPT{'minr'}) { $dat->{'R'}->[$i] = $OPT{'minr'};}
  if ($dat->{'R'}->[$i] > $OPT{'maxr'}) { $dat->{'R'}->[$i] = 0.0;}

  ### COLOR ASSIGNMENT ### 

   if ($OPT{'C'} eq 'C') 
  { $dat->{'color'}->[$i] = $Color{$atomtype}; 
    if ($Trans{$atomtype} ne '') {$dat->{'trans'}->[$i]  = $Trans{$atomtype}; }
  #  printf("%s %s %s %s\n",$dat->{'atom'}->[$i],$atomtype,$dat->{'R'}->[$i],$dat->{'trans'}->[$i]);
    }
  elsif ($OPT{'C'} eq 'U') { $dat->{'color'}->[$i] = $OPT{'co'}; }
  else  {$dat->{'color'}->[$i] = 'blue';}
 } ## $i ##

} ## end of Set_Atom_Radius_Color() ##




sub Read_Sphere_List{
 my($fname,$dat) = @_;
 my($x); my($y); my($z); my($r);
  
 %{$dat} = ();

 open(F,$fname) || die "#ERROR:Can't open \"$fname\"";
 while (<F>)
 {
  if ($_!~/^#/)
  {
    chomp;
    ($x,$y,$z,$r) = split(/\s+/,$_); 
    push(@{$dat->{'X'}},$x);
    push(@{$dat->{'Y'}},$y);
    push(@{$dat->{'Z'}},$z);
    push(@{$dat->{'R'}},$r);
    push(@{$dat->{'RR'}},$r*$r);
   } 
 } 
 close(F);

} ## end of Read_Sphere_List() ##



sub Read_Options{
 # $_[0] : ref of \@ARGV
 # $_[1] : ref of \%OPT

 # This script is reading following style options :
 #   psiscan.pl org41list -lib 95pdb01Mar4Mx -tail -I -C
 # In principle, the format is the style like  "[-option] [value]"
 # If [value] is omitted, [option] is set to '1'.

 my($x); my($x1); my($i);
 
 $i = 0;
 while ($i<scalar(@ARGV))
 {
  $x  = $_[0]->[$i];
  $x1 = $_[0]->[$i+1];
  if ($x =~/^\-/)
   { $x =~s/^\-//;
     if (($x1 !~ /^\-\w+/)&&(length($x1)>0)) { $_[1]->{$x} = $x1; ++$i; }
     else { $_[1]->{$x} = 1;}
   }
  ++$i;
 }

} ## end of Read_Options() ##

sub Cal_Gcenter_Rg{
 my($dat) = @_;
 my($Sx); my($Sy); my($Sz); my($i);
 my($dx); my($dy); my($dz); my($DD) = 0.0; 
 
 if ($dat->{'Natom'} == 0) {return(0);}

 $Sx = $Sy = $Sz = 0.0;
 for ($i=0;$i<$dat->{'Natom'};++$i)
 {
  $Sx += $dat->{'X'}->[$i];
  $Sy += $dat->{'Y'}->[$i];
  $Sz += $dat->{'Z'}->[$i];
 }

 $dat->{'Gx'} = $Sx/$dat->{'Natom'};
 $dat->{'Gy'} = $Sy/$dat->{'Natom'};
 $dat->{'Gz'} = $Sz/$dat->{'Natom'}; 

 for ($i=0;$i<$dat->{'Natom'};++$i)
 {
  $dx = $dat->{'X'}->[$i] - $dat->{'Gx'};
  $dy = $dat->{'Y'}->[$i] - $dat->{'Gy'};
  $dz = $dat->{'Z'}->[$i] - $dat->{'Gz'};
  $DD += $dx*$dx + $dy*$dy + $dz*$dz;
 }


 if ($DD > 0.0) {$DD = sqrt($DD/$dat->{'Natom'});}

 $dat->{'Rg'} = $DD;
 printf("#Rg %f\n",$dat->{'Rg'});

} ## end of Cal_Gcenter_Rg() ##



sub Set_Gcenter_to_Origin{
 my($dat) = @_;
 my($i);
 
 printf("#Set_Gcenter_to_Origin()\n");

 for ($i=0;$i<$dat->{'Natom'};++$i)
 {
  $dat->{'X'}->[$i] -= $dat->{'Gx'};
  $dat->{'Y'}->[$i] -= $dat->{'Gy'};
  $dat->{'Z'}->[$i] -= $dat->{'Gz'};
 }

 $dat->{'Gx'} = 0.0; $dat->{'Gy'} = 0.0; $dat->{'Gz'} = 0.0;

} ## end of Set_Gcenter_to_Origin() ##


sub Read_PDB_File{
 my($pdbfile, $spe_chain,$HETtype,$dat) = @_;
 #my($spe_chain) = $_[1]; ## Specified Chain ( if "", not-specified) ##
 #my($HETtype)   = $_[2]; ## 'A'll,'W':excluding waters, 'N'o ##
 #my($newchain)  = $_[3]; ## if "", not-newly assigned.
   
 printf("#Read_PDB_File('%s')\n",$pdbfile);
 if ($spe_chain eq '-') {$spe_chain = "";}

 my($F); 
 my($pdb); my($dir);
 my($X);  my($Y);  my($Z);
 my($head); my($tail); my($atom); my($res); my($ch);
 my($out); my($head); my($tail);
 my($tFactor);  my($occup);
   
 open(F,$pdbfile) || die "#ERROR:Can't open pdbfile \"$pdbfile\"";

 $end = 0; $readon = 0;
 $dat->{'Natom'} = 0;
 while(($_=<F>)&&($end==0))
 {
  if ((/^ATOM/)||(/^HETATM/))
   {
    $out = 0;
    $c = substr($_,21,1);
    $atom = substr($_,12,4);
    $res  = substr($_,17,3);
    $rnum  = substr($_,22,4);
    $X = substr($_,30,8); $Y = substr($_,38,8); $Z = substr($_,46,8);
    $ch = substr($head,21,1);
    $occup   = substr($_,54,6);
    $tFactor = substr($_,60,6);
    #print "\"$_\" tFactor \"$tFactor\" occup \"$occup\"\n";
    if (/^ATOM/)
     { if (($spe_chain eq "") ||($ch eq $spe_chain)) {$out = 1;}   }

    if (/^HETATM/)
    { if ($HETtype  eq 'A') {$out = 1;}
      if (($HETtype eq 'W')&&($res ne 'HOH')) {$out = 1;} }

    if ($out == 1)
    {
     if ($newchain ne "")  { substr($head,21,1) = $newchain; }
     #print "atom \"$atom\"\n";
     push(@{$dat->{'X'}},$X); 
     push(@{$dat->{'Y'}},$Y); 
     push(@{$dat->{'Z'}},$Z); 
     push(@{$dat->{'atom'}},$atom); 
     push(@{$dat->{'res'}},$res); 
     push(@{$dat->{'rnum'}},$rnum); 
     push(@{$dat->{'tFactor'}},$tFactor); 
     push(@{$dat->{'occup'}},$occup); 
     $dat->{'Natom'} += 1; 
    }
  }

 } ## while ##
close(F);


} ## end of Read_PDB_File() ##


sub Normalize_Vec3D{
 my($x) = @_;
 my($len);

 $len = $x->[0]*$x->[0] + $x->[1]*$x->[1] + $x->[2]*$x->[2];
 if ($len>0.0) {
  $len = sqrt($len);
  $x->[0] /= $len;
  $x->[1] /= $len;
  $x->[2] /= $len;
 }

} ## end of Normalize_Vec3D() ##
