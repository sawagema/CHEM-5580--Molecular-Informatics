/*

 <SphePnt3.c>
 
  for calculating 3-contacting probe spheres.

  coded by Takeshi Kawabata (takawaba@is.naist.jp)

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "pdbstruct.h" 
#include "ColCheck.h" 
#include "Overlap.h" 


/*** FUNCTION (GLOBAL) ***/
int  Cal_Sphere_On_Three_Atoms();
void Make_Probe_Spheres_Three_Contact();
void Make_Probe_Spheres_Three_Contact_ColVoxel();
void Make_Probe_Spheres_Three_Contact_PairColVoxel();
void Make_Probe_Spheres_Three_Contact_PairColVoxel_Overlap();
void Make_Probe_Spheres_Three_Contact_Overlap();
void Make_Probe_Spheres_Three_Contact_ColVoxel_Overlap();
void Remove_Crashed_Atom();
int  Make_Probe_One_Probe_Two_Protein();
void Joint_Atom_List();
void Assign_ChainID();
int  Check_Crash_Pos_and_Atoms();
void Add_Atom_Stack();
void Renumber_AnumRnum();


/*** FUNCTION (LOCAL) ***/
static void Cal_Tij_on_Base_Plane();
static float Norm();
static int Normalize();
static int Normalize_Double();
static float Dot_Prod();  
static double Dot_Prod_Double();  
static void Cross_Prod();
static void Cross_Prod_Double();
static float Distance();
static int Cal_Probe_Circle_On_Two_Atoms();



void  Make_Probe_Spheres_Three_Contact(Phead,Ahead,Rprobe,Dmat)
 struct ATOM *Phead;
 struct ATOM *Ahead;
 float  Rprobe;
 struct MATRIX *Dmat;
{
 /*
  This functions is the basic one.
  The answer is correct, but it needs much computational time 
  for many atoms and for a large probe sphere. 
 */
 
 struct ATOM *an,*bn,*cn;
 float Rprobe2;
 float Ppos[3],Qpos[3];
 int Nprobe;
 char spok;

 Rprobe2 = Rprobe *2;
 Nprobe = 0;
 Phead->next = NULL;
 an = Ahead;

 while (an->next != NULL)
 {
  an = an->next;
  bn = an;
  while (bn->next != NULL)
  {
   bn = bn->next;
   
   if (Dmat->m[an->num][bn->num] <= an->R+bn->R+Rprobe2)
   {
    cn = bn;
    while (cn->next != NULL)
    {
     cn = cn->next;
     if( (Dmat->m[an->num][cn->num] <= an->R+cn->R+Rprobe2) &&
         (Dmat->m[bn->num][cn->num] <= bn->R+cn->R+Rprobe2) )
     {
       spok = Cal_Sphere_On_Three_Atoms(Ppos,Qpos,Rprobe,an,bn,cn);
       if (spok==1)
       {
        if (Check_Crash_Pos_and_Atoms(Ppos,Rprobe,Ahead)==0)
        { Add_Atom_Stack(Phead,Ppos,Rprobe,'T',Nprobe,an,bn,cn); ++Nprobe;}
        if (Check_Crash_Pos_and_Atoms(Qpos,Rprobe,Ahead)==0)
         {Add_Atom_Stack(Phead,Qpos,Rprobe,'T',Nprobe,an,bn,cn); ++Nprobe;}
       }
      } 

     } /* cn */ 

    }

   } /* bn */ 

  } /* an */

  Renumber_AnumRnum(Phead);

} /* end of Make_Probe_Spheres_Three_Contact() */





void  Make_Probe_Spheres_Three_Contact_ColVoxel(Phead,Ahead,Rprobe,Dmat)
 struct ATOM *Phead;
 struct ATOM *Ahead;
 float  Rprobe;
 struct MATRIX *Dmat;
{
 /*
  This function uses COLVOXEL to speed up the collision check 
  between generated probe spheres and other protein atoms. 
 */
 
 struct ATOM *an,*bn,*cn;
 float Rprobe2;
 float Ppos[3],Qpos[3];
 int i,Nprobe;
 char spok,pok,qok;
 struct COLVOXEL cvox;
 int I[3];
 int Ntry,Nspok,Naccept,naccept,Npair_accept,Npair; 

 Rprobe2 = Rprobe *2;
 Nprobe = 0;
 Phead->next = NULL;

 
 /** Make ColVoxel for Fast Collision Check **/
 
 cvox.gridlen = PAR.cvox_grid;
 Cal_Size_Of_Voxel_By_Molecule(Ahead,Rprobe,cvox.gridlen,cvox.min,cvox.N,'F');
 Malloc_Col_Voxel( &cvox, cvox.N[0],cvox.N[1],cvox.N[2]);
 Cal_Col_Voxel(&cvox,Ahead,Rprobe*0.5);

 Ntry = Nspok = Naccept = Npair = Npair_accept = 0; 
 an = Ahead;

 while (an->next != NULL)
 {
  an = an->next;
  bn = an;
  while (bn->next != NULL)
  {
   bn = bn->next;
   
 
   if (Dmat->m[an->num][bn->num] <= an->R+bn->R+Rprobe2)
   {
    cn = bn;
    naccept = 0;
    ++Npair; 
    while (cn->next != NULL)
    {
     cn = cn->next;
     if( (Dmat->m[an->num][cn->num] <= an->R+cn->R+Rprobe2) &&
         (Dmat->m[bn->num][cn->num] <= bn->R+cn->R+Rprobe2) )
     {
       spok = Cal_Sphere_On_Three_Atoms(Ppos,Qpos,Rprobe,an,bn,cn);
       ++Ntry;
 
       if (spok==1)
       {
        ++Nspok;
        pok = qok = 0;
        IntXYZ_from_FloatXYZ(I,Ppos,&cvox);
        
        if ((cvox.map[I[0]][I[1]][I[2]]!=255)&&(Check_Crash_Pos_and_Atoms(Ppos,Rprobe,Ahead)==0))
        { Add_Atom_Stack(Phead,Ppos,Rprobe,'T',Nprobe,an,bn,cn); ++Nprobe; pok = 1;}
        
        IntXYZ_from_FloatXYZ(I,Qpos,&cvox);
        if ((cvox.map[I[0]][I[1]][I[2]]!=255)&&(Check_Crash_Pos_and_Atoms(Qpos,Rprobe,Ahead)==0))
         {Add_Atom_Stack(Phead,Qpos,Rprobe,'T',Nprobe,an,bn,cn); ++Nprobe; qok = 1;}

       if ((pok==1)||(qok==1)){  ++Naccept; ++naccept;}
       }
      } 
   
    } /* cn */ 

     if (naccept > 0) ++Npair_accept;
    }

   } /* bn */ 

  } /* an */

  Renumber_AnumRnum(Phead);
  printf("#Ntry %d Nspok %d Naccept %d Nprobe %d Npair %d Npair_accept %d\n",
   Ntry,Nspok,Naccept,Nprobe,Npair,Npair_accept);

 Free_Col_Voxel( &cvox, cvox.N[0],cvox.N[1],cvox.N[2]);
} /* end of Make_Probe_Spheres_Three_Contact_ColVoxel() */






void  Make_Probe_Spheres_Three_Contact_PairColVoxel(Phead,Ahead,Rprobe,Dmat)
 struct ATOM *Phead;
 struct ATOM *Ahead;
 float  Rprobe;
 struct MATRIX *Dmat;
{
 struct ATOM *an,*bn,*cn;
 float Rprobe2;
 float Ppos[3],Qpos[3],Hpos[3];
 int i,m,Nprobe;
 char spok,pok,qok,ok;
 struct COLVOXEL cvox;
 int I[3];
 int Ntry,Nspok,Naccept,naccept,Npair_accept,Npair; 
 float Tij[3],Rmat[3][3],Rcirc;
 float Pcirc[256][3],Qcirc[3];
 int Ncirc,Ncirc_out;
 float theta;

 printf("#Make_Probe_Spheres_Three_Contact_PairColVoxel()\n");

 Rprobe2 = Rprobe *2;
 Nprobe = 0;
 Phead->next = NULL;

 
 /** Make ColVoxel for Fast Collision Check **/
 cvox.gridlen = PAR.cvox_grid;
 Cal_Size_Of_Voxel_By_Molecule(Ahead,Rprobe,cvox.gridlen,cvox.min,cvox.N,'F');
 Malloc_Col_Voxel( &cvox, cvox.N[0],cvox.N[1],cvox.N[2]);
 Cal_Col_Voxel(&cvox,Ahead,Rprobe*0.5);


 Ncirc = (int)ceil(2*M_PI*(1.8+Rprobe)/cvox.gridlen);
 

 printf("#Ncirc %d\n",Ncirc);
 for (i=0;i<Ncirc;++i)
  { theta = 2.0*M_PI*i/Ncirc;
    Pcirc[i][0] = cos(theta); Pcirc[i][1] = sin(theta); Pcirc[i][2] = 0.0; }

 Ntry = Nspok = Naccept = Npair = Npair_accept = 0; 
 an = Ahead;

 while (an->next != NULL)
 {
  an = an->next;
  bn = an;
  while (bn->next != NULL)
  {
   bn = bn->next;
   
   if (Dmat->m[an->num][bn->num] <= an->R+bn->R+Rprobe2)
   {
    Cal_Probe_Circle_On_Two_Atoms(an,bn,Rprobe,Tij,&Rcirc,Rmat);
 
   Ncirc_out = 0;
   if (Rcirc>0.0)
   { 
    i = 0;  
    while ((i<Ncirc)&&(Ncirc_out==0)) 
    {
     for (m=0;m<3;++m)
      Qcirc[m]=Rcirc*(Rmat[m][0]*Pcirc[i][0]+Rmat[m][1]*Pcirc[i][1]) + Tij[m]; 
     ok = IntXYZ_from_FloatXYZ(I,Qcirc,&cvox);
     if (cvox.map[I[0]][I[1]][I[2]]!=255) { Ncirc_out += 1;} 
     ++i;
    } /* i */
   }

    cn = bn;
    Hpos[0] = Hpos[1] = Hpos[2] = 0.0;
    naccept = 0;
    ++Npair; 
    while ((cn->next != NULL)&&(Ncirc_out > 0))  
    {
     cn = cn->next;
     if( (Dmat->m[an->num][cn->num] <= an->R+cn->R+Rprobe2) &&
         (Dmat->m[bn->num][cn->num] <= bn->R+cn->R+Rprobe2) )
     {
 
       spok = Cal_Sphere_On_Three_Atoms(Ppos,Qpos,Rprobe,an,bn,cn);
       ++Ntry;
 
       if (spok==1)
       {
        ++Nspok;
        pok = qok = 0;
        IntXYZ_from_FloatXYZ(I,Ppos,&cvox);
        
        if ((cvox.map[I[0]][I[1]][I[2]]!=255)&&(Check_Crash_Pos_and_Atoms(Ppos,Rprobe,Ahead)==0))
        { Add_Atom_Stack(Phead,Ppos,Rprobe,'T',Nprobe,an,bn,cn); ++Nprobe; pok = 1;
          Hpos[0] = Ppos[0]; Hpos[1] = Ppos[1]; Hpos[2] = Ppos[2]; }
        
        IntXYZ_from_FloatXYZ(I,Qpos,&cvox);
        if ((cvox.map[I[0]][I[1]][I[2]]!=255)&&(Check_Crash_Pos_and_Atoms(Qpos,Rprobe,Ahead)==0))
         {Add_Atom_Stack(Phead,Qpos,Rprobe,'T',Nprobe,an,bn,cn); ++Nprobe; qok = 1;
          Hpos[0] = Qpos[0]; Hpos[1] = Qpos[1]; Hpos[2] = Qpos[2]; }

       if ((pok==1)||(qok==1)){  ++Naccept; ++naccept;}
       }
      } 
   
   
     } /* cn */ 

    if ((Ncirc_out==0)&&(naccept>0))   
    printf("#PAIR Ncirc_ok %d naccept %d\n",Ncirc_out,naccept);

    if (naccept > 0) ++Npair_accept;
    }

   } /* bn */ 

  } /* an */

  Renumber_AnumRnum(Phead);
  printf("#Ntry %d Nspok %d Naccept %d Nprobe %d Npair %d Npair_accept %d\n",
   Ntry,Nspok,Naccept,Nprobe,Npair,Npair_accept);

  Free_Col_Voxel( &cvox, cvox.N[0],cvox.N[1],cvox.N[2]);

} /* end of Make_Probe_Spheres_Three_Contact_PairColVoxel() */



void  Make_Probe_Spheres_Three_Contact_PairColVoxel_Overlap(Phead,Ahead,Rprobe,Dmat)
 struct ATOM *Phead;
 struct ATOM *Ahead;
 float  Rprobe;
 struct MATRIX *Dmat;
{
 struct ATOM *an,*bn,*cn;
 float Rprobe2;
 float Ppos[3],Qpos[3],Hpos[3];
 int i,m,Nprobe;
 char spok,pok,qok,ok;
 struct COLVOXEL cvox;
 int I[3];
 int Ntry,Nspok,Naccept,naccept,Npair_accept,Npair; 
 float Tij[3],Rmat[3][3],Rcirc;
 float Pcirc[256][3],Qcirc[3];
 int Ncirc,Ncirc_out;
 float theta;

 printf("#Make_Probe_Spheres_Three_Contact_PairColVoxel_Overlap()\n");

 Rprobe2 = Rprobe *2;
 Nprobe = 0;
 Phead->next = NULL;
 Set_Overlap_List(Ahead,Dmat,Rprobe);
 
 /** Make ColVoxel for Fast Collision Check **/
 cvox.gridlen = PAR.cvox_grid;
 Cal_Size_Of_Voxel_By_Molecule(Ahead,Rprobe,cvox.gridlen,cvox.min,cvox.N,'F');
 Malloc_Col_Voxel( &cvox, cvox.N[0],cvox.N[1],cvox.N[2]);
 Cal_Col_Voxel(&cvox,Ahead,Rprobe*0.5);


 Ncirc = (int)ceil(2*M_PI*(1.8+Rprobe)/cvox.gridlen);
 
 printf("#Ncirc %d\n",Ncirc);
 for (i=0;i<Ncirc;++i)
  { theta = 2.0*M_PI*i/Ncirc;
    Pcirc[i][0] = cos(theta); Pcirc[i][1] = sin(theta); Pcirc[i][2] = 0.0; }

 Ntry = Nspok = Naccept = Npair = Npair_accept = 0; 
 an = Ahead;

 while (an->next != NULL)
 {
  an = an->next;
  bn = an;
  while (bn->next != NULL)
  {
   bn = bn->next;
   
   if (Dmat->m[an->num][bn->num] <= an->R+bn->R+Rprobe2)
   {
    Cal_Probe_Circle_On_Two_Atoms(an,bn,Rprobe,Tij,&Rcirc,Rmat);
  
   Ncirc_out = 0;

   if (Rcirc>0.0)
   {
    i = 0;  
    while ((i<Ncirc)&&(Ncirc_out==0)) 
    {
     for (m=0;m<3;++m)
       Qcirc[m]=Rcirc*(Rmat[m][0]*Pcirc[i][0]+Rmat[m][1]*Pcirc[i][1]) + Tij[m]; 
     ok = IntXYZ_from_FloatXYZ(I,Qcirc,&cvox);
     if (cvox.map[I[0]][I[1]][I[2]]!=255) { Ncirc_out += 1;} 
     ++i;
     } /* i */

    }  /* Rcirc > 0.0 */

    cn = bn;
    Hpos[0] = Hpos[1] = Hpos[2] = 0.0;
    naccept = 0;
    ++Npair; 

    while ((cn->next != NULL)&&(Ncirc_out > 0))  
    {
     cn = cn->next;

     if( (Dmat->m[an->num][cn->num] <= an->R+cn->R+Rprobe2) &&
         (Dmat->m[bn->num][cn->num] <= bn->R+cn->R+Rprobe2) )
     {
 
       spok = Cal_Sphere_On_Three_Atoms(Ppos,Qpos,Rprobe,an,bn,cn);
       ++Ntry;
 
       if (spok==1)
       {
        ++Nspok;
        pok = qok = 0;
        /* 
        printf("IntXYZ here Ppos %f %f %f\n",Ppos[0],Ppos[1],Ppos[2]); 
        */ 
        IntXYZ_from_FloatXYZ(I,Ppos,&cvox);
      
        if ((cvox.map[I[0]][I[1]][I[2]]!=255)&&(Check_Crash_Pos_and_Overlapped_Atoms(Ppos,Rprobe,an)==0))
        { Add_Atom_Stack(Phead,Ppos,Rprobe,'T',Nprobe,an,bn,cn); ++Nprobe; pok = 1;
          Hpos[0] = Ppos[0]; Hpos[1] = Ppos[1]; Hpos[2] = Ppos[2]; }
        
        IntXYZ_from_FloatXYZ(I,Qpos,&cvox);
        if ((cvox.map[I[0]][I[1]][I[2]]!=255)&&(Check_Crash_Pos_and_Overlapped_Atoms(Qpos,Rprobe,an)==0))
         {Add_Atom_Stack(Phead,Qpos,Rprobe,'T',Nprobe,an,bn,cn); ++Nprobe; qok = 1;
          Hpos[0] = Qpos[0]; Hpos[1] = Qpos[1]; Hpos[2] = Qpos[2]; }

       if ((pok==1)||(qok==1)){  ++Naccept; ++naccept;}
       }
      } 
   
   
     } /* cn */ 

    if ((Ncirc_out==0)&&(naccept>0))   
    printf("#PAIR Ncirc_ok %d naccept %d\n",Ncirc_out,naccept);

    if (naccept > 0) ++Npair_accept;
    }

   } /* bn */ 

  } /* an */

  Renumber_AnumRnum(Phead);
  printf("#Ntry %d Nspok %d Naccept %d Nprobe %d Npair %d Npair_accept %d\n",
   Ntry,Nspok,Naccept,Nprobe,Npair,Npair_accept);

  Free_Overlap_List(Ahead);
  Free_Col_Voxel( &cvox, cvox.N[0],cvox.N[1],cvox.N[2]);

} /* end of Make_Probe_Spheres_Three_Contact_PairColVoxel_Overlap() */



void  Make_Probe_Spheres_Three_Contact_Overlap(Phead,Ahead,Rprobe,Dmat)
 struct ATOM *Phead;
 struct ATOM *Ahead;
 float  Rprobe;
 struct MATRIX *Dmat;
{
 struct ATOM *an,*bn,*cn;
 float Rprobe2;
 float Ppos[3],Qpos[3];
 int i,Nprobe;
 char spok,pok,qok;
 int Ntry,Nspok,Naccept,naccept,Npair_accept,Npair; 

 printf("#Make_Probe_Spheres_Three_Contact_Overlap()\n");
 
 Rprobe2 = Rprobe *2;
 Nprobe = 0;
 Phead->next = NULL;


 Set_Overlap_List(Ahead,Dmat,Rprobe);
 
 Ntry = Nspok = Naccept = Npair = Npair_accept = 0; 
 an = Ahead;

 while (an->next != NULL)
 {
  an = an->next;
  bn = an;
  while (bn->next != NULL)
  {
   bn = bn->next;
   
   if (Dmat->m[an->num][bn->num] <= an->R+bn->R+Rprobe2)
   {
    cn = bn;
    naccept = 0;
    ++Npair; 
    while (cn->next != NULL)
    {
     cn = cn->next;
     if( (Dmat->m[an->num][cn->num] <= an->R+cn->R+Rprobe2) &&
         (Dmat->m[bn->num][cn->num] <= bn->R+cn->R+Rprobe2) )
     {
       spok = Cal_Sphere_On_Three_Atoms(Ppos,Qpos,Rprobe,an,bn,cn);
       ++Ntry;
 
       if (spok==1)
       {
        ++Nspok;
        pok = qok = 0;
        
        if (Check_Crash_Pos_and_Overlapped_Atoms(Ppos,Rprobe,an)==0)
        { Add_Atom_Stack(Phead,Ppos,Rprobe,'T',Nprobe,an,bn,cn); ++Nprobe; pok = 1;}
        
        if (Check_Crash_Pos_and_Overlapped_Atoms(Qpos,Rprobe,an)==0)
         {Add_Atom_Stack(Phead,Qpos,Rprobe,'T',Nprobe,an,bn,cn); ++Nprobe; qok = 1;}

       if ((pok==1)||(qok==1)){  ++Naccept; ++naccept;}
       }
      } 
   
    } /* cn */ 

     if (naccept > 0) ++Npair_accept;
    }

   } /* bn */ 

  } /* an */

  Renumber_AnumRnum(Phead);

  printf("#Ntry %d Nspok %d Naccept %d Nprobe %d Npair %d Npair_accept %d\n",
   Ntry,Nspok,Naccept,Nprobe,Npair,Npair_accept);

 Free_Overlap_List(Ahead);

} /* end of Make_Probe_Spheres_Three_Contact_Overlap() */



void  Make_Probe_Spheres_Three_Contact_ColVoxel_Overlap(Phead,Ahead,Rprobe,Dmat)
 struct ATOM *Phead;
 struct ATOM *Ahead;
 float  Rprobe;
 struct MATRIX *Dmat;
{
 struct ATOM *an,*bn,*cn;
 float Rprobe2;
 float Ppos[3],Qpos[3];
 int i,Nprobe;
 char spok,pok,qok;
 struct COLVOXEL cvox;
 int I[3];
 int Ntry,Nspok,Naccept,naccept,Npair_accept,Npair; 

 printf("#Make_Probe_Spheres_Three_Contact_ColVoxel_Overlap()\n");
 
 Rprobe2 = Rprobe *2;
 Nprobe = 0;
 Phead->next = NULL;


 Set_Overlap_List(Ahead,Dmat,Rprobe);
 
 /** Make ColVoxel for Fast Collision Check **/
 cvox.gridlen = PAR.cvox_grid;
 Cal_Size_Of_Voxel_By_Molecule(Ahead,Rprobe,cvox.gridlen,cvox.min,cvox.N,'F');
 Malloc_Col_Voxel( &cvox, cvox.N[0],cvox.N[1],cvox.N[2]);
 Cal_Col_Voxel(&cvox,Ahead,Rprobe*0.5);
 
 Ntry = Nspok = Naccept = Npair = Npair_accept = 0; 
 an = Ahead;

 while (an->next != NULL)
 {
  an = an->next;
  bn = an;
  while (bn->next != NULL)
  {
   bn = bn->next;
   
   if (Dmat->m[an->num][bn->num] <= an->R+bn->R+Rprobe2)
   {
    cn = bn;
    naccept = 0;
    ++Npair; 
    while (cn->next != NULL)
    {
     cn = cn->next;
     if( (Dmat->m[an->num][cn->num] <= an->R+cn->R+Rprobe2) &&
         (Dmat->m[bn->num][cn->num] <= bn->R+cn->R+Rprobe2) )
     {
       spok = Cal_Sphere_On_Three_Atoms(Ppos,Qpos,Rprobe,an,bn,cn);
       ++Ntry;
 
       if (spok==1)
       {
        ++Nspok;
        pok = qok = 0;
        IntXYZ_from_FloatXYZ(I,Ppos,&cvox);
        
        if ((cvox.map[I[0]][I[1]][I[2]]!=255)&&(Check_Crash_Pos_and_Overlapped_Atoms(Ppos,Rprobe,an)==0))
        { Add_Atom_Stack(Phead,Ppos,Rprobe,'T',Nprobe,an,bn,cn); ++Nprobe; pok = 1;}
        
        IntXYZ_from_FloatXYZ(I,Qpos,&cvox);
        if ((cvox.map[I[0]][I[1]][I[2]]!=255)&&(Check_Crash_Pos_and_Overlapped_Atoms(Qpos,Rprobe,an)==0))
         {Add_Atom_Stack(Phead,Qpos,Rprobe,'T',Nprobe,an,bn,cn); ++Nprobe; qok = 1;}

       if ((pok==1)||(qok==1)){  ++Naccept; ++naccept;}
       }
      } 
   
    } /* cn */ 

     if (naccept > 0) ++Npair_accept;
    }

   } /* bn */ 

  } /* an */

  Renumber_AnumRnum(Phead);

  printf("#Ntry %d Nspok %d Naccept %d Nprobe %d Npair %d Npair_accept %d\n",
   Ntry,Nspok,Naccept,Nprobe,Npair,Npair_accept);

 Free_Overlap_List(Ahead);
 Free_Col_Voxel( &cvox, cvox.N[0],cvox.N[1],cvox.N[2]);

} /* end of Make_Probe_Spheres_Three_Contact_ColVoxel_Overlap() */







int Cal_Probe_Circle_On_Two_Atoms(I,J,Rprobe,Tij,Rcirc,Rmat)
 struct ATOM *I,*J; /* Two  atoms tangent to the probe atom */
 float Rprobe;     /* Radius of Probe */
 float Tij[3];     /* Center of Probe Circle */
 float *Rcirc;     /* Radius of Circle */
 float Rmat[3][3]; /* Rotation Matrix */
 /*
  If ATOM I and J cannot provide any tangent probe atoms, set *Rcirc = 0.0 and return(0).
 */
{
 float RRij,Rij;
 double A,B,AA,BB,x,yy,t,N[3];
 double Dit,Djt;
 int m;
 float X[3],Y[3],Z[3];

 for (m=0;m<3;++m) N[m] = J->Pos[m] - I->Pos[m];
 RRij = N[0]*N[0] + N[1]*N[1] + N[2]*N[2];

 if (RRij <= 0.0) { *Rcirc = 0.0; return(0);}

 A = I->R + Rprobe;
 B = J->R + Rprobe;
 AA = A*A;
 BB = B*B;
 t = 0.5*(AA - BB)/RRij;
 for (m=0;m<3;++m) 
  Tij[m] = 0.5*(I->Pos[m] + J->Pos[m]) + t * N[m];

 x = AA-BB+RRij;
 yy = AA - x*x/4.0/RRij;
 if (yy>0.0) *Rcirc = sqrt(yy); else { *Rcirc = 0.0; return(0);}
 Rij = sqrt(RRij);
   
 for (m=0;m<3;++m) Z[m] =  N[m]/Rij;

 X[0] = 0.0; X[1] = -Z[2]; X[2] = Z[1]; 
 Normalize(X);

 Y[0] = X[2]*Z[1] - X[1]*Z[2];
 Y[1] = X[0]*Z[2] - X[2]*Z[0];
 Y[2] = X[1]*Z[0] - X[0]*Z[1];

 Rmat[0][0] = X[0]; Rmat[0][1] = Y[0]; Rmat[0][2] = Z[0];
 Rmat[1][0] = X[1]; Rmat[1][1] = Y[1]; Rmat[1][2] = Z[1];
 Rmat[2][0] = X[2]; Rmat[2][1] = Y[2]; Rmat[2][2] = Z[2];

 /* 
   printf("Rmat[0] %f %f %f\n",Rmat[0][0],Rmat[0][1],Rmat[0][2]);
   printf("Rmat[1] %f %f %f\n",Rmat[1][0],Rmat[1][1],Rmat[1][2]);
   printf("Rmat[2] %f %f %f\n",Rmat[2][0],Rmat[2][1],Rmat[2][2]);
 */
 
 return(1);

} /* end of Cal_Probe_Circle_On_Two_Atoms() */






int  Make_Probe_One_Probe_Two_Protein(Dhead,Phead,Ahead,Rprobe,Dmat)
 struct ATOM *Dhead;  /* Two Atom Tangent Probes */
 struct ATOM *Phead;  /* Previous Tangent Probes */
 struct ATOM *Ahead;  /* Protein */
 struct MATRIX *Dmat;
 float  Rprobe;
{
 struct ATOM *an,*bn,*cn,*dn;
 float Dac,Dbc,Rprobe2;
 float Ppos[3],Qpos[3];
 int Nprobe;
 char spok;

 dn = NULL;
 Rprobe2 = Rprobe *2;
 Nprobe = 0;
 Dhead->next = NULL;
 an = Ahead;

 while (an->next != NULL)
 {
  an = an->next;
  bn = an;
  while (bn->next != NULL)
  {
   bn = bn->next;
   
   if (Dmat->m[an->num][bn->num] <= an->R+bn->R+Rprobe2)
   {
    cn = Phead;
    while (cn->next != NULL)
    {
     cn = cn->next;
     if (cn->mark == 0)
     {
     Dac = Distance(an->Pos,cn->Pos); 
     Dbc = Distance(an->Pos,cn->Pos); 
     if( (Dac <= an->R+cn->R+Rprobe2) &&
         (Dbc <= bn->R+cn->R+Rprobe2) )
     {
       spok = Cal_Sphere_On_Three_Atoms(Ppos,Qpos,Rprobe,an,bn,cn);
       if (spok==1)
       {
        if (Check_Crash_Pos_and_Atoms(Ppos,Rprobe,Ahead)==0)
        { Add_Atom_Stack(Dhead,Ppos,Rprobe,'D',Nprobe,an,bn,dn); ++Nprobe;}
        if (Check_Crash_Pos_and_Atoms(Qpos,Rprobe,Ahead)==0)
        { Add_Atom_Stack(Dhead,Qpos,Rprobe,'D',Nprobe,an,bn,dn); ++Nprobe;}
       }
      } 
     }
     } /* cn */ 

    }

   } /* bn */ 

  } /* an */

  Renumber_AnumRnum(Dhead);
  cn = Phead;
  while (cn->next != NULL)
  { cn = cn->next;
    cn->mark = 1; }

  return(Nprobe);

} /* end of Make_Probe_One_Probe_Two_Protein() */



int Cal_Sphere_On_Three_Atoms(Ppos,Qpos,Rprobe,I,J,K)
 float  Ppos[3],Qpos[3]; /* Probe Atom */
 float  Rprobe;
 struct ATOM *I,*J,*K;   /* Three atoms tangent to the probe atom */
{
 double Tij[3],Tjk[3],Tik[3];
 double X[3],Y[3],Z[3];  /** Local Coordinates **/
 double IK[3],dotIK,B[3],v1[3],v2[3];
 int m;
 double D,u,height;
 char ok;

 /************
  <Float or Double ?>
 
  For precise calculation all the real numbers are calculated using "double"
  in this function, although all atom Position and distance maps are 
  stored in "float". 

  <Conditions for having 3-contact sphere with R for three atoms I, J, K>

 (1) Simple distance condition

    |I - J| <= RI + RJ + 2*Rprobe   
    |J - K| <= RJ + RK + 2*Rprobe   
    |K - I| <= RK + RI + 2*Rprobe   

  This function "Cal_Sphere_On_Three_Atoms()" does not check these conditions.
  If you want efficient calculation, check these conditions before apply the function.

 (2) Even if the conditions (1) are satisfied, another condition is required. 

   We have to define some terminology.  
  
   base_plane : triangle of the three atom center I, J, K.
   base_point : point on the base_plane. The line between the base point 
                and center of probe, is perpendicular to the base_plane.  

    |Ri + Rp|  >= |base_point - I|
    |Rj + Rp|  >= |base_point - J|
    |Rk + Rp|  >= |base_point - K|

  In the program, these conditions are directly related to 
  calculation of 'height'. 

 ************/

 /*
 printf(">> Cal_Sphere_On_Three_Atoms(Ppos,Qpos,Rprobe,I,J,K) <<\n");
 */ 
 /*** Set X,Y,Z ***/
 for (m=0;m<3;++m)  X[m] = J->Pos[m] - I->Pos[m]; 
 ok = Normalize_Double(X); if (ok==0) {printf("#WARNING NORM JI IS ZERO\n"); return(0);}
 
 for (m=0;m<3;++m)  IK[m] = K->Pos[m] - I->Pos[m]; 
 dotIK = Dot_Prod_Double(X,IK); 
 for (m=0;m<3;++m) Y[m] = IK[m] - dotIK * X[m]; 
 ok = Normalize_Double(Y);  if (ok==0) {printf("#WARNING NORM KI IS ZERO\n"); return(0);}
 Cross_Prod_Double(Z,X,Y);

 /*
 printf("I %s %s %s %s %f %f %f\n",I->Anum,I->Atom,I->Resi,I->Rnum,I->Pos[0],I->Pos[1],I->Pos[2]);
 printf("J %s %s %s %s %f %f %f\n",J->Anum,J->Atom,J->Resi,J->Rnum,J->Pos[0],J->Pos[1],J->Pos[2]);
 printf("K %s %s %s %s %f %f %f\n",K->Anum,K->Atom,K->Resi,K->Rnum,K->Pos[0],K->Pos[1],K->Pos[2]);
 printf("X %f %f %f\n",X[0],X[1],X[2]);
 printf("Y %f %f %f\n",Y[0],Y[1],Y[2]);
 printf("Z %f %f %f\n",Z[0],Z[1],Z[2]);
 */
 
 /*** Calculate Tij,Tjk,Tik ***/
 Cal_Tij_on_Base_Plane(Tij,I,J,Rprobe);
 Cal_Tij_on_Base_Plane(Tjk,J,K,Rprobe);
 Cal_Tij_on_Base_Plane(Tik,I,K,Rprobe);

 /* 
 printf("Tij %f %f %f\n",Tij[0],Tij[1],Tij[2]);
 printf("Tjk %f %f %f\n",Tjk[0],Tjk[1],Tjk[2]);
 printf("Tik %f %f %f\n",Tik[0],Tik[1],Tik[2]);
 */
 
 /*** Calculate point b (center of base-plane IJK) **/
 for (m=0;m<3;++m) 
  { v1[m] = Tik[m] - I->Pos[m]; 
    v2[m] = Tik[m] - Tij[m]; }

 u = Dot_Prod_Double(v1,v2)/Dot_Prod_Double(v1,Y);
 for (m=0;m<3;++m)  B[m] = Tij[m] + u * Y[m];

 /* printf("B %f %f %f\n",B[0],B[1],B[2]); */


 /*** Cal Probe center 'P' **/
 for (m=0;m<3;++m)  v1[m] = B[m] - I->Pos[m];
 height = (I->R + Rprobe)*(I->R + Rprobe) - (v1[0]*v1[0]+v1[1]*v1[1]+v1[2]*v1[2]);

 /* Case for improper obtuse(donkaku) triangle */ 
 if (height <=0.0)  
 { 
   /*
   printf("#WARNING:height is zero. Improper 'obtuse' triangle.\n"); 
   */
   return(0); }

 height = sqrt(height);

 /* printf("height %f\n",height); */
 for (m=0;m<3;++m)  
  { Ppos[m] = B[m] + height * Z[m];
    Qpos[m] = B[m] - height * Z[m]; }

 return(1);

} /* end of Cal_Sphere_On_Three_Atoms() */







int Cal_Sphere_On_Three_Atoms_Float(Ppos,Qpos,Rprobe,I,J,K)
 float  Ppos[3],Qpos[3]; /* Probe Atom */
 float  Rprobe;
 struct ATOM *I,*J,*K;   /* Three atoms tangent to the probe atom */
{
 float Tij[3],Tjk[3],Tik[3];
 float X[3],Y[3],Z[3];  /** Local Coordinates **/
 float IK[3],dotIK,B[3],v1[3],v2[3];
 int m;
 float D,u,height;
 char ok;

 /************

  <Conditions for having 3-contact sphere with R for three atoms I, J, K>

 (1) Simple distance condition

    |I - J| <= RI + RJ + 2*Rprobe   
    |J - K| <= RJ + RK + 2*Rprobe   
    |K - I| <= RK + RI + 2*Rprobe   

  This function "Cal_Sphere_On_Three_Atoms()" does not check these conditions.
  If you want efficient calculation, check these conditions before apply the function.

 (2) Even if the conditions (1) are satisfied, another condition is required. 

   We have to define some terminology.  
  
   base_plane : triangle of the three atom center I, J, K.
   base_point : point on the base_plane. The line between the base point 
                and center of probe, is perpendicular to the base_plane.  

    |Ri + Rp|  >= |base_point - I|
    |Rj + Rp|  >= |base_point - J|
    |Rk + Rp|  >= |base_point - K|

  In the program, these conditions are directly related to 
  calculation of 'height'. 

 ************/

 /*
 printf(">> Cal_Sphere_On_Three_Atoms(Ppos,Qpos,Rprobe,I,J,K) <<\n");
 */ 
 /*** Set X,Y,Z ***/
 for (m=0;m<3;++m)  X[m] = J->Pos[m] - I->Pos[m]; 
 ok = Normalize(X); if (ok==0) {printf("#WARNING NORM JI IS ZERO\n"); return(0);}
 
 for (m=0;m<3;++m)  IK[m] = K->Pos[m] - I->Pos[m]; 
 dotIK = Dot_Prod(X,IK); 
 for (m=0;m<3;++m) Y[m] = IK[m] - dotIK * X[m]; 
 ok = Normalize(Y);  if (ok==0) {printf("#WARNING NORM KI IS ZERO\n"); return(0);}
 Cross_Prod(Z,X,Y);

 /*
 printf("I %s %s %s %s %f %f %f\n",I->Anum,I->Atom,I->Resi,I->Rnum,I->Pos[0],I->Pos[1],I->Pos[2]);
 printf("J %s %s %s %s %f %f %f\n",J->Anum,J->Atom,J->Resi,J->Rnum,J->Pos[0],J->Pos[1],J->Pos[2]);
 printf("K %s %s %s %s %f %f %f\n",K->Anum,K->Atom,K->Resi,K->Rnum,K->Pos[0],K->Pos[1],K->Pos[2]);
 printf("X %f %f %f\n",X[0],X[1],X[2]);
 printf("Y %f %f %f\n",Y[0],Y[1],Y[2]);
 printf("Z %f %f %f\n",Z[0],Z[1],Z[2]);
 */
 
 /*** Calculate Tij,Tjk,Tik ***/
 Cal_Tij_on_Base_Plane(Tij,I,J,Rprobe);
 Cal_Tij_on_Base_Plane(Tjk,J,K,Rprobe);
 Cal_Tij_on_Base_Plane(Tik,I,K,Rprobe);

 /* 
 printf("Tij %f %f %f\n",Tij[0],Tij[1],Tij[2]);
 printf("Tjk %f %f %f\n",Tjk[0],Tjk[1],Tjk[2]);
 printf("Tik %f %f %f\n",Tik[0],Tik[1],Tik[2]);
 */
 
 /*** Calculate point b (center of base-plane IJK) **/
 for (m=0;m<3;++m) 
  { v1[m] = Tik[m] - I->Pos[m]; 
    v2[m] = Tik[m] - Tij[m]; }

 u = Dot_Prod(v1,v2)/Dot_Prod(v1,Y);
 for (m=0;m<3;++m)  B[m] = Tij[m] + u * Y[m];

 /* printf("B %f %f %f\n",B[0],B[1],B[2]); */


 /*** Cal Probe center 'P' **/
 for (m=0;m<3;++m)  v1[m] = B[m] - I->Pos[m];
 height = (I->R + Rprobe)*(I->R + Rprobe) - (v1[0]*v1[0]+v1[1]*v1[1]+v1[2]*v1[2]);

 /* Case for improper obtuse(donkaku) triangle */ 
 if (height <=0.0)  
 { 
   /*
   printf("#WARNING:height is zero. Improper 'obtuse' triangle.\n"); 
   */
   return(0); }

 height = sqrt(height);

 /* printf("height %f\n",height); */
 for (m=0;m<3;++m)  
  { Ppos[m] = B[m] + height * Z[m];
    Qpos[m] = B[m] - height * Z[m]; }

 return(1);

} /* end of Cal_Sphere_On_Three_Atoms_Float() */



void Cal_Tij_on_Base_Plane(Tij,I,J,Rp)
 double Tij[3];
 struct ATOM *I,*J;
 float Rp;
{
 double RRij,D[3];
 double t,A,B;
 int m;

 for (m=0;m<3;++m) D[m] = I->Pos[m] - J->Pos[m];
 RRij = D[0]*D[0] + D[1]*D[1] + D[2]*D[2];
 if (RRij > 0.0)
 {
   A = I->R + Rp;
   B = J->R + Rp;
   t = 0.5*(A*A - B*B)/RRij;
   for (m=0;m<3;++m) 
    Tij[m] = 0.5*(I->Pos[m] + J->Pos[m])+ t * (J->Pos[m] - I->Pos[m]);
 
  }
 else for (m=0;m<3;++m) Tij[m] = I->Pos[m];

} /* end of Cal_Tij_on_Base_Plane() */


void Cal_Tij_on_Base_Plane_Float(Tij,I,J,Rp)
 float Tij[3];
 struct ATOM *I,*J;
 float Rp;
{
 float RRij,D[3];
 double t,A,B;
 int m;

 for (m=0;m<3;++m) D[m] = I->Pos[m] - J->Pos[m];
 RRij = D[0]*D[0] + D[1]*D[1] + D[2]*D[2];
 if (RRij > 0.0)
 {
   A = I->R + Rp;
   B = J->R + Rp;
   t = 0.5*(A*A - B*B)/RRij;
   for (m=0;m<3;++m) 
    Tij[m] = 0.5*(I->Pos[m] + J->Pos[m])+ t * (J->Pos[m] - I->Pos[m]);
 
  }
 else for (m=0;m<3;++m) Tij[m] = I->Pos[m];

} /* end of Cal_Tij_on_Base_Plane_Float() */









float Norm(X)
 float X[3];
{
 float D;
 D = X[0]*X[0] + X[1]*X[1] + X[2]*X[2];
 if (D>0.0) { D = sqrt(D);}
 return(D);
} /* end of Norm() */


int Normalize(X)
 float X[3];
{
 float D;
 D = X[0]*X[0] + X[1]*X[1] + X[2]*X[2];
 if (D>0.0) 
 { D = sqrt(D);
   X[0] /= D; X[1] /= D; X[2] /= D; 
   return(1); }
 else return(0);

} /* end of Normalize() */


int Normalize_Double(X)
 double X[3];
{
 double D;
 D = X[0]*X[0] + X[1]*X[1] + X[2]*X[2];
 if (D>0.0) 
 { D = sqrt(D);
   X[0] /= D; X[1] /= D; X[2] /= D; 
   return(1); }
 else return(0);

} /* end of Normalize_Double() */





float Dot_Prod(A,B)  
 float A[3],B[3];
{ return(A[0]*B[0] + A[1]*B[1] + A[2]*B[2]); }

double Dot_Prod_Double(A,B)  
 double A[3],B[3];
{ return(A[0]*B[0] + A[1]*B[1] + A[2]*B[2]); }

void Cross_Prod(C,A,B)  
 float C[3],A[3],B[3];
{ C[0] = A[1]*B[2] - A[2]*B[1];
  C[1] = A[2]*B[0] - A[0]*B[2];
  C[2] = A[0]*B[1] - A[1]*B[0]; }

void Cross_Prod_Double(C,A,B)  
 double C[3],A[3],B[3];
{ C[0] = A[1]*B[2] - A[2]*B[1];
  C[1] = A[2]*B[0] - A[0]*B[2];
  C[2] = A[0]*B[1] - A[1]*B[0]; }



float Distance(A,B)  
 float A[3],B[3];
{ 
 float D[3],dis;
 int m;
 for (m=0;m<3;++m) D[m] = A[m] - B[m];
 dis = 0.0; 
 for (m=0;m<3;++m) dis += D[m]*D[m];
 
 if (dis>0.0) dis = sqrt(dis);
 return(dis);
}






void Add_Atom_Stack(Ahead,pos,R,chain,Natom,c0,c1,c2)
 struct ATOM *Ahead;
 float pos[3],R;
 char chain; 
 int Natom;
 struct ATOM *c0,*c1,*c2; /* Contacted Protein Atoms */
{
 struct ATOM *an,*nn;
 int i;

  nn = Ahead->next;
  Ahead->next = (struct ATOM*)malloc(sizeof(struct ATOM));
  an = Ahead->next;
  an->next = nn;
  an->prev = Ahead;
  if (an->next != NULL) an->next->prev = an;

  for (i=0;i<3;++i) an->Pos[i] = pos[i];
  an->R = R;
  an->num = an->rnum = Natom;
  sprintf(an->Rnum,"%4d ",an->rnum);
  sprintf(an->Atom,"CA ");
  sprintf(an->Resi,"PRB");
  an->AHtype = 'H';
  if ((an->num %100)==0) {printf("#an->num %d\n",an->num);}
  sprintf(an->Anum,"%5d",an->num);
  an->Chain = chain;
  an->tFactor = 0.0;
  an->mark = 0;
  an->con[0] = c0; an->con[1] = c1; an->con[2] = c2;
  an->rnext = an->rprev = NULL;
  an->res = NULL;
  an->subtype = ' ';

} /* end of Add_Atom_Stack() */





void Assign_ChainID(Ahead,chain)
 struct ATOM *Ahead;
 char chain;
{
 struct ATOM *an;
 int Natom;

 Natom = 0;
 an = Ahead;
 while (an->next != NULL)
 { an = an->next;
   an->Chain = chain; }

} /* end of Assign_ChainID() */



void Renumber_AnumRnum(Ahead)
 struct ATOM *Ahead;
{
 struct ATOM *an;
 int Natom;

 Natom = 0;
 an = Ahead;
 while (an->next != NULL)
 { an = an->next;
   an->num = Natom;
   if (an->num < 100000)
    sprintf(an->Anum,"%5d",an->num);
   else 
    sprintf(an->Anum,"%5d",an->num%100000);

   if (an->num < 10000)
     sprintf(an->Rnum,"%4d ",an->num); 
   else
     sprintf(an->Rnum,"%4d ",an->num%10000); 

   ++Natom; }

} /* end of Renumber_AnumRnum() */



int Check_Crash_Pos_and_Atoms(pos,R,Ahead)
 float pos[3],R;
 struct ATOM *Ahead;
{
 /*
   Naive crash check between pos[3] and protein atoms contained in Ahead.
   if crash pos and atoms, then return 1, otherwise return 0.
 */
 struct ATOM *an;
 int m; 
 float d[3],D;

 an = Ahead;
 while (an->next != NULL)
 {
   an = an->next;
   for (m=0;m<3;++m) d[m] = pos[m] - an->Pos[m]; 
   D = d[0]*d[0] + d[1]*d[1] + d[2]*d[2];
   if (D>0.0) D = sqrt(D);
   if ((R + an->R - D)>PAR.Lcrash_permit) 
   {
 /*
    printf("#crash pos %f %f %f R %f an %s %f %f %f R %f D %f\n",
    pos[0],pos[1],pos[2],R, an->Anum,
    an->Pos[0],an->Pos[1],an->Pos[2],an->R,D); 
   */ 
    return(1);
    } 
  }

  return(0);

} /* end of Check_Crash_Pos_and_Atoms() */



void Remove_Crashed_Atom(Phead,Rhead)
 struct ATOM *Phead;  /* Head of probed atoms to be checked */
 struct ATOM *Rhead;  /* Head of reference atoms */
{
 struct ATOM *pn,*rn;
 char crash;

 printf("#Remove_Crashed_Atom()\n"); fflush(stdout);
 pn = Phead; crash = 0;
 while (pn->next != NULL)
 {
   pn = pn->next; 

   crash = Check_Crash_Pos_and_Atoms(pn->Pos,pn->R,Rhead);
   if (crash == 1)
   {
     sprintf(pn->Resi,"XXX"); 
     pn->prev->next = pn->next;
     if (pn->next != NULL) pn->next->prev = pn->prev;
   }
 }

} /* end of Remove_Crashed_Atom() */




void Joint_Atom_List(Ahead,Bhead)
 struct ATOM *Ahead,*Bhead;
{
 struct ATOM  *endA;

 endA = Ahead;
 while (endA->next !=NULL) endA = endA->next;

 endA->next = Bhead->next;
 if (Bhead->next != NULL) Bhead->next->prev = endA;
 Bhead->next = NULL;

} /* end of Joint_Atom_List() */
