/**

 <Overlap.h>

**/

extern void Set_Overlap_List();
extern void Free_Overlap_List();
extern int  Check_Crash_Pos_and_Overlapped_Atoms();
