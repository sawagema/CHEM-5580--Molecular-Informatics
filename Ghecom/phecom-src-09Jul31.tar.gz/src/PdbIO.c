/*

<PdbIO.c>

 functions for input/output of PDB files
 using list structure (ATOM and RESIDUE node). 

 coded by Takeshi Kawabata (takawaba@is.naist.jp)

*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <strings.h>
#include <math.h>
#include <time.h>
#include "pdbstruct.h" 
#include "EachVol.h" 

/*** Functions (GLOBAL) ***/
void Read_PDB_File();
void Make_Residue_List();
void Find_Filename_Core();
void Get_Part_Of_Line();
char *Get_Date_String();
char *Get_Date_String_PDB();
int  Number_Of_Atom();
int  Number_Of_Residue();
int  Number_Of_Chain();
void Malloc_MATRIX();
void Free_MATRIX();
int  Free_ATOMs();
void Cal_Distance_MATRIX();
void Set_Region_Of_Atoms();
void Write_Residue_File();
void Set_AtomName_Of_Probes_By_Contacted_Three_Atoms(); 
void Set_Constant_tFactor();
void Renumber_Atom_Number();
void Renumber_Residue_Number();
void Write_PDB_File();
void Write_PDB_File_Residue();
void Read_PDB_File_Probes();
void Set_Pseudo_Three_Contacting_Atoms_To_Probes();
void Delete_Probes_DoNot_Contact_Protein();
void Write_PDB_File_Probes();
void Add_Atom_To_Residue_Head();
void Add_Atom_To_Residue_Tail();
void Output_Residues_Atoms();
void Write_PDB_File_With_Nvec();
void Write_Comment_PDB_Remark();

/*** Functions (LOCAL) ***/
static void Split_to_Words();
static struct ATOM *Find_Atom_with_Anum();
static void Exclude_Doubling_altLoc_Atoms();
static int Find_Same_Res_Rnum_Atom_Before();
static void Change_N_CA_C_O_Hetatom_to_Atom();
static void Renumber_Atom_num();
static void Exclude_Hetero_Atoms();



void Read_PDB_File(fname,Ahead,HETtype,ChainID)
 char *fname;
 struct ATOM *Ahead;
 char  HETtype;    /* Read HETATM or not 'T' or 'F' */
 char  ChainID;    /* Chain Identifier () */
{
 FILE *fp;
 char line[256],B[32],Aname[32],Rname[32],atomtype,chain,altloc;
 char atminfo[32],atminfo0[32],end;
 float P[3];
 int accept,anum;
 struct ATOM *an;

 printf("#Read_PDB_File(\"%s\")\n",fname);
 anum = 0;  
 Ahead->next = NULL;
 an = Ahead; end = 0;

 fp = fopen(fname,"r");
 if (fp==NULL){printf("#ERROR:Can't open pdbfile \"%s\"\n",fname); exit(1);} 
 while ((feof(fp)==0)&&(end==0))
 {
  line[0] = '\0';
  fgets(line,255,fp);
       if (strncmp(line,"ATOM",4)==0)   atomtype = 'A';
  else if (strncmp(line,"HETATM",6)==0) atomtype = 'H';
  else atomtype = ' ';

  if (strncmp(line,"ENDMDL",6)==0) end = 1;  

  if (atomtype != ' ')
  { 
    accept = 1; 
    Get_Part_Of_Line(Aname,line,12,15);
    Get_Part_Of_Line(Rname,line,17,19);
    Get_Part_Of_Line(atminfo,line,12,25);
    atminfo[4] = ' '; 
    /* printf("\"%s\"\n",atminfo); */
    altloc = line[16]; 
    
    chain = line[21]; 

    /*** Decide Accept or Not ***/

 /*
    if ((HETtype == 'F') && (atomtype == 'H')) accept = 0;
  */  
  if (Aname[1]=='H') accept = 0;

    if (strncmp(Rname,"HOH",3)==0) accept = 0;
    if (strncmp(Rname,"DOD",3)==0) accept = 0;

    if ((ChainID!='-')&&(chain!=ChainID)) accept = 0;

    if (accept==1)
    { 
     an->next = (struct ATOM *)malloc(sizeof(struct ATOM));
     an->next->prev = an;
     an = an->next;
     an->next = NULL;
     Get_Part_Of_Line(B,line,30,37); an->Pos[0] = atof(B);
     Get_Part_Of_Line(B,line,38,45); an->Pos[1] = atof(B);
     Get_Part_Of_Line(B,line,46,53); an->Pos[2] = atof(B);
     Get_Part_Of_Line(an->Anum,line,6,10);
     Get_Part_Of_Line(an->Atom,line,12,15);
     Get_Part_Of_Line(an->Resi,line,17,19);
     Get_Part_Of_Line(an->Rnum,line,22,26);
     Get_Part_Of_Line(B,line,54,59); an->Occup  = atof(B);
     an->tFactor = 0.000;
     Get_Part_Of_Line(B,line,60,65); an->tFactor = atof(B);
     an->Chain  = chain; 
     an->altLoc = altloc; 
     an->num   = anum;
     an->res = NULL;
     an->rnext = an->rprev = NULL;
     an->AHtype = atomtype;
     an->con[0] = an->con[1] = an->con[2] = NULL; 
     an->subtype = ' ';
     ++anum; 
    }

   sprintf(atminfo0,"%s",atminfo); 
  }

 } /* while */

 fclose(fp);
 Exclude_Doubling_altLoc_Atoms(Ahead);
 if (PAR.Het2Atm == 'T') Change_N_CA_C_O_Hetatom_to_Atom(Ahead);
 
 if (HETtype == 'F')  Exclude_Hetero_Atoms(Ahead); 

} /* end of Read_PDB_File() */








void Write_PDB_File(fname,Ahead,mode,comment,command)
 char *fname;
 struct ATOM *Ahead;
 char mode; /* 'a'ppend, 'w'rite */
 char *comment;
 char *command;
{
 FILE *fp;
 struct ATOM *an;
 int i,j,L;
 char line[1024],subline[100];

 printf("#Write_PDB_File -> \"%s\" %s\n",fname,Get_Date_String_PDB());
 if (fname[0]=='-') fp = stdout;
 else
 {
    if (mode=='a') fp = fopen(fname,"a");
             else  fp = fopen(fname,"w");
  if (fp==NULL) { printf("#ERROR:Can't write to \"%s\"\n",fname); exit(1);}
 }

 sprintf(line,"FILENAME \"%s\"",fname);
 Get_Part_Of_Line(subline,line,0,40);
 fprintf(fp,"HEADER    %-40s%s   0XXX      0XXX   1\n",subline,Get_Date_String_PDB());
 
 /*** Write Comments ***/
 if (comment[0] != '\0') Write_Comment_PDB_Remark(fp,comment);

 fprintf(fp,"REMARK    DATE %s\n",Get_Date_String());
 if (command[0] != '\0') fprintf(fp,"REMARK COMMAND %s\n",command);
 fprintf(fp,"REMARK    Occupancy [55-60] : Radius of the atom\n");

 /*** Write ATOM/HETATM ***/
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
       if (an->AHtype=='A')  fprintf(fp,"ATOM  ");
  else if (an->AHtype=='H')  fprintf(fp,"HETATM");
  else fprintf(fp,"ATOM? ");
  fprintf(fp,"%5s %4s %3s %c%5s   %8.3f%8.3f%8.3f%6.2f%6.2f\n",
       an->Anum,an->Atom,an->Resi,an->Chain,an->Rnum,
       an->Pos[0],an->Pos[1],an->Pos[2],an->R,an->tFactor);
 }

 fprintf(fp,"TER\n");

 if (fp!=stdout) fclose(fp);

} /* end of Write_PDB_File() */





void Write_PDB_File_Probes(fname,Ahead,mode,comment,command)
 char *fname;
 struct ATOM *Ahead;
 char mode; /* 'a'ppend, 'w'rite */
 char *comment;
 char *command;
{
 FILE *fp;
 struct ATOM *an;
 int i,j,L;
 char line[512],subline[100];
 printf("#Write_PDB_File_Probes -> \"%s\"\n",fname);
 if (fname[0]=='-') fp = stdout;
 else
 {
    if (mode=='a') fp = fopen(fname,"a");
             else  fp = fopen(fname,"w");
  if (fp==NULL) { printf("#ERROR:Can't write to \"%s\"\n",fname); exit(1);}
 }

 sprintf(line,"PROBE_FILE \"%s\"",fname);
 Get_Part_Of_Line(subline,line,0,40);
 fprintf(fp,"HEADER    %-40s%s   0XXX      0XXX   1\n",subline,Get_Date_String_PDB());
 
 fprintf(fp,"REMARK    DATE %s\n",Get_Date_String());
 if (command[0] != '\0') fprintf(fp,"REMARK COMMAND %s\n",command);
 
 /*** Write Comments ***/
 if (comment[0] != '\0') Write_Comment_PDB_Remark(fp,comment);

 fprintf(fp,"REMARK #   catm1,catm2,catm3:Atom number of protein atoms contacting that probe\n");
 fprintf(fp,"REMARK #                    :'null' means 'not-contact'.\n");
 fprintf(fp,"REMARK%5s %4s %3s %6s   %8s%8s%8s%6s%6s%6s%6s%6s\n",
    "","","","","  X  ","  Y  ","  Z  ","Rvdw","tFact","catm1","catm2","catm3");
 /*** Write ATOM/HETATM ***/
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
       if (an->AHtype=='A')  fprintf(fp,"ATOM  ");
  else if (an->AHtype=='H')  fprintf(fp,"HETATM");
  else fprintf(fp,"ATOM? ");
  fprintf(fp,"%5s %4s %3s %c%5s   %8.3f%8.3f%8.3f%6.2f%6.2f",
       an->Anum,an->Atom,an->Resi,an->Chain,an->Rnum,
       an->Pos[0],an->Pos[1],an->Pos[2],an->R,an->tFactor);
  for (i=0;i<3;++i) 
  {
   if (an->con[i] != NULL) fprintf(fp,"%6s",an->con[i]->Anum); else fprintf(fp,"%6s","null"); 
   } 
  fprintf(fp," %c\n",an->subtype);
}

 fprintf(fp,"TER\n");

 if (fp!=stdout) fclose(fp);

} /* end of Write_PDB_File_Probes() */



void Write_PDB_File_Residue(fname,Rhead,mode,comment,command)
 char *fname;
 struct RESIDUE *Rhead;
 char mode; /* 'a'ppend, 'w'rite */
 char *comment;
 char *command;
{
 FILE *fp;
 struct RESIDUE *rn;
 struct ATOM *an;
 int i,j,L;
 char line[512],subline[100];

 printf("#Write_PDB_File_Residue -> \"%s\"\n",fname);
 if (fname[0]=='-') fp = stdout;
 else
 {
    if (mode=='a') fp = fopen(fname,"a");
             else  fp = fopen(fname,"w");
  if (fp==NULL) { printf("#ERROR:Can't write to \"%s\"\n",fname); exit(1);}
 }

 sprintf(line,"FILENAME \"%s\"",fname);
 Get_Part_Of_Line(subline,line,0,40);
 fprintf(fp,"HEADER    %-40s%s   0XXX      0XXX   1\n",subline,Get_Date_String_PDB());

 if (comment[0] != '\0') Write_Comment_PDB_Remark(fp,comment);

 if (command[0] != '\0') fprintf(fp,"REMARK COMMAND %s\n",command);
 rn = Rhead;
 while (rn->next != NULL)
 {
  rn = rn->next;
  an = &(rn->Ahead);
  while (an->rnext != NULL)
  {
   an = an->rnext;
        if (an->AHtype=='A')  fprintf(fp,"ATOM  ");
   else if (an->AHtype=='H')  fprintf(fp,"HETATM");
   else fprintf(fp,"ATOM? ");
   fprintf(fp,"%5s %4s %3s %c%5s   %8.3f%8.3f%8.3f%6.2f%6.2f\n",
        an->Anum,an->Atom,an->Resi,an->Chain,an->Rnum,
        an->Pos[0],an->Pos[1],an->Pos[2],an->R,an->tFactor);
  } /* an */

 } /* rn */

 fprintf(fp,"TER\n");
 if (fp!=stdout) fclose(fp);

} /* end of Write_PDB_File_Residue() */







void Read_PDB_File_Probes(fname,Phead,Rprobe,Ahead)
 char *fname;
 struct ATOM *Phead; /* Head of Probes */
 float Rprobe;
 struct ATOM *Ahead; /* Head of Protein Atoms */
{
 FILE *fp;
 char line[256],B[32],Aname[32],Rname[32],atomtype,chain,altloc;
 char atminfo[32],atminfo0[32];
 char constr[3][8];
 float P[3];
 int anum;
 struct ATOM *an;

 /*
 >> FILE FORMAT << 
 REMARK [con0-2]: Atom numbers of protein atoms contacting the probe.
 REMARK                               X       Y       Z     R Mprob catm1 catm2 catm3
 HETATM    1  NOC PRB P   1      10.823   9.016   2.542  1.87 11.25  1123  1127  1139
 HETATM    2  NOO PRB P   1      10.965   8.839   2.505  1.87 11.25   694  1123  1139
 HETATM    3  OCC PRB P   1      14.409   9.826   2.608  1.87 11.25   693   699  1139 
 */

 printf("#Read_PDB_File_Probes(\"%s\")\n",fname);
 anum = 0;  
 Phead->next = NULL;
 an = Phead;

 fp = fopen(fname,"r");
 if (fp==NULL){printf("#ERROR:Can't open probe_pdbfile \"%s\"\n",fname); exit(1);} 
 while (feof(fp)==0)
 {
  line[0] = '\0';
  fgets(line,255,fp);
       if (strncmp(line,"ATOM",4)==0)   atomtype = 'A';
  else if (strncmp(line,"HETATM",6)==0) atomtype = 'H';
  else atomtype = ' ';

  if (atomtype != ' ')
  { 
    Get_Part_Of_Line(Aname,line,12,15);
    Get_Part_Of_Line(Rname,line,17,19);
    Get_Part_Of_Line(atminfo,line,12,25);
    atminfo[4] = ' '; 
    /* printf("\"%s\"\n",atminfo); */
    altloc = line[16]; 
    chain = line[21]; 
    an->next = (struct ATOM *)malloc(sizeof(struct ATOM));
    an->next->prev = an;
    an = an->next;
    an->next = NULL;
    Get_Part_Of_Line(B,line,30,37); an->Pos[0] = atof(B);
    Get_Part_Of_Line(B,line,38,45); an->Pos[1] = atof(B);
    Get_Part_Of_Line(B,line,46,53); an->Pos[2] = atof(B);
    Get_Part_Of_Line(an->Anum,line,6,10);
    Get_Part_Of_Line(an->Atom,line,12,15);
    Get_Part_Of_Line(an->Resi,line,17,19);
    Get_Part_Of_Line(an->Rnum,line,22,26);
    Get_Part_Of_Line(B,line,54,59); an->Occup  = atof(B);
    Get_Part_Of_Line(B,line,60,65); an->tFactor = atof(B);
    Get_Part_Of_Line(constr[0],line,67,71);
    Get_Part_Of_Line(constr[1],line,73,77);
    Get_Part_Of_Line(constr[2],line,79,83);
    printf("line \"%s\"\n",line);
    printf("constr 0 \"%s\" 1 \"%s\" 2 \"%s\"\n",constr[0],constr[1],constr[2]);
    an->con[0] =  Find_Atom_with_Anum(constr[0],Ahead);
    an->con[1] =  Find_Atom_with_Anum(constr[1],Ahead);
    an->con[2] =  Find_Atom_with_Anum(constr[2],Ahead);
    an->tFactor = 0.0;
    an->Chain = chain; 
    an->num   = anum;
    an->res = NULL;
    an->rnext = an->rprev = NULL;
    an->AHtype = atomtype;
    an->R  = Rprobe;
    an->RR = an->R * an->R;
    an->subtype = ' '; 
    ++anum; 

   sprintf(atminfo0,"%s",atminfo); 
  }

 } /* while */

 fclose(fp);

} /* end of Read_PDB_File_Probes() */



struct ATOM *Find_Atom_with_Anum(anum,Ahead)
 char   *anum;
 struct ATOM *Ahead;
{
 struct ATOM *an;
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  /* printf("pat '%s' -> anum '%s'\n",anum,an->Anum);  */
  if (strncmp(an->Anum,anum,6)==0) return(an);
  }

 /*
 printf("#ERROR:Can't find anum \"%s\"\n",anum); exit(1);
 */
 printf("#WARNING:Can't find anum \"%s\"\n",anum); return(NULL);
 

} /* end of Find_Atom_with_Anum() */







void Set_Pseudo_Three_Contacting_Atoms_To_Probes(Phead,Ahead)
 struct ATOM *Phead; /* Head of Probes */
 struct ATOM *Ahead; /* Head of Protein Atoms */
{
 /*

  For a focused probe sphere, find three closest protein atoms 
  which satisfied the condition Dij - Rprobe - Ratom < Dthre.

 */
 struct ATOM *AtmClose[3];
 float  Dbwn_atm[3]; 
 int    Nclose;
 struct ATOM *pn,*an,*bn;
 float Dpos[3];
 float Dthre, Radd, DD, D, Dbwn,buff;
 int i, Ncha,accept;

 printf("#Set_Pseudo_Three_Contacting_Atoms_To_Probes()\n");
 Dthre = 0.1;

 pn = Phead; 
 while (pn->next != NULL)
 {
  pn = pn->next;
  Nclose = 0;

  an = Ahead;
  while (an->next != NULL)
  {
   an = an->next;
   Radd = pn->R + an->R; 
   Dpos[0] = pn->Pos[0] - an->Pos[0];
   Dpos[1] = pn->Pos[1] - an->Pos[1];
   Dpos[2] = pn->Pos[2] - an->Pos[2];
   DD = Dpos[0]*Dpos[0] + Dpos[1]*Dpos[1] + Dpos[2]*Dpos[2];
   if (DD>0.0) D = sqrt(DD); else D = 0.0;
   
   Dbwn = D - Radd; 
   if (Dbwn <= Dthre) 
   {
     accept = 0;
     if (Nclose<3) 
      {AtmClose[Nclose] = an; Dbwn_atm[Nclose] = Dbwn; ++Nclose; accept = 1;}
     else if (Dbwn < Dbwn_atm[Nclose-1])
      { AtmClose[Nclose-1] = an; Dbwn_atm[Nclose-1] = Dbwn; accept = 1;}  
     
     /* Bubble Sort */
    if (accept == 1)
     { 
      do{
       Ncha = 0;  
       for (i=1;i<Nclose;++i)
       {
         if (Dbwn_atm[i-1]>Dbwn_atm[i])
         { 
            buff = Dbwn_atm[i-1];             
            bn   = AtmClose[i-1];
            Dbwn_atm[i-1] = Dbwn_atm[i];             
            AtmClose[i-1] = AtmClose[i];
            Dbwn_atm[i]   = buff;             
            AtmClose[i]   = bn;
            ++Ncha;  
         }     
        }
       } while (Ncha>0);
    
      } 
 
    } /* Dbwn <= Dthre */
 
  } /* an */

  for (i=0;i<Nclose;++i) pn->con[i] = AtmClose[i];

 } /* pn */


} /* end of Set_Pseudo_Three_Contacting_Atoms_To_Probes() */


void Delete_Probes_DoNot_Contact_Protein(Phead)
 struct ATOM *Phead; /* Head of Probes */
{
 struct ATOM *pn; 
 int    Nclose,i;

 /* If no protein atom is contacted, delete pn */
 pn = Phead;
 while (pn->next != NULL)
 {
  pn = pn->next;

  Nclose = 0;
  for (i=0;i<3;++i)
  { 
    if (pn->con[i] != NULL) ++Nclose; 
   }

  if (Nclose==0)
  {
   if (pn->prev != NULL) pn->prev->next = pn->next;
   if (pn->next != NULL) pn->next->prev = pn->prev;
   pn = pn->prev;
  }

 } /* pn */

} /* end of Delete_Probes_DoNot_Contact_Protein() */





void Get_Part_Of_Line(part,line,s,e)
  char *part;
  char *line;
  int  s,e;
{
 int i,E,L;
 L = strlen(line)-1;
 if (line[L] == '\n') L -= 1;
 if (e>L) E = L; else E = e;
 for (i=s;i<=E;++i) part[i-s] = line[i];
 part[E-s+1] = '\0';

} /* end of Get_Part_of_Line() */





char *Get_Date_String()
{
 time_t      now_t;
 struct tm  *loc_t;
 static char Mon[][4] = {"Jan","Feb","Mar","Apr","May","Jun",
                         "Jul","Aug","Sep","Oct","Nov","Dec"};
 static char string[64];
 now_t = time(NULL);
 loc_t = localtime(&now_t);

 sprintf(string,"%s %d,%d %d:%d:%d",
  Mon[loc_t->tm_mon],loc_t->tm_mday,loc_t->tm_year+1900,
  loc_t->tm_hour,loc_t->tm_min,loc_t->tm_sec);
 return(string);

} /* end of Get_Date_String() */


char *Get_Date_String_PDB()
{
 time_t      now_t;
 struct tm  *loc_t;
 static char Mon[][4] = {"JAN","FEB","MAR","APR","MAY","JUN",
                         "JUL","AUG","SEP","OCT","NOV","DEC"};
 static char string[64];
 char day[16],year[16];
 int  Nyear;  
 now_t = time(NULL);
 loc_t = localtime(&now_t);

 if (loc_t->tm_mday <10) sprintf(day,"0%d",loc_t->tm_mday);
 else sprintf(day,"%2d",loc_t->tm_mday);

 if (loc_t->tm_year<100) Nyear = loc_t->tm_year;
   else                  Nyear = loc_t->tm_year - 100;

 if (Nyear < 10) sprintf(year,"0%d",Nyear);
            else sprintf(year,"%2d",Nyear);

 sprintf(string,"%s-%3s-%s",day, Mon[loc_t->tm_mon],year);
 return(string);

} /* end of Get_Date_String_PDB() */


void Find_Filename_Core(core,fname)
 char *core,*fname;
{
 int Wsta[100],Wend[100],Nword;
 char lastfile[128],hit;
 int i,dot_pos;

 Split_to_Words(fname,'/',&Nword,Wsta,Wend,100);
 Get_Part_Of_Line(lastfile,fname,Wsta[Nword-1],Wend[Nword-1]);
 i = strlen(lastfile)-1; 
 hit = 0;
 while ((i>0)&&(hit==0))
 {
  if ((lastfile[i] == '.') && (lastfile[i-1] != '.')) 
   {hit = 1; dot_pos = i-1;}
  --i; 
 }

 if (hit==1) Get_Part_Of_Line(core,lastfile,0,dot_pos);
 else sprintf(core,"%s",lastfile);

} /* end of Find_Filename_Core() */
 

void Split_to_Words(str,splsym,Nword,Wsta,Wend,Nwordmax)
 char *str;          /* Input String */
 char splsym;        /* Symbol for split */
 int *Nword;         /* Number of words  */
 int Wsta[];         /* Start point of str for a wowd */
 int Wend[];         /* End point of str for a wowd */
 int Nwordmax;       /* Maxium number of Nword  */
{
 /* [Example]
  str = "abc/d/ef//ghi//"
  splsym = '/'
   -->
  Nword 4
  (Wsta,Wend) = {(0,2), (4,4), (6,7), (10,12)}
 */
 int i,L;
 
 L = strlen(str);
 *Nword = 0; i = 0;

 while ((i<L)&&(*Nword < Nwordmax))
 {
  if (str[i]!=splsym)
   { Wsta[*Nword] = i;
     while ((str[i]!=splsym)&&(i<=(L-1))) { ++i; }
     Wend[*Nword] = i-1;
     ++(*Nword); }
  ++i;
 }

} /* end of Split_to_Words() */


int Number_Of_Atom(Ahead)
 struct ATOM *Ahead;
{ struct ATOM *an;
  int Natom;
  Natom = 0; an = Ahead;
  while (an->next != NULL) { an = an->next; ++Natom; }
  return(Natom);
} /* end of  Number_Of_Atom() */


int Number_Of_Residue(Rhead)
 struct RESIDUE *Rhead;
{ struct RESIDUE *rn;
  int Nres;

  Nres = 0; rn = Rhead;
  while (rn->next != NULL) {rn = rn->next; ++Nres; }
  return(Nres);

} /* end of  Number_Of_Residue() */




int Number_Of_Chain(Ahead)
 struct ATOM *Ahead;
{
 struct ATOM *an;
 int Natom,Nchain;

 Natom = Nchain = 0;
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  if (Natom!=0)
  {
    if (an->Chain != an->prev->Chain) ++Nchain;
   } 
  ++Natom;
  }

 return(Nchain);

} /* end of  Number_Of_Chain() */






void Malloc_MATRIX(M,Nmalloc)
 struct MATRIX *M;
 int Nmalloc;
{ int i,NN;
  double Mbyte;

  M->N = Nmalloc;
  NN = Nmalloc + 1; 
  Mbyte = (double)sizeof(float)*M->N * M->N/1000.0/1000.0;
  printf("#Malloc_MATRIX(N %d) --> %.2f Mbyte\n",M->N,Mbyte);
 
  if (Mbyte > MAX_MEMORY_MEGA){
   printf("#ERROR:Malloc_MATRIX():%.2f Mbyte is larger than MAX (%d Mbyte).\n",
      Mbyte,MAX_MEMORY_MEGA);
   exit(1);  
  }  
  
  M->m = (float **)malloc(sizeof(float *)*NN);
  for (i=0;i<NN;++i)
     M->m[i] = (float *)malloc(sizeof(float)*NN);

} /* end of Malloc_MATRIX() */



void Free_MATRIX(M)
 struct MATRIX *M;
{ int i;
 
 for (i=0;i<M->N;++i) free(M->m[i]);
 free(M->m);

} /* end of Free_MATRIX() */


int Free_ATOMs(Ahead)
 struct ATOM *Ahead;
{
 /* return "Number of free atom" */
 struct ATOM *an,*pn;
 int Nfree;

 printf("#Free_ATOMs()\n");
 if (Ahead->next == NULL) return(0);
                                                                                                        
 an = Ahead; pn = NULL; Nfree = 0;
 while (an->next != NULL)
  {
   pn = an;
   an = an->next;
   if ((pn != Ahead)&&(pn != NULL)) { free(pn); pn = NULL; ++Nfree;}
  }
                                                                                                        
 if (an!=NULL) { free(an); an = NULL; ++Nfree;}
 Ahead->next = NULL;
 return(Nfree);

} /* end of Free_ATOMs() */





void Cal_Distance_MATRIX(Ahead,Dmat)
 struct ATOM   *Ahead;
 struct MATRIX *Dmat;
{
 struct ATOM *an,*bn;
 float d[3],DD,D;
 int i,a,b;

/* printf("#Cal_Distance_MATRIX()\n"); */
 an = Ahead;
 while (an->next != NULL){
  an = an->next;
  bn = an; 
  while (bn->next != NULL)
  {
   bn = bn->next;
   for (i=0;i<3;++i) d[i] = an->Pos[i] - bn->Pos[i];
   DD = d[0]*d[0] + d[1]*d[1] + d[2]*d[2];
   if (DD>0.0) D = sqrt(DD); else D = 0.0;
   a = an->num; 
   b = bn->num; 
   if ((a<0)|| (a>Dmat->N))
   { printf("#ERROR:Atom %d is out of matrix range [%d..%d]\n",a,0,Dmat->N-1);
     exit(1);  }
   if ((b<0)|| (b>Dmat->N))
   { printf("#ERROR:Atom %d is out of matrix range [%d..%d]\n",b,0,Dmat->N-1);
     exit(1);  }
   
   Dmat->m[a][b] = Dmat->m[b][a] = D;
   /* printf("Dmat %d %d %f\n",a,b,Dmat->m[a][b]);  */
  } /* bn */

 } /* an */

} /* end of Cal_Distance_MATRIX() */



void Set_Region_Of_Atoms(Ahead,chainA,chainB,resA,resB)
 struct ATOM *Ahead;
 char chainA,chainB,*resA,*resB;
{
 struct ATOM *an;
 int NatomA,NatomB;

 NatomA = NatomB = 0;

 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
       if ( ((chainA=='-')||(an->Chain==chainA))  &&
            ((strncmp(resA,"xxx",3)==0)||(strncmp(resA,an->Resi,3)==0)))
        { an->region = 'A'; ++NatomA;}
  else if ( ((chainB=='-')||(an->Chain==chainB))  &&
            ((strncmp(resB,"xxx",3)==0)||(strncmp(resB,an->Resi,3)==0)))
 { an->region = 'B'; ++NatomB;}
  else  an->region = ' ';
 }

 if ((NatomA==0)||(NatomB==0))
 {
  printf("#ERROR : regions are not proper(NatomA %d NatomB %d).\n",NatomA, NatomB);
  exit(1);
 }
 else 
  { PAR.REGION = 'T';
    printf("#REGION_ASSIGNED NatomA %d NatomB %d\n",NatomA,NatomB);
   }
} /* end of Set_Region_Of_Atoms() */



void Make_Residue_List(Ahead,Rhead)
 struct ATOM    *Ahead;
 struct RESIDUE *Rhead;
{
 struct ATOM *an;
 struct RESIDUE *rn;
 int  Nresidue;

 printf("#Make_Residue_List(Ahead,Rhead)\n");
 Rhead->next = NULL;

 an = Ahead;
 rn = Rhead;
 Nresidue = 0;
 while (an->next != NULL)
 {
  an = an->next;
  
  if ((an->prev==NULL)||
      (strncmp(an->Rnum,an->prev->Rnum,5)!=0)||(an->Chain != an->prev->Chain))
  {
    rn->next = (struct RESIDUE *)malloc(sizeof(struct RESIDUE));
    rn->next->prev = rn;
    rn->next->next = NULL;
    rn = rn->next;
    rn->Chain = an->Chain;
    sprintf(rn->Resi,"%s",an->Resi);
    sprintf(rn->Rnum,"%s",an->Rnum);
    rn->Natom = 0; 
    ++Nresidue;  
    rn->num = Nresidue;
    rn->Ahead.rnext = NULL;  
}

   Add_Atom_To_Residue_Tail(rn,an); 
 }

 printf("#Nresidue %d\n",Nresidue);

} /* end of Make_Residue_List() */




void Add_Atom_To_Residue_Tail(rn,an)
 struct RESIDUE *rn;
 struct ATOM    *an;
{
 struct ATOM *bn;

 /*
 printf("#Add_Atom_To_Residue_Tail(rnum %d anum %d)\n",rn->num,an->num); fflush(stdout);
 */
 
 bn = &(rn->Ahead);
 while (bn->rnext != NULL) bn = bn->rnext;
 bn->rnext = an;
 an->rnext = NULL; 
 ++(rn->Natom);
 an->res = rn;
 an->rnum = rn->num; 
 sprintf(an->Rnum,"%s",rn->Rnum);
 sprintf(an->Resi,"%s",rn->Resi);

} /* end of Add_Atom_To_Residue_Tail() */




void Add_Atom_To_Residue_Head(rn,an)
 struct RESIDUE *rn;
 struct ATOM    *an;
{
 struct ATOM *bn;

 bn = rn->Ahead.rnext;
 rn->Ahead.rnext = an; 
 if (bn != NULL) { an->rnext = bn; } 
 ++(rn->Natom);
 an->res = rn;
 an->rnum = rn->num; 
 sprintf(an->Rnum,"%s",rn->Rnum);
 sprintf(an->Resi,"%s",rn->Resi);

} /* end of Add_Atom_To_Residue_Head() */




void Write_Residue_File(fname,Rhead,RprobeS,RprobeL,Nprobe,Ncluster,Vprobe,command)
 char *fname;
 struct RESIDUE *Rhead;
 float RprobeS,RprobeL;
 int   Nprobe, Ncluster; 
 float Vprobe;
 char *command;
{
 FILE *fp;
 struct RESIDUE *rn;
 float Vone_probe,Vprb,Mprb,Mmxcl;
 char chain;
 int i;

 printf("#Write_Residue_File() -> \"%s\"\n",fname);

 Vone_probe = 4.0/3.0*M_PI*RprobeS*RprobeS*RprobeS;

 if (fname[0]=='-') fp = stdout;
 else
 {
  fp = fopen(fname,"w");
  if (fp==NULL) { printf("#ERROR:Can't write to \"%s\"\n",fname); exit(1);}
 }

 fprintf(fp,"#>>>> Volume of Pocket Probes <<<<\n");
 if (command[0] != '\0') fprintf(fp,"#%-14s Probe %s\n","COMMAND",command);
 fprintf(fp,"#%-14s %s\n","DATE",Get_Date_String());
 fprintf(fp,"#%-14s %f\n","RprobeS",RprobeS);
 fprintf(fp,"#%-14s %f\n","RprobeL",RprobeL);
 fprintf(fp,"#%-14s %d\n","Nprobe",Nprobe);
 fprintf(fp,"#%-14s %d\n","Ncluster",Ncluster);
 fprintf(fp,"#%-14s %f\n","Vprobe",Vprobe);
 fprintf(fp,"#%-14s Number of atoms in the residue\n","[Natm]");
 fprintf(fp,"#%-14s Number of contacted probes on surface\n","[Nprb_surf]");
 fprintf(fp,"#%-14s Number of contacted probes in pocket\n","[Nprb]");
 fprintf(fp,"#%-14s Volume of contacted probes in pocket\n","[Vprb(A^3)]");
 fprintf(fp,"#%-14s Vprb /[volume of one probe]\n","[Mprb]");
 fprintf(fp,"#  (If Nprb_surf==0, Vprb and Mprobe become -1.)\n");
 if (Ncluster>0)
 { fprintf(fp,"#%-14s [Volume of contacted largest probe cluster]/[volume of one probe]\n","[Mmxcl]");
   fprintf(fp,"#  (If Nprb_surf==0, Mmxcl becomes -1.)\n");
   fprintf(fp,"#%-14s Numbers of contacted clusters\n","[clus_num]"); }
 fprintf(fp,"#[RNUM] [CHAIN] [RES] [Natm] [Nprb_surf] [Nprb] [Vprb(A^3)] [Mprb]");
 if (Ncluster>0) fprintf(fp," [Mmxcl] [clus_num]");
 fprintf(fp,"\n");

 rn = Rhead;

 while (rn->next != NULL)
 {
  rn = rn->next;
  if (rn->Chain == ' ') chain = '-'; else chain = rn->Chain;
  /*
  fprintf(fp,"%5s %c %3s %4d %4d %6.2f %6.2f",
   rn->Rnum,chain,rn->Resi,rn->Natom,rn->Nprobe,rn->Vprobe,rn->Vprobe/Vone_probe);
  */
 
  Mprb = rn->Vprobe/Vone_probe;
  Vprb   = rn->Vprobe;
  if (rn->Nprobe_surf == 0) Vprb = Mprb = -1.0; 

  fprintf(fp,"%5s %c %3s %4d %4d %4d %6.2f %6.2f",
   rn->Rnum,chain,rn->Resi,rn->Natom,rn->Nprobe_surf,rn->Nprobe,Vprb,Mprb);
 
  if (Ncluster>0)
  { 
   Mmxcl = rn->Vcluster/Vone_probe; 
   if (rn->Nprobe_surf == 0) Mmxcl = -1.0; 
   fprintf(fp," %6.2f",Mmxcl); 
   for (i=1;i<=Ncluster;++i) { if (rn->con_clus[i]==1) fprintf(fp," %d",i);} 
  }
  fprintf(fp,"\n");
 }

 if (fp!=stdout) fclose(fp);

} /* end of Write_Residue_File() */




 
void Set_AtomName_Of_Probes_By_Contacted_Three_Atoms(Phead)
 struct ATOM *Phead;
{  
 struct ATOM *an;
 int Ncarbon,i,j,change;
 char str[4],numAtm[256],buff;  
 an = Phead;

 /** Set Atom Order (N>O>S>P>C) **/
 for (i=0;i<255;++i) numAtm[i] = 10;
 numAtm['N'] = 0; numAtm['O'] = 1; numAtm['S'] = 2; 
 numAtm['P'] = 3; numAtm['C'] = 4; 

 str[3] = '\0';
 
 while (an->next != NULL)
 {
   an = an->next;
   Ncarbon = 0;
   sprintf(str,"   "); 
 
   for (i=0;i<3;++i)
    if (an->con[i] != NULL)
    { str[i] = an->con[i]->Atom[1];
      if (str[i]=='C') ++Ncarbon; }
 
   an->tFactor = (float)(3.0-Ncarbon);
   
   /* Bubble Sort for numAtm */
   do{
    change = 0;
    for (j=0;j<2;++j)
    {
      if (numAtm[str[j]] > numAtm[str[j+1]])
      { buff = str[j];
        str[j] = str[j+1];
        str[j+1] = buff; ++change; }  
    } 
   } while (change >0); 

   if (strncmp(str,"   ",3)!=0) sprintf(an->Atom," %s",str);

 }  /* an */

} /* end of Set_AtomName_Of_Probes_By_Contacted_Three_Atoms() */



void Set_Constant_tFactor(Phead,val)
 struct ATOM *Phead;
 float val;
{  
 struct ATOM *an;
   
 an = Phead;
 while (an->next != NULL)
 {
   an = an->next;
   an->tFactor = val;
 } 

} /* end of Set_Constant_tFactor() */



void Renumber_Atom_Number(Phead)
 struct ATOM *Phead;
{  
 struct ATOM *an;
 int Natom;
   
 an = Phead;
 Natom = 0;
 while (an->next != NULL)
 {
   an = an->next;
   ++Natom;
   an->num = Natom;
   sprintf(an->Anum,"%5d",an->num);
   if (an->res != NULL) 
    { sprintf(an->Rnum,"%s",an->res->Rnum);
      an->rnum = an->res->num;}
   else 
   { sprintf(an->Rnum,"%4d ",an->num);
     an->rnum = an->num;}
 } 

} /* end of Renumber_Atom_Number() */



void Renumber_Residue_Number(Rhead)
 struct RESIDUE *Rhead;
{  
 struct RESIDUE *rn;
 int Nres;
   
 rn = Rhead;
 Nres = 0;
 while (rn->next != NULL)
 {
   rn = rn->next;
   ++Nres;
   rn->num = Nres;
   sprintf(rn->Rnum,"%4d ",rn->num);
 } 

} /* end of Renumber_Residue_Number() */




void Output_Residues_Atoms(Rhead)
 struct RESIDUE *Rhead;
{
 struct RESIDUE *rn;
 struct ATOM *an;
 float r,v;

 rn = Rhead;
  while (rn->next != NULL)
  { rn = rn->next;
    if (rn->Ahead.rnext != NULL) r = rn->Ahead.rnext->R; else r = 1;
    v = 4.0/3.0 * M_PI * r*r*r;
    printf("RES %s %s Natom %d Vresidue %f Mresidue %f\n",
     rn->Resi,rn->Rnum,rn->Natom,rn->Vresidue,rn->Vresidue/v);
    an = &(rn->Ahead);
    while (an->rnext != NULL) 
    { an = an->rnext;
     printf("  ATOM %s %s %s %s %f %f %f\n",
     an->Resi,an->Rnum,an->Atom,an->Anum,an->Pos[0],an->Pos[1],an->Pos[2]); }
  } 

} /*end of Output_Residues_Atoms() */


void Exclude_Doubling_altLoc_Atoms(HeadAtom)
 struct ATOM *HeadAtom;
{
 struct MOLECULE *mol;
 struct ATOM     *an;
 char hit;
 int Nex;

 Nex = 0;
 an = HeadAtom;
 while (an->next != NULL)
 {
   an = an->next;
   if (an->altLoc != ' ')
   {
     hit = Find_Same_Res_Rnum_Atom_Before(HeadAtom,an);
     if (hit==1)
     { ++Nex;
       if (an->prev != NULL)  an->prev->next   = an->next;
       if (an->next != NULL)  an->next->prev   = an->prev; }
    }

 } /* an */

  Renumber_Atom_num(HeadAtom);

} /* end of Exclude_Doubling_altLoc_Atoms() */




void Exclude_Hetero_Atoms(HeadAtom)
 struct ATOM *HeadAtom;
{
 struct MOLECULE *mol;
 struct ATOM     *an;
 char hit;
 int Nex;

 Nex = 0;
 an = HeadAtom;
 while (an->next != NULL)
 {
   an = an->next;
   if (an->AHtype == 'H')
   { ++Nex;
     if (an->prev != NULL)  an->prev->next   = an->next;
     if (an->next != NULL)  an->next->prev   = an->prev; }

 } /* an */
    
  Renumber_Atom_num(HeadAtom);

} /* end of Exclude_Hetero_Atoms() */




void Renumber_Atom_num(HeadAtom)
 struct ATOM *HeadAtom;
{
 int Natom;
 struct ATOM     *an;

 Natom = 0;
 an = HeadAtom;
 while (an->next != NULL)
 { an = an->next; 
   an->num = Natom;
   ++Natom; }

} /* end of Renumber_Atom_num() */




int Find_Same_Res_Rnum_Atom_Before(HeadAtom,focus)
 struct ATOM  *HeadAtom;
 struct ATOM  *focus;
{
 struct ATOM *an;
 char hit;

 hit = 0;
 an = HeadAtom;
 while ((an->next != NULL)&&(hit==0)&&(an->next->num!=focus->num))
 {
  an = an->next;
  if ((an->altLoc != ' ')&&(an->num != focus->num))
   {
    if ( (focus->Chain == an->Chain) &&
         (strncmp(focus->Resi, an->Resi,3)==0) &&
         (strncmp(focus->Rnum, an->Rnum,5)==0) &&
         (strncmp(focus->Atom, an->Atom,4)==0)) { hit = 1; return(hit);}
   }

 } /* an */

  return(hit);
} /* end of Find_Same_Res_Rnum_Atom_Before() */







void Change_N_CA_C_O_Hetatom_to_Atom(HeadAtom)
 struct ATOM *HeadAtom;
{
 struct ATOM *atom,*satom;
 char Nok,Cok,CAok,Ook,stop;
 int Nhetatm;

 atom = HeadAtom;
 Nok = Cok = CAok = 0; Nhetatm = 0; satom = NULL;
 while (atom->next != NULL)
 {
  if ((strcmp(atom->Resi,atom->next->Resi)!=0)||(strcmp(atom->Rnum,atom->next->Rnum)!=0))
  {

   if (((Nok*Cok*CAok*Ook)==1)&&(Nhetatm>0))
   {
     stop = 0;
     while ((satom!=NULL)&&(satom->num <= atom->num))
     {
      if (satom->AHtype != 'A') { satom->AHtype = 'A'; }
      satom = satom->next; }
     }

   satom = NULL;
   Nok = Cok = CAok = 0; Nhetatm = 0;
  }

  atom = atom->next;

  if (satom==NULL) satom = atom;
  if (atom->AHtype != 'A') ++Nhetatm;
  if (strncmp(atom->Atom," CA ",4)==0) CAok = 1;
  if (strncmp(atom->Atom," N  ",4)==0) Nok  = 1;
  if (strncmp(atom->Atom," C  ",4)==0) Cok  = 1;
  if (strncmp(atom->Atom," O  ",4)==0) Ook  = 1;
 }

} /* end of  Change_N_CA_C_O_Hetatom_to_Atom() */




void Write_PDB_File_With_Nvec(fname,Ahead,command,Rprobe)
 char *fname;
 struct ATOM *Ahead;
 char *command; /* COMMAND STRING */
 float Rprobe;
{
 FILE *fp;
 struct ATOM *an;
 int i,j,L,Natom,anum;
 double Epnt[3];
 char line[512],subline[100];
 float ScaleNvec; 
 printf("#Write_PDB_File_With_Nvec() -> \"%s\" Rprobe %f\n",fname,Rprobe);
 if (fname[0]=='-') fp = stdout;
 else
 { fp = fopen(fname,"w");
   if (fp==NULL) { printf("#ERROR:Can't write to \"%s\"\n",fname); exit(1);} }

 sprintf(line,"FILENAME \"%s\"",fname);
 Get_Part_Of_Line(subline,line,0,40);
 fprintf(fp,"HEADER    %-40s%s   0XXX      0XXX   1\n",subline,Get_Date_String_PDB());
 fprintf(fp,"REMARK    Protein atoms with normal vectors\n");

 if (command[0] != '\0') fprintf(fp,"REMARK COMMAND \"%s\"\n",command);
 fprintf(fp,"REMARK DATE \"%s\"\n",Get_Date_String());

 fprintf(fp,"REMARK%5s %4s %3s  %5s   %8s%8s%8s%6s%6s\n",
 "Anum","Atm","Resi","Rnum","  X  ","  Y  ","  Z  "  ,"radius"," tFactor");
/** [1] Write Atoms **/
 Natom = 0;
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
       if (an->AHtype=='A')  fprintf(fp,"ATOM  ");
  else if (an->AHtype=='H')  fprintf(fp,"HETATM");
  else fprintf(fp,"ATOM? ");
  fprintf(fp,"%5s %4s %3s %c%5s   %8.3f%8.3f%8.3f%6.3f%6.3f\n",
       an->Anum,an->Atom,an->Resi,an->Chain,an->Rnum,
       an->Pos[0],an->Pos[1],an->Pos[2],an->R,an->tFactor);
 ++Natom;
 } /* an */
 fprintf(fp,"TER\n");

 /** [2] Write End Point of Nvec **/
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  if ((an->nvec[0]!=0.0)|| (an->nvec[1]!=0.0)|| (an->nvec[2]!=0.0))
  {
  anum = atoi(an->Anum) + Natom;
  ScaleNvec = an->R + Rprobe; 
  Epnt[0] = an->Pos[0] + ScaleNvec * an->nvec[0];
  Epnt[1] = an->Pos[1] + ScaleNvec * an->nvec[1];
  Epnt[2] = an->Pos[2] + ScaleNvec * an->nvec[2];

  fprintf(fp,"HETATM");
  fprintf(fp,"%5d %4s %3s %c%5s   %8.3f%8.3f%8.3f%6.3f%6.3f",
       anum,an->Atom,an->Resi,an->Chain,an->Rnum,Epnt[0],Epnt[1],Epnt[2],an->R,an->tFactor);

  fprintf(fp,"\n");
  }
 } /* an */
/** [3] Write CONECT **/
 an = Ahead;
 while (an->next != NULL)
 {
  an = an->next;
  if ((an->nvec[0]!=0.0)|| (an->nvec[1]!=0.0)|| (an->nvec[2]!=0.0))
  {
   anum = atoi(an->Anum) + Natom;
   fprintf(fp,"CONECT%5s%5d\n",an->Anum,anum);
   }
 }
 fprintf(fp,"TER\n");
 if (fp!=stdout) fclose(fp);

} /* end of Write_PDB_File_With_Nvec() */



void Write_Comment_PDB_Remark(fpo,comment)
 FILE *fpo;
 char *comment;
{
 int i,j,L;

 L = strlen(comment);
  i = j = 0;
  fprintf(fpo,"REMARK #   ");
  while (i<L)
  { if ((j>60)||(comment[i]=='\n')) { fprintf(fpo,"\nREMARK #   "); j = 0;}
    if (comment[i]!='\n') fprintf(fpo,"%c",comment[i]);
   ++i; ++j;
  }
 fprintf(fpo,"\n");

} /* end of Write_Comment_Remark() */
