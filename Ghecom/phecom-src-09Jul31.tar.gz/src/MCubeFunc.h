/*
 <MCubeFunc.h>
*/

extern void Marching_Cube();
extern void Output_MC_Faces_VRML();
extern int  Output_MC_Faces_PDB();
extern float Volume_Inside_Faces();
extern float Area_Faces();
extern void Free_MC_Vertex_Stack();
extern void Free_MC_Face_Stack();
